# GoalPulse

A polished, lightweight macOS menu bar app for counting down to the goals that matter.

GoalPulse keeps one active goal and its live countdown in your menu bar, with a pixel-art emoji that shifts from calm to urgent as the deadline approaches. Open the popover for the animated sprite and the full countdown beside it, plus progress, schedule, motivational copy, and quick actions. Everything is stored locally — no account, no analytics, no network.

## Features

- **Menu bar countdown** — pixel emoji only, countdown only, or both. The label is compact and adaptive: days/hours far out, minutes/seconds near the deadline.
- **Full goal management** — title, optional details, start date/time, deadline date/time, emoji, and accent color. Multiple goals with one active in the menu bar.
- **Live, drift-free countdown** — absolute `Date` math, a single aligned clock, and automatic refresh after wake, clock changes, and time-zone changes. No decrementing counters.
- **Pixel-art emoji moods** — 😎 calm, 🙂 steady, 🎯 focus, 🔥 intense, 🚨 urgent, and 🏆 complete. Six hand-drawn 16 × 16 sprites blink, flicker, rotate their beacon, and glint; custom emoji are converted to chunky pixel art. The live countdown and due status sit directly beside the sprite in the active card. Thresholds are customizable, and all sprite motion respects Reduce Motion and the animation intensity setting.
- **Progress visualization** — elapsed percentage, remaining percentage, route progress, timeline, and state-aware coloring (accent for normal, red for urgent, green for complete).
- **Native design** — SwiftUI materials, tinted cards, rounded typography, light/dark/system theme, and a compact 384 × 600 popover.
- **Milestone reminders** — optional notifications at 7 days, 24 hours, 1 hour, and 10 minutes. Deterministic identifiers prevent duplicate alerts.
- **Launch at login** — via `SMAppService`, with permission and placement states surfaced in Settings.
- **Local-first persistence** — human-readable JSON with atomic writes, malformed-file backup, and normalization on load.
- **Accessibility** — VoiceOver labels spell out the countdown, progress, and mood; animation is gated by Reduce Motion.

## Requirements

- macOS 14 Sonoma or later
- Xcode 16 or later (recommended), **or** Command Line Tools for the fallback build
- No third-party dependencies

## Quick start

```bash
# Build and launch with the bundled script
bash scripts/build_app.sh --run
```

The app is produced at `build/GoalPulse.app`. It runs as a menu bar–only app (`LSUIElement`), so no Dock icon appears.

### Xcode

```bash
open GoalPulse.xcodeproj
```

Select the **GoalPulse** scheme, choose **My Mac**, and press Run. The local `GoalPulseCore` package resolves automatically. To distribute, select your signing team under **Signing & Capabilities**; for local use, the project is configured for ad-hoc “Sign to Run Locally” signing.

### Command-line build

```bash
bash scripts/build_app.sh          # build only
bash scripts/build_app.sh --run    # build and open
```

If full Xcode is installed, the script uses `xcodebuild` with the shared `GoalPulse` scheme. Otherwise it builds `GoalPulseCore` with SwiftPM and compiles the app with `swiftc`.

> With Command Line Tools only, the script prefers macOS SDK 26.5. SDK 27’s SwiftUI module exposes macros that the standalone CLT toolchain does not ship. This workaround is not needed when building with full Xcode. Override the SDK with `GOALPULSE_SDK=/path/to/MacOSX.sdk` if needed.

### App icon

The icon is generated programmatically and the asset catalog/`.icns` are checked in. To regenerate:

```bash
bash scripts/generate_assets.sh
```

## Install

```bash
cp -R build/GoalPulse.app /Applications/
open /Applications/GoalPulse.app
```

Installing in `/Applications` is required for **Launch at login**. After launching, click the menu bar item, create a goal, and use the plus and gear buttons for creation and settings.

## Using GoalPulse

1. **Create a goal** — title plus start and deadline. Optional details, emoji, and accent color.
2. **Pick the menu bar goal** — the active goal’s emoji and/or countdown appears in the menu bar. Switch from the dashboard’s **Switch** action or Settings.
3. **Open the popover** — click the menu bar item for countdown, progress, timeline, and motivation.
4. **Manage goals** — **All goals** shows every goal, with edit, show-in-menu-bar, and delete actions.
5. **Tune it** — Settings covers label style, countdown format, theme, animation intensity, thresholds, reminders, launch at login, and data location.

## Architecture

```text
GoalPulse/
├── GoalPulse/
│   ├── App/
│   │   ├── GoalPulseApp.swift        # MenuBarExtra scene
│   │   ├── AppDelegate.swift         # Accessory activation, system observers
│   │   └── AppModel.swift            # App-wide coordinator
│   ├── Services/
│   │   ├── GoalStore.swift           # Atomic JSON persistence
│   │   ├── SettingsStore.swift       # UserDefaults preferences
│   │   ├── CountdownClock.swift      # One aligned wall clock
│   │   ├── NotificationManager.swift # Milestone scheduling and permissions
│   │   └── LaunchAtLoginService.swift# SMAppService wrapper
│   ├── Support/
│   │   ├── GoalDraft.swift           # Editable form state and validation
│   │   ├── GoalDateFormatting.swift  # Date/time display helpers
│   │   └── Theme.swift               # Colors, cards, materials, backgrounds
│   ├── Views/
│   │   ├── PopoverView.swift         # Route state and screen transitions
│   │   ├── CountdownDashboardView.swift
│   │   ├── GoalListView.swift
│   │   ├── GoalEditorView.swift
│   │   ├── SettingsView.swift
│   │   ├── MenuBarLabelView.swift
│   │   └── Components/               # Pixel emoji, countdown, shared chrome
│   └── Resources/                    # Info.plist, asset catalog, AppIcon.icns
├── GoalPulseCore/                    # Local Swift package — pure, tested logic
│   ├── Sources/GoalPulseCore/
│   └── Tests/GoalPulseCoreTests/
├── scripts/
│   ├── build_app.sh                  # Xcode or CLT build/package/sign
│   ├── generate_icon.swift           # CoreGraphics icon artwork
│   └── generate_assets.sh            # PNG sizes, Contents.json, .icns
└── GoalPulse.xcodeproj/              # App target and shared scheme
```

### Why a separate core package?

`GoalPulseCore` contains the domain rules that must not drift: goal validation, countdown math, emoji thresholds, formatting, milestone planning, and the Codable persistence schema. It has no SwiftUI/AppKit dependency and is covered by Swift Testing. The app layer adds system integration and views. This keeps the timer, date math, and mood transitions deterministic and easy to test.

### Countdown model

Each render asks for a new immutable `GoalCountdown` derived from `now`, `startDate`, and `deadline`. The clock wakes on the next wall-clock second, then updates `now`. Because countdown values are recomputed rather than decremented:

- timer coalescing or a missed tick cannot cause drift;
- sleep/wake, manual clock changes, and time-zone changes are corrected on the next refresh;
- DST and leap days are handled by absolute instants;
- a completed goal always reports zero remaining and the complete mood.

The menu bar label observes the same shared clock. A dedicated runtime check hosts only the label, lets real time pass, and confirms its image changes from `2m 5s` to `2m 3s` — i.e. it updates while the popover is closed.

### Persistence

Goals and the active goal ID are stored together:

```text
~/Library/Application Support/GoalPulse/goals.json
```

```json
{
  "activeGoalID": "…",
  "goals": [
    {
      "id": "…",
      "title": "Ship GoalPulse 1.0",
      "startDate": "2026-09-15T14:30:00Z",
      "deadline": "2027-01-17T20:03:12Z",
      "emoji": "🚀",
      "accentID": "indigo",
      "createdAt": "2026-09-15T14:29:00Z"
    }
  ]
}
```

- Writes are atomic.
- Invalid goals are dropped on load, a timestamped backup is kept, and the file is normalized.
- An unreadable file is backed up before a fresh store is used.
- Preferences live in `UserDefaults` under `goalPulse.preferences.v1`.
- Settings → Data & About can reveal the folder in Finder.

### Notifications

- Only requested after an explicit user action (enabling reminders or tapping **Allow**).
- Milestones are planned from absolute dates, skip milestones already in the past, and use deterministic identifiers.
- On every goal/preference change, stale pending requests are removed and a fresh plan is scheduled (capped at 60 requests).
- Notification content uses the goal title, mood emoji, motivation, and localized deadline.
- 1-hour and 10-minute reminders include a sound; all reminders show banner/list alerts when the app is frontmost.

## Permissions and configuration

| Capability | What macOS asks | Notes |
| --- | --- | --- |
| Notifications | Prompt on first explicit enable/test | Manage later in **System Settings → Notifications → GoalPulse**. If denied, Settings shows a **System Settings…** shortcut. Notification delivery is more reliable for properly signed builds. |
| Launch at login | No direct prompt; may appear as **requires approval** | Requires the app to live in `/Applications`. Approve in **System Settings → General → Login Items**. `notFound` means macOS cannot register the current location. Ad-hoc builds can be rejected; use a Developer ID signature for distribution. |
| Local file access | None | Data stays in the app’s Application Support folder. |
| Accessibility / Screen Recording / Camera / Mic | None | GoalPulse does not request or need them. |
| Network | None | No account, analytics, or network code. |

The app is a menu bar agent (`LSUIElement = true`) and does not show a Dock icon. To quit, use **Quit** in the popover footer or **Quit GoalPulse** in Settings.

## Tests

Core logic has 52 Swift Testing tests across 8 suites:

```bash
swift test --package-path GoalPulseCore
```

Coverage includes:

- exact countdown splits, completion, future starts, and invalid ranges;
- leap-year and DST-sensitive date cases;
- emoji threshold boundaries and custom threshold validation;
- full, compact, clock, menu bar, duration, percentage, and accessibility formatting;
- goal validation and date/time merging;
- preference round-tripping and sanitization;
- persistence schema normalization and milestone planning.

A separate 34-check runtime harness (not checked in) exercised the app services: add/switch/delete goals, active-goal fallback, JSON reload, exact `84 Days : 5 Hours : 33 Minutes : 12 Seconds` formatting, all five running moods plus complete, future starts, invalid deadlines, and a live clock tick. A live menu bar label check confirmed label updates with no popover open.

## Signing and distribution

### Local ad-hoc build

`scripts/build_app.sh` signs ad-hoc by default. This is sufficient for local use, but macOS may reject ad-hoc builds for login-item registration, and notifications can be less reliable. Local notifications may still work while the app is allowed in System Settings.

### Developer ID (direct distribution)

1. Build with a Developer ID identity:

   ```bash
   GOALPULSE_CODESIGN_IDENTITY="Developer ID Application: Your Name (TEAMID)" \
     bash scripts/build_app.sh
   ```

   The script enables the hardened runtime and a secure timestamp for non-ad-hoc identities.

2. Notarize the archive:

   ```bash
   # One-time credential setup
   xcrun notarytool store-credentials "GoalPulse-notary" \
     --apple-id "you@example.com" --team-id "TEAMID" --password "app-specific-password"

   ditto -c -k --keepParent build/GoalPulse.app build/GoalPulse.zip
   xcrun notarytool submit build/GoalPulse.zip --keychain-profile "GoalPulse-notary" --wait
   xcrun stapler staple build/GoalPulse.app
   ditto -c -k --keepParent build/GoalPulse.app build/GoalPulse.zip
   ```

3. Verify and distribute:

   ```bash
   spctl -a -vv build/GoalPulse.app
   codesign --verify --deep --strict --verbose=2 build/GoalPulse.app
   ```

Ship the notarized, stapled app or zip. A DMG/`pkg` can be built as well; notarize and staple that outer container in the same way. No App Sandbox or special notification entitlement is used in this direct-distribution configuration. Mac App Store distribution would require a sandbox/entitlement review pass and is out of scope for this build.

## Manual verification checklist

- [x] Builds with CLT-only toolchain; app bundle launches as a menu bar agent.
- [x] Offscreen snapshots of dashboard, list, editor, settings, empty, light/dark, and running, urgent, scheduled, and complete states.
- [x] Pixel mood sprite sheet for both animation frames; custom emoji converted to a 24 × 24 pixel grid.
- [x] Countdown, labels, and due status render beside the pixel emoji in every countdown format.
- [x] Menu bar pixel sprite and compact countdown render together in light and dark appearances, including custom emoji.
- [x] Sprite frames change over time with motion enabled and stay pixel-identical with Reduce Motion.
- [x] Exact canonical countdown format `84 Days : 5 Hours : 33 Minutes : 12 Seconds`.
- [x] Mood transitions at 90/60/40/20/5% remaining, plus trophy at completion.
- [x] Persistence reload and active-goal fallback across store instances.
- [x] Live clock tick and menu bar label update while no popover is hosted.
- [x] Deadline-before-start validation.
- [ ] Interactive notification prompt and delivery on a signed, installed build (requires user permission and cannot be automated headlessly).
- [ ] Launch-at-login registration from `/Applications` (requires installation and user approval).

## Known limitations

- A menu bar item can be hidden by macOS when the menu bar is full or by third-party menu bar managers; GoalPulse cannot force visibility.
- The popover has a fixed 384 × 600 frame; long forms and settings scroll.
- Reminders are one-shot local notifications, rescheduled as goals or preferences change. There is no recurring reminder mode.
- There is no sync, account, export/import UI, or cloud backup by design.
- Ad-hoc signed builds may not be eligible for login-item registration; use Developer ID for distribution.
- The Xcode project does not pin a development team, so you must choose your own signing identity before archiving or distributing.

## License

No license is included. Add one before distributing source.
