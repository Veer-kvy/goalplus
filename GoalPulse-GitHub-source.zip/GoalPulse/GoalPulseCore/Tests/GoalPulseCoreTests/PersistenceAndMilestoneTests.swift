import Foundation
import Testing
@testable import GoalPulseCore

@Suite("Persistence model")
struct GoalPulseDataTests {
    private let start = TestDates.date(2026, 1, 1, 8, 0)

    private func goal(
        title: String = "Test goal",
        id: UUID = UUID(),
        startOffset: TimeInterval = 0,
        duration: TimeInterval = 86_400
    ) -> Goal {
        Goal(
            id: id,
            title: title,
            startDate: start.addingTimeInterval(startOffset),
            deadline: start.addingTimeInterval(startOffset + duration)
        )
    }

    @Test("Goals and active selection round-trip through JSON")
    func codableRoundTrip() throws {
        let first = Goal(
            title: "First",
            startDate: start,
            deadline: start.addingTimeInterval(86_400),
            createdAt: start
        )
        let second = Goal(
            title: "Second",
            startDate: start.addingTimeInterval(86_400),
            deadline: start.addingTimeInterval(2 * 86_400),
            createdAt: start.addingTimeInterval(86_400)
        )
        let data = GoalPulseData(goals: [first, second], activeGoalID: second.id)

        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let encoded = try encoder.encode(data)

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let decoded = try decoder.decode(GoalPulseData.self, from: encoded)

        #expect(decoded == data)
        #expect(decoded.activeGoalID == second.id)
    }

    @Test("Missing fields decode with safe defaults")
    func missingFields() throws {
        let json = Data("{}".utf8)
        let decoded = try JSONDecoder().decode(GoalPulseData.self, from: json)
        #expect(decoded.goals.isEmpty)
        #expect(decoded.activeGoalID == nil)
        #expect(decoded.schemaVersion == GoalPulseData.currentSchemaVersion)
    }

    @Test("Invalid and duplicate goals are removed safely")
    func normalizationDropsBadGoals() {
        let valid = goal(title: "  Valid  ")
        let invalid = goal(title: "Broken", duration: 0)
        let duplicate = goal(title: "Duplicate", id: valid.id)
        let data = GoalPulseData(goals: [valid, invalid, duplicate], activeGoalID: invalid.id)

        let result = data.normalized()

        #expect(result.data.goals.count == 1)
        #expect(result.data.goals.first?.title == "Valid")
        #expect(result.droppedGoals == 2)
        #expect(result.data.activeGoalID == valid.id)
        #expect(result.repairedActiveGoal)
    }

    @Test("A nil active goal is repaired to the first goal")
    func normalizationRepairsActiveGoal() {
        let first = goal(title: "First")
        let second = goal(title: "Second", startOffset: 86_400)
        let data = GoalPulseData(goals: [first, second], activeGoalID: nil)

        let result = data.normalized()
        #expect(result.data.activeGoalID == first.id)
        #expect(result.repairedActiveGoal)
    }

    @Test("An empty file normalizes to no active goal")
    func normalizationEmpty() {
        let result = GoalPulseData(goals: [], activeGoalID: UUID()).normalized()
        #expect(result.data.goals.isEmpty)
        #expect(result.data.activeGoalID == nil)
        #expect(result.repairedActiveGoal)
    }

    @Test("Valid active selection is preserved")
    func normalizationPreservesActive() {
        let first = goal(title: "First")
        let second = goal(title: "Second", startOffset: 86_400)
        let result = GoalPulseData(goals: [first, second], activeGoalID: second.id).normalized()
        #expect(result.data.activeGoalID == second.id)
        #expect(!result.repairedActiveGoal)
        #expect(result.droppedGoals == 0)
    }
}

@Suite("Milestone planning")
struct MilestonePlannerTests {
    private let now = TestDates.date(2026, 1, 1, 0, 0)

    private func goal(startOffset: TimeInterval, duration: TimeInterval = 30 * 86_400) -> Goal {
        Goal(
            title: "Milestone goal",
            startDate: now.addingTimeInterval(startOffset),
            deadline: now.addingTimeInterval(startOffset + duration)
        )
    }

    @Test("Future milestones are planned in chronological order")
    func plannedOrder() {
        let target = goal(startOffset: 0, duration: 10 * 86_400)
        let planned = MilestonePlanner.plan(
            goals: [target],
            milestones: Set(NotificationMilestone.allCases),
            now: now
        )

        #expect(planned.count == 4)
        #expect(planned.map(\.milestone) == [.sevenDays, .oneDay, .oneHour, .tenMinutes])
        #expect(planned.allSatisfy { $0.fireDate > now })
        #expect(planned.allSatisfy { $0.goal.id == target.id })
    }

    @Test("Milestones already in the past are not queued")
    func missedMilestonesSkipped() {
        // Five days remaining: only 24h, 1h and 10m milestones are ahead.
        let target = goal(startOffset: -30 * 86_400, duration: 35 * 86_400)
        let planned = MilestonePlanner.plan(
            goals: [target],
            milestones: Set(NotificationMilestone.allCases),
            now: now
        )

        #expect(!planned.contains { $0.milestone == .sevenDays })
        #expect(planned.count == 3)
    }

    @Test("Milestones before a future goal starts are skipped")
    func beforeStartSkipped() {
        // Starts in 25 hours, ends in 26 hours. The 7-day and 24-hour
        // milestones fall before the goal begins; the 1-hour milestone lands
        // exactly on the start and is kept.
        let target = goal(startOffset: 25 * 3_600, duration: 3_600)
        let planned = MilestonePlanner.plan(
            goals: [target],
            milestones: Set(NotificationMilestone.allCases),
            now: now
        )

        #expect(planned.count == 2)
        #expect(planned.map(\.milestone) == [.oneHour, .tenMinutes])
        #expect(planned.allSatisfy { $0.fireDate >= target.startDate })
    }

    @Test("Only selected milestones are planned")
    func selectedMilestones() {
        let target = goal(startOffset: 0, duration: 10 * 86_400)
        let planned = MilestonePlanner.plan(
            goals: [target],
            milestones: [.oneHour, .tenMinutes],
            now: now
        )
        #expect(planned.map(\.milestone) == [.oneHour, .tenMinutes])
    }

    @Test("Planning respects the pending notification limit")
    func limit() {
        let targets = (0..<20).map { index in
            goal(startOffset: TimeInterval(index) * 86_400, duration: 10 * 86_400)
        }
        let planned = MilestonePlanner.plan(
            goals: targets,
            milestones: Set(NotificationMilestone.allCases),
            now: now,
            limit: 5
        )
        #expect(planned.count == 5)
        #expect(planned == planned.sorted { $0.fireDate < $1.fireDate })
    }

    @Test("Invalid goals never produce notifications")
    func invalidGoalSkipped() {
        let invalid = Goal(title: "Invalid", startDate: now, deadline: now)
        let planned = MilestonePlanner.plan(
            goals: [invalid],
            milestones: Set(NotificationMilestone.allCases),
            now: now
        )
        #expect(planned.isEmpty)
    }
}
