import Foundation
import Testing
@testable import GoalPulseCore

@Suite("Emoji moods")
struct EmojiMoodTests {
    private func mood(remainingFraction fraction: Double, thresholds: EmojiThresholds = .standard) -> EmojiMood {
        let start = TestDates.date(2026, 1, 1)
        let total: TimeInterval = 400
        let deadline = start.addingTimeInterval(total)
        let now = deadline.addingTimeInterval(-(total * fraction))
        let countdown = GoalCountdown(start: start, deadline: deadline, now: now)
        return EmojiMood.resolve(countdown: countdown, thresholds: thresholds)
    }

    @Test("Default thresholds produce every mood")
    func defaultMoods() {
        #expect(mood(remainingFraction: 1.0) == .calm)
        #expect(mood(remainingFraction: 0.99) == .calm)
        #expect(mood(remainingFraction: 0.60) == .steady)
        #expect(mood(remainingFraction: 0.30) == .focus)
        #expect(mood(remainingFraction: 0.15) == .intense)
        #expect(mood(remainingFraction: 0.05) == .urgent)
    }

    @Test("Threshold boundaries are deterministic")
    func boundaries() {
        #expect(mood(remainingFraction: 0.76) == .calm)
        #expect(mood(remainingFraction: 0.75) == .steady)
        #expect(mood(remainingFraction: 0.51) == .steady)
        #expect(mood(remainingFraction: 0.50) == .focus)
        #expect(mood(remainingFraction: 0.26) == .focus)
        #expect(mood(remainingFraction: 0.25) == .intense)
        #expect(mood(remainingFraction: 0.11) == .intense)
        #expect(mood(remainingFraction: 0.10) == .urgent)
        #expect(mood(remainingFraction: 0.001) == .urgent)
    }

    @Test("A passed deadline is always completion, even at 0% thresholds")
    func completionWins() {
        let start = TestDates.date(2026, 1, 1)
        let deadline = start.addingTimeInterval(100)
        let countdown = GoalCountdown(start: start, deadline: deadline, now: deadline.addingTimeInterval(1))
        #expect(EmojiMood.resolve(countdown: countdown) == .complete)
    }

    @Test("Custom thresholds move the mood boundaries")
    func customThresholds() {
        let custom = EmojiThresholds(calm: 0.90, steady: 0.70, focus: 0.40, intense: 0.20)
        #expect(mood(remainingFraction: 0.80, thresholds: custom) == .steady)
        #expect(mood(remainingFraction: 0.50, thresholds: custom) == .focus)
        #expect(mood(remainingFraction: 0.30, thresholds: custom) == .intense)
        #expect(mood(remainingFraction: 0.15, thresholds: custom) == .urgent)
    }

    @Test("Invalid thresholds fall back to defaults rather than misbehaving")
    func invalidThresholds() {
        let invalid = EmojiThresholds(calm: 0.25, steady: 0.75, focus: 0.50, intense: 0.10)
        #expect(!invalid.isValid)
        #expect(invalid.sanitized() == .standard)
        #expect(mood(remainingFraction: 0.80, thresholds: invalid) == .calm)
    }

    @Test("Every mood has emoji and motivational copy")
    func copyIsPresent() {
        for mood in EmojiMood.allCases {
            #expect(!mood.defaultEmoji.isEmpty)
            #expect(!mood.title.isEmpty)
            #expect(!mood.motivation.isEmpty)
        }
    }

    @Test("A custom goal emoji is used while running, trophy on completion")
    func customGoalEmoji() {
        let start = TestDates.date(2026, 1, 1)
        let goal = Goal(
            title: "Read 12 books",
            startDate: start,
            deadline: start.addingTimeInterval(100_000),
            emoji: "📚"
        )
        #expect(goal.displayEmoji(for: .focus) == "📚")
        #expect(goal.displayEmoji(for: .complete) == "🏆")
    }
}
