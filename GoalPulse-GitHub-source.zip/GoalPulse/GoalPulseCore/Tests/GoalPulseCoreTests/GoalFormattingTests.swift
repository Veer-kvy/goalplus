import Foundation
import Testing
@testable import GoalPulseCore

@Suite("Formatting")
struct GoalFormattingTests {
    private func countdown(days: Int, hours: Int, minutes: Int, seconds: Int, complete: Bool = false) -> GoalCountdown {
        let start = TestDates.date(2026, 1, 1)
        let total = TimeInterval(days * 86_400 + hours * 3_600 + minutes * 60 + seconds)
        let deadline = start.addingTimeInterval(max(total, 1))
        let now = complete ? deadline : start
        return GoalCountdown(start: start, deadline: deadline, now: now)
    }

    @Test("The canonical full format is exact")
    func fullFormat() {
        let value = countdown(days: 125, hours: 14, minutes: 32, seconds: 48)
        #expect(GoalFormatting.fullCountdown(value) == "125 Days : 14 Hours : 32 Minutes : 48 Seconds")
        #expect(
            GoalFormatting.fullCountdown(days: 1, hours: 2, minutes: 3, seconds: 4)
                == "1 Days : 2 Hours : 3 Minutes : 4 Seconds"
        )
    }

    @Test("Compact and clock formats")
    func alternateFormats() {
        let value = countdown(days: 5, hours: 4, minutes: 3, seconds: 2)
        #expect(GoalFormatting.compactCountdown(value) == "5d 4h 3m 2s")
        #expect(GoalFormatting.clockCountdown(value) == "05:04:03:02")
        #expect(GoalFormatting.countdown(value, format: .compact) == "5d 4h 3m 2s")
        #expect(GoalFormatting.countdown(value, format: .inline).contains("Days"))
    }

    @Test("Menu bar text is compact and reveals seconds only near the end")
    func menuBarFormat() {
        #expect(GoalFormatting.menuBarCountdown(countdown(days: 125, hours: 14, minutes: 32, seconds: 48)) == "125d 14h")
        #expect(GoalFormatting.menuBarCountdown(countdown(days: 0, hours: 5, minutes: 4, seconds: 3)) == "5h 4m")
        #expect(GoalFormatting.menuBarCountdown(countdown(days: 0, hours: 0, minutes: 4, seconds: 3)) == "4m 3s")
        #expect(GoalFormatting.menuBarCountdown(countdown(days: 0, hours: 0, minutes: 0, seconds: 3)) == "3s")
        #expect(GoalFormatting.menuBarCountdown(countdown(days: 0, hours: 0, minutes: 0, seconds: 0, complete: true)) == "Done")
    }

    @Test("Durations use two useful units")
    func durations() {
        #expect(GoalFormatting.duration(0) == "0s")
        #expect(GoalFormatting.duration(45) == "45s")
        #expect(GoalFormatting.duration(125) == "2m 5s")
        #expect(GoalFormatting.duration(3 * 3_600 + 25 * 60) == "3h 25m")
        #expect(GoalFormatting.duration(124 * 86_400 + 4 * 3_600 + 59) == "124d 4h")
    }

    @Test("Percentages are clamped and rounded")
    func percentages() {
        #expect(GoalFormatting.percent(-0.2) == "0%")
        #expect(GoalFormatting.percent(0.0) == "0%")
        #expect(GoalFormatting.percent(0.126) == "13%")
        #expect(GoalFormatting.percent(1.5) == "100%")
    }

    @Test("Accessibility text spells out units")
    func accessibilityText() {
        let value = countdown(days: 2, hours: 1, minutes: 0, seconds: 5)
        let text = GoalFormatting.accessibilityCountdown(value)
        #expect(text.contains("2 days"))
        #expect(text.contains("1 hour"))
        #expect(text.contains("5 seconds"))
        #expect(text.hasSuffix("remaining"))
    }
}
