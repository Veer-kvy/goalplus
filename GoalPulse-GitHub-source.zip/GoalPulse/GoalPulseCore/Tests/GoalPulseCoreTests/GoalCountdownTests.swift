import Foundation
import Testing
@testable import GoalPulseCore

@Suite("Goal countdown")
struct GoalCountdownTests {
    @Test("A deadline months away breaks down into days, hours, minutes and seconds")
    func monthsAway() {
        let start = TestDates.date(2026, 1, 1, 9, 0, 0)
        let deadline = start.addingTimeInterval(125 * 86_400 + 14 * 3_600 + 32 * 60 + 48)
        let countdown = GoalCountdown(start: start, deadline: deadline, now: start)

        #expect(countdown.days == 125)
        #expect(countdown.hours == 14)
        #expect(countdown.minutes == 32)
        #expect(countdown.seconds == 48)
        #expect(countdown.phase == .running)
        #expect(countdown.progress == 0)
        #expect(countdown.remainingFraction == 1)
    }

    @Test("A deadline less than one day away")
    func lessThanOneDay() {
        let now = TestDates.date(2026, 6, 14, 8, 0, 0)
        let deadline = now.addingTimeInterval(6 * 3_600 + 12 * 60 + 8)
        let countdown = GoalCountdown(start: now.addingTimeInterval(-86_400), deadline: deadline, now: now)

        #expect(countdown.days == 0)
        #expect(countdown.hours == 6)
        #expect(countdown.minutes == 12)
        #expect(countdown.seconds == 8)
    }

    @Test("A deadline a few seconds away counts down without drifting")
    func fewSeconds() {
        let now = TestDates.date(2026, 3, 3, 12, 0, 0)
        let deadline = now.addingTimeInterval(5)
        let countdown = GoalCountdown(start: now, deadline: deadline, now: now)

        #expect(countdown.seconds == 5)
        #expect(countdown.remaining == 5)
        #expect(countdown.progress == 0)
    }

    @Test("A completed goal clamps to zero and full progress")
    func completed() {
        let start = TestDates.date(2026, 1, 1)
        let deadline = start.addingTimeInterval(3_600)
        let now = deadline.addingTimeInterval(9_000)
        let countdown = GoalCountdown(start: start, deadline: deadline, now: now)

        #expect(countdown.phase == .complete)
        #expect(countdown.isComplete)
        #expect(countdown.remaining == 0)
        #expect(countdown.days == 0)
        #expect(countdown.hours == 0)
        #expect(countdown.minutes == 0)
        #expect(countdown.seconds == 0)
        #expect(countdown.progress == 1)
        #expect(countdown.remainingFraction == 0)
    }

    @Test("The exact deadline instant is complete")
    func exactDeadline() {
        let start = TestDates.date(2026, 1, 1)
        let deadline = start.addingTimeInterval(100)
        let countdown = GoalCountdown(start: start, deadline: deadline, now: deadline)

        #expect(countdown.phase == .complete)
        #expect(countdown.remaining == 0)
    }

    @Test("A future start is upcoming and has no elapsed time")
    func futureStart() {
        let now = TestDates.date(2026, 7, 1)
        let start = now.addingTimeInterval(3 * 86_400)
        let deadline = start.addingTimeInterval(7 * 86_400)
        let countdown = GoalCountdown(start: start, deadline: deadline, now: now)

        #expect(countdown.phase == .upcoming)
        #expect(countdown.elapsed == 0)
        #expect(countdown.progress == 0)
        #expect(countdown.remainingFraction == 1)
        #expect(countdown.remaining == deadline.timeIntervalSince(now))
        #expect(countdown.days == 10)
    }

    @Test("Elapsed and progress are clamped to the goal window")
    func clamping() {
        let start = TestDates.date(2026, 1, 1)
        let deadline = start.addingTimeInterval(100)
        let midway = GoalCountdown(start: start, deadline: deadline, now: start.addingTimeInterval(25))
        let late = GoalCountdown(start: start, deadline: deadline, now: start.addingTimeInterval(1_000))

        #expect(abs(midway.progress - 0.25) < 0.000_001)
        #expect(abs(midway.remainingFraction - 0.75) < 0.000_001)
        #expect(late.progress == 1)
        #expect(late.elapsed == 100)
    }

    @Test("Leap years use real calendar instants")
    func leapYear() {
        let leapStart = TestDates.date(2028, 2, 28)
        let leapDeadline = TestDates.date(2028, 3, 1)
        let leap = GoalCountdown(start: leapStart, deadline: leapDeadline, now: leapStart)

        let normalStart = TestDates.date(2027, 2, 28)
        let normalDeadline = TestDates.date(2027, 3, 1)
        let normal = GoalCountdown(start: normalStart, deadline: normalDeadline, now: normalStart)

        #expect(leap.totalDuration == 2 * 86_400)
        #expect(leap.days == 2)
        #expect(normal.totalDuration == 86_400)
        #expect(normal.days == 1)
    }

    @Test("A DST spring-forward day is 23 hours, not an inaccurate 24")
    func daylightSavingSpringForward() {
        var newYork = Calendar(identifier: .gregorian)
        newYork.timeZone = TimeZone(identifier: "America/New_York") ?? .gmt
        let start = TestDates.date(2026, 3, 7, 12, 0, 0, calendar: newYork)
        let deadline = TestDates.date(2026, 3, 9, 12, 0, 0, calendar: newYork)
        let countdown = GoalCountdown(start: start, deadline: deadline, now: start)

        #expect(countdown.totalDuration == 47 * 3_600)
        #expect(countdown.days == 1)
        #expect(countdown.hours == 23)
    }

    @Test("Time-zone labels do not change absolute countdown math")
    func timeZoneIndependence() {
        // The same two instants as seen from two different local time zones.
        var tokyo = Calendar(identifier: .gregorian)
        tokyo.timeZone = TimeZone(identifier: "Asia/Tokyo") ?? .gmt
        let start = TestDates.date(2026, 11, 1, 9, 30, 0, calendar: tokyo)
        let deadline = start.addingTimeInterval(90_061)
        let countdown = GoalCountdown(start: start, deadline: deadline, now: start)
        #expect(countdown.days == 1)
        #expect(countdown.hours == 1)
        #expect(countdown.minutes == 1)
        #expect(countdown.totalDuration == 90_061)
    }

    @Test("An inverted range cannot produce negative values")
    func invertedRange() {
        let start = TestDates.date(2026, 5, 1, 12)
        let deadline = start.addingTimeInterval(-3_600)
        let countdown = GoalCountdown(start: start, deadline: deadline, now: start.addingTimeInterval(-7_200))

        #expect(countdown.totalDuration == 0)
        #expect(countdown.elapsed == 0)
        #expect(countdown.remaining == 3_600)
        #expect(countdown.remainingFraction == 1)
        #expect(countdown.progress == 0)
    }
}
