import Foundation
import Testing
@testable import GoalPulseCore

@Suite("Date and time merging")
struct DateTimeMergerTests {
    @Test("Date and time pickers combine into one instant")
    func combineRegular() {
        let date = TestDates.date(2026, 10, 25, 0, 0)
        let time = TestDates.date(2001, 1, 1, 19, 45, 30)
        let combined = DateTimeMerger.combine(date: date, time: time, calendar: TestDates.utcCalendar)
        let parts = TestDates.utcCalendar.dateComponents([.year, .month, .day, .hour, .minute, .second], from: combined)

        #expect(parts.year == 2026)
        #expect(parts.month == 10)
        #expect(parts.day == 25)
        #expect(parts.hour == 19)
        #expect(parts.minute == 45)
        #expect(parts.second == 30)
    }

    @Test("A non-existent DST wall time still yields a real instant on that day")
    func springForward() {
        var newYork = Calendar(identifier: .gregorian)
        newYork.timeZone = TimeZone(identifier: "America/New_York") ?? .gmt
        let date = TestDates.date(2026, 3, 8, 0, 0, calendar: newYork)
        let time = TestDates.date(2026, 3, 8, 2, 30, 0, calendar: newYork)
        let combined = DateTimeMerger.combine(date: date, time: time, calendar: newYork)
        let parts = newYork.dateComponents([.year, .month, .day], from: combined)

        #expect(parts.year == 2026)
        #expect(parts.month == 3)
        #expect(parts.day == 8)
        #expect(combined > newYork.startOfDay(for: date))
    }

    @Test("An ambiguous DST wall time resolves to a stable instant")
    func fallBack() {
        var newYork = Calendar(identifier: .gregorian)
        newYork.timeZone = TimeZone(identifier: "America/New_York") ?? .gmt
        let date = TestDates.date(2026, 11, 1, 0, 0, calendar: newYork)
        let time = TestDates.date(2026, 11, 1, 1, 30, 0, calendar: newYork)
        let first = DateTimeMerger.combine(date: date, time: time, calendar: newYork)
        let second = DateTimeMerger.combine(date: date, time: time, calendar: newYork)

        #expect(first == second)
        #expect(newYork.component(.hour, from: first) == 1)
    }

    @Test("Rounding to the next minute removes seconds")
    func rounding() {
        let date = TestDates.date(2026, 1, 1, 12, 30, 20)
        let rounded = DateTimeMerger.roundingUpToMinute(date, calendar: TestDates.utcCalendar)
        let parts = TestDates.utcCalendar.dateComponents([.hour, .minute, .second], from: rounded)

        #expect(parts.hour == 12)
        #expect(parts.minute == 31)
        #expect(parts.second == 0)
    }
}
