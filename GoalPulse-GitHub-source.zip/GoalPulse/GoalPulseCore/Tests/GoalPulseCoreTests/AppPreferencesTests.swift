import Foundation
import Testing
@testable import GoalPulseCore

@Suite("Preferences")
struct AppPreferencesTests {
    @Test("Defaults match the product specification")
    func defaults() {
        let preferences = AppPreferences()
        #expect(preferences.menuBarDisplayMode == .emojiAndCountdown)
        #expect(preferences.countdownFormat == .segmented)
        #expect(preferences.thresholds == .standard)
        #expect(preferences.animationIntensity == .balanced)
        #expect(!preferences.notificationsEnabled)
        #expect(preferences.notificationMilestones == Set(NotificationMilestone.allCases))
        #expect(preferences.theme == .system)
        #expect(!preferences.reduceMotion)
    }

    @Test("Preferences round-trip through JSON")
    func roundTrip() throws {
        var preferences = AppPreferences()
        preferences.menuBarDisplayMode = .countdownOnly
        preferences.countdownFormat = .compact
        preferences.thresholds = EmojiThresholds(calm: 0.8, steady: 0.6, focus: 0.3, intense: 0.15)
        preferences.animationIntensity = .subtle
        preferences.notificationsEnabled = true
        preferences.notificationMilestones = [.oneDay, .tenMinutes]
        preferences.theme = .dark
        preferences.reduceMotion = true

        let data = try JSONEncoder().encode(preferences)
        let decoded = try JSONDecoder().decode(AppPreferences.self, from: data)
        #expect(decoded == preferences)
    }

    @Test("Missing fields decode to defaults")
    func missingFields() throws {
        let json = Data(#"{"theme":"dark"}"#.utf8)
        let decoded = try JSONDecoder().decode(AppPreferences.self, from: json)
        #expect(decoded.theme == .dark)
        #expect(decoded.menuBarDisplayMode == .emojiAndCountdown)
        #expect(decoded.thresholds == .standard)
    }

    @Test("Corrupt threshold values are sanitized")
    func sanitizeThresholds() {
        var preferences = AppPreferences()
        preferences.thresholds = EmojiThresholds(calm: 0.1, steady: 0.2, focus: 0.3, intense: 0.4)
        let sanitized = preferences.sanitized()
        #expect(sanitized.thresholds == .standard)
    }

    @Test("Thresholds must be ordered")
    func thresholdOrdering() {
        #expect(EmojiThresholds.standard.isValid)
        #expect(!EmojiThresholds(calm: 0.5, steady: 0.6, focus: 0.25, intense: 0.1).isValid)
        #expect(!EmojiThresholds(calm: 1.2, steady: 0.5, focus: 0.25, intense: 0.1).isValid)
        #expect(!EmojiThresholds(calm: 0.75, steady: 0.5, focus: 0.25, intense: 0).isValid)
    }
}
