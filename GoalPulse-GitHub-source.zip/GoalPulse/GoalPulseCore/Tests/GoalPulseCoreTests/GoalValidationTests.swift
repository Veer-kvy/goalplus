import Foundation
import Testing
@testable import GoalPulseCore

@Suite("Goal validation")
struct GoalValidationTests {
    private let start = TestDates.date(2026, 1, 1, 9, 0)

    @Test("A normal goal is valid")
    func validGoal() {
        let result = GoalValidation.validate(
            title: "Learn SwiftUI",
            details: "Ship a menu bar app",
            startDate: start,
            deadline: start.addingTimeInterval(86_400),
            emoji: "🎯"
        )
        #expect(result.isValid)
    }

    @Test("Empty and whitespace-only titles are rejected")
    func emptyTitles() {
        #expect(GoalValidation.validate(title: "", startDate: start, deadline: start.addingTimeInterval(60)).firstError == .emptyTitle)
        #expect(GoalValidation.validate(title: "   \n", startDate: start, deadline: start.addingTimeInterval(60)).firstError == .emptyTitle)
    }

    @Test("Overlong content is rejected")
    func lengthLimits() {
        let longTitle = String(repeating: "a", count: GoalValidation.maxTitleLength + 1)
        let longDetails = String(repeating: "b", count: GoalValidation.maxDetailsLength + 1)
        #expect(GoalValidation.validate(title: longTitle, startDate: start, deadline: start.addingTimeInterval(60)).firstError == .titleTooLong)
        #expect(GoalValidation.validate(title: "Fine", details: longDetails, startDate: start, deadline: start.addingTimeInterval(60)).firstError == .detailsTooLong)
        #expect(GoalValidation.validate(title: "Fine", startDate: start, deadline: start.addingTimeInterval(60), emoji: "😀😀😀😀😀😀😀😀😀").firstError == .emojiTooLong)
    }

    @Test("The deadline must be strictly after the start")
    func deadlineOrdering() {
        #expect(GoalValidation.validate(title: "Equal", startDate: start, deadline: start).firstError == .deadlineNotAfterStart)
        #expect(GoalValidation.validate(title: "Before", startDate: start, deadline: start.addingTimeInterval(-1)).firstError == .deadlineNotAfterStart)
        #expect(GoalValidation.validate(title: "After", startDate: start, deadline: start.addingTimeInterval(1)).isValid)
    }

    @Test("A past goal with a valid range is accepted")
    func pastGoal() {
        let result = GoalValidation.validate(
            title: "Completed history",
            startDate: start.addingTimeInterval(-86_400),
            deadline: start.addingTimeInterval(-3_600)
        )
        #expect(result.isValid)
    }

    @Test("Multiple errors are collected")
    func multipleErrors() {
        let result = GoalValidation.validate(title: "", startDate: start, deadline: start)
        #expect(result.errors.count == 2)
        #expect(result.errors.contains(.emptyTitle))
        #expect(result.errors.contains(.deadlineNotAfterStart))
    }

    @Test("Goal helpers expose validation and trimmed values")
    func goalHelpers() {
        let goal = Goal(
            title: "  Morning run  ",
            details: "  5 km  ",
            startDate: start,
            deadline: start.addingTimeInterval(60),
            emoji: "  🏃  "
        )
        #expect(goal.isValid)
        #expect(goal.trimmedTitle == "Morning run")
        #expect(goal.trimmedDetails == "5 km")
        #expect(goal.trimmedEmoji == "🏃")
    }
}
