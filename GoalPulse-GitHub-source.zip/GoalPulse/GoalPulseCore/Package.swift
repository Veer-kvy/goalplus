// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "GoalPulseCore",
    platforms: [.macOS(.v14)],
    products: [
        .library(name: "GoalPulseCore", targets: ["GoalPulseCore"])
    ],
    targets: [
        .target(
            name: "GoalPulseCore",
            path: "Sources/GoalPulseCore"
        ),
        .testTarget(
            name: "GoalPulseCoreTests",
            dependencies: ["GoalPulseCore"],
            path: "Tests/GoalPulseCoreTests"
        )
    ],
    swiftLanguageModes: [.v5]
)
