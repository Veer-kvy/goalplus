import Foundation

public enum GoalValidationError: Error, Equatable, Hashable, Sendable, LocalizedError {
    case emptyTitle
    case titleTooLong
    case detailsTooLong
    case emojiTooLong
    case deadlineNotAfterStart

    public var errorDescription: String? {
        switch self {
        case .emptyTitle:
            return "Give your goal a title."
        case .titleTooLong:
            return "Keep the title to \(GoalValidation.maxTitleLength) characters or fewer."
        case .detailsTooLong:
            return "Keep the description to \(GoalValidation.maxDetailsLength) characters or fewer."
        case .emojiTooLong:
            return "Use a single, short emoji."
        case .deadlineNotAfterStart:
            return "The deadline must be after the start date and time."
        }
    }
}

public struct GoalValidationResult: Equatable, Sendable {
    public let errors: [GoalValidationError]

    public init(errors: [GoalValidationError]) {
        self.errors = errors
    }

    public var isValid: Bool { errors.isEmpty }
    public var firstError: GoalValidationError? { errors.first }
}

public enum GoalValidation {
    public static let maxTitleLength = 80
    public static let maxDetailsLength = 500
    public static let maxEmojiCharacters = 8

    public static func validate(
        title: String,
        details: String = "",
        startDate: Date,
        deadline: Date,
        emoji: String? = nil
    ) -> GoalValidationResult {
        var errors: [GoalValidationError] = []

        let trimmedTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedTitle.isEmpty {
            errors.append(.emptyTitle)
        } else if trimmedTitle.count > maxTitleLength {
            errors.append(.titleTooLong)
        }

        if details.trimmingCharacters(in: .whitespacesAndNewlines).count > maxDetailsLength {
            errors.append(.detailsTooLong)
        }

        let trimmedEmoji = emoji?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if trimmedEmoji.count > maxEmojiCharacters {
            errors.append(.emojiTooLong)
        }

        if deadline <= startDate {
            errors.append(.deadlineNotAfterStart)
        }

        return GoalValidationResult(errors: errors)
    }

    /// Validation used when loading persisted data. Goals that fail these
    /// checks are skipped rather than crashing or rendering nonsensical math.
    public static func isPersistable(_ goal: Goal) -> Bool {
        goal.isValid
    }
}
