import Foundation

/// An immutable snapshot of a goal at a specific instant.
///
/// The countdown is always derived from real date arithmetic against
/// `deadline`, never from a decrementing counter, so it cannot drift. A timer
/// only decides *when* to ask for a fresh snapshot. Because Foundation dates
/// are absolute instants, leap days, time-zone changes and DST transitions
/// do not corrupt the calculation.
public struct GoalCountdown: Equatable, Sendable {
    public enum Phase: String, Equatable, Sendable {
        case upcoming
        case running
        case complete
    }

    public let now: Date
    public let startDate: Date
    public let deadline: Date
    public let totalDuration: TimeInterval
    public let elapsed: TimeInterval
    public let remaining: TimeInterval
    public let progress: Double
    public let remainingFraction: Double
    public let phase: Phase

    public let days: Int
    public let hours: Int
    public let minutes: Int
    public let seconds: Int

    public init(start: Date, deadline: Date, now: Date = Date()) {
        let total = max(0, deadline.timeIntervalSince(start))
        let clampedElapsed = min(total, max(0, now.timeIntervalSince(start)))
        let clampedRemaining = max(0, deadline.timeIntervalSince(now))

        let phase: Phase
        if now >= deadline {
            phase = .complete
        } else if now < start {
            phase = .upcoming
        } else {
            phase = .running
        }

        let progress: Double
        let remainingFraction: Double
        if total > 0 {
            progress = Self.clamp(clampedElapsed / total)
            remainingFraction = phase == .complete ? 0 : Self.clamp(clampedRemaining / total)
        } else {
            progress = phase == .complete ? 1 : 0
            remainingFraction = phase == .complete ? 0 : 1
        }

        // Countdowns conventionally truncate partial seconds. The goal is only
        // marked complete once `now` reaches the deadline.
        let wholeSeconds = Int(clampedRemaining.rounded(.down))
        self.days = wholeSeconds / 86_400
        self.hours = (wholeSeconds % 86_400) / 3_600
        self.minutes = (wholeSeconds % 3_600) / 60
        self.seconds = wholeSeconds % 60

        self.now = now
        self.startDate = start
        self.deadline = deadline
        self.totalDuration = total
        self.elapsed = clampedElapsed
        self.remaining = clampedRemaining
        self.progress = progress
        self.remainingFraction = remainingFraction
        self.phase = phase
    }

    public var isComplete: Bool { phase == .complete }
    public var isUpcoming: Bool { phase == .upcoming }
    public var progressPercentage: Double { progress * 100 }
    public var remainingPercentage: Double { remainingFraction * 100 }

    public static func clamp(_ value: Double, lower: Double = 0, upper: Double = 1) -> Double {
        guard value.isFinite else { return lower }
        return min(upper, max(lower, value))
    }
}
