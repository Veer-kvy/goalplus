import Foundation

/// How the main countdown is rendered. The menu bar always uses a compact,
/// adaptive representation so it never dominates the system status area.
public enum CountdownFormat: String, CaseIterable, Codable, Identifiable, Sendable {
    case segmented
    case inline
    case compact

    public var id: String { rawValue }
}

public enum MenuBarDisplayMode: String, CaseIterable, Codable, Identifiable, Sendable {
    case emojiAndCountdown
    case emojiOnly
    case countdownOnly

    public var id: String { rawValue }
}

public enum AnimationIntensity: String, CaseIterable, Codable, Identifiable, Sendable {
    case off
    case subtle
    case balanced
    case lively

    public var id: String { rawValue }

    public var scaleAmount: Double {
        switch self {
        case .off: return 0
        case .subtle: return 0.025
        case .balanced: return 0.05
        case .lively: return 0.09
        }
    }

    public var glowAmount: Double {
        switch self {
        case .off: return 0
        case .subtle: return 0.20
        case .balanced: return 0.38
        case .lively: return 0.55
        }
    }
}

public enum ThemePreference: String, CaseIterable, Codable, Identifiable, Sendable {
    case system
    case light
    case dark

    public var id: String { rawValue }
}

/// Foundation-only display helpers for countdowns.
///
/// Keeping these pure and deterministic makes them easy to test and avoids
/// subtle locale-dependent differences between the menu bar and the popover.
public enum GoalFormatting {
    /// The canonical countdown line, for example:
    /// `125 Days : 14 Hours : 32 Minutes : 48 Seconds`.
    public static func fullCountdown(_ countdown: GoalCountdown) -> String {
        "\(countdown.days) Days : \(countdown.hours) Hours : \(countdown.minutes) Minutes : \(countdown.seconds) Seconds"
    }

    public static func fullCountdown(days: Int, hours: Int, minutes: Int, seconds: Int) -> String {
        "\(days) Days : \(hours) Hours : \(minutes) Minutes : \(seconds) Seconds"
    }

    /// `125d 14h 32m 48s`
    public static func compactCountdown(_ countdown: GoalCountdown) -> String {
        "\(countdown.days)d \(countdown.hours)h \(countdown.minutes)m \(countdown.seconds)s"
    }

    /// `125:14:32:48`
    public static func clockCountdown(_ countdown: GoalCountdown) -> String {
        String(
            format: "%02d:%02d:%02d:%02d",
            countdown.days,
            countdown.hours,
            countdown.minutes,
            countdown.seconds
        )
    }

    /// Compact, adaptive menu bar text. Seconds appear only during the last
    /// hour so the label stays quiet while still feeling live near a deadline.
    public static func menuBarCountdown(_ countdown: GoalCountdown) -> String {
        if countdown.isComplete { return "Done" }
        if countdown.days > 0 {
            return "\(countdown.days)d \(countdown.hours)h"
        }
        if countdown.hours > 0 {
            return "\(countdown.hours)h \(countdown.minutes)m"
        }
        if countdown.minutes > 0 {
            return "\(countdown.minutes)m \(countdown.seconds)s"
        }
        return "\(countdown.seconds)s"
    }

    public static func countdown(_ countdown: GoalCountdown, format: CountdownFormat) -> String {
        switch format {
        case .segmented, .inline:
            return fullCountdown(countdown)
        case .compact:
            return compactCountdown(countdown)
        }
    }

    /// Two-unit duration, suitable for “Total” and “Elapsed” rows.
    public static func duration(_ interval: TimeInterval) -> String {
        let totalSeconds = Int(max(0, interval).rounded(.down))
        let days = totalSeconds / 86_400
        let hours = (totalSeconds % 86_400) / 3_600
        let minutes = (totalSeconds % 3_600) / 60
        let seconds = totalSeconds % 60

        if days > 0 { return "\(days)d \(hours)h" }
        if hours > 0 { return "\(hours)h \(minutes)m" }
        if minutes > 0 { return "\(minutes)m \(seconds)s" }
        return "\(seconds)s"
    }

    public static func wholePercent(_ fraction: Double) -> Int {
        Int((GoalCountdown.clamp(fraction) * 100).rounded())
    }

    public static func percent(_ fraction: Double) -> String {
        "\(wholePercent(fraction))%"
    }

    public static func progressAccessibilityValue(_ countdown: GoalCountdown) -> String {
        "\(wholePercent(countdown.progress)) percent complete, \(wholePercent(countdown.remainingFraction)) percent remaining"
    }

    public static func accessibilityCountdown(_ countdown: GoalCountdown) -> String {
        if countdown.isComplete { return "Goal complete" }
        let parts: [(Int, String, String)] = [
            (countdown.days, "day", "days"),
            (countdown.hours, "hour", "hours"),
            (countdown.minutes, "minute", "minutes"),
            (countdown.seconds, "second", "seconds")
        ]
        let text = parts
            .filter { $0.0 != 0 || $0.1 == "second" }
            .map { "\($0.0) \($0.0 == 1 ? $0.1 : $0.2)" }
            .joined(separator: ", ")
        return "\(text) remaining"
    }
}
