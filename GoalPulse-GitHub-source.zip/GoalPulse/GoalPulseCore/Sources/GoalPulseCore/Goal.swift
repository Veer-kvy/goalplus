import Foundation

/// A single goal tracked by GoalPulse.
///
/// Dates are stored as absolute `Date` instants. This keeps countdowns stable
/// across time-zone changes, daylight-saving transitions and leap years: all
/// remaining-time math is performed on the underlying instants, while dates
/// are only localized when they are displayed.
public struct Goal: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var title: String
    public var details: String
    public var startDate: Date
    public var deadline: Date
    public var emoji: String?
    public var accentID: String?
    public var createdAt: Date

    public init(
        id: UUID = UUID(),
        title: String,
        details: String = "",
        startDate: Date,
        deadline: Date,
        emoji: String? = nil,
        accentID: String? = nil,
        createdAt: Date = Date()
    ) {
        self.id = id
        self.title = title
        self.details = details
        self.startDate = startDate
        self.deadline = deadline
        self.emoji = emoji
        self.accentID = accentID
        self.createdAt = createdAt
    }

    public var trimmedTitle: String {
        title.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    public var trimmedDetails: String {
        details.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    public var trimmedEmoji: String? {
        guard let emoji else { return nil }
        let trimmed = emoji.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    /// Total planned duration. Invalid (inverted) goals are clamped to zero so
    /// downstream percentage math can never divide by zero or turn negative.
    public var duration: TimeInterval {
        max(0, deadline.timeIntervalSince(startDate))
    }

    public func countdown(at now: Date = Date()) -> GoalCountdown {
        GoalCountdown(start: startDate, deadline: deadline, now: now)
    }

    public func mood(at now: Date = Date(), thresholds: EmojiThresholds = .standard) -> EmojiMood {
        EmojiMood.resolve(countdown: countdown(at: now), thresholds: thresholds)
    }

    /// Uses the goal's custom emoji when one was supplied, otherwise the
    /// emoji that belongs to the current countdown mood. Completion always
    /// shows the celebration emoji so a finished goal reads as an achievement.
    public func displayEmoji(for mood: EmojiMood) -> String {
        if mood == .complete { return mood.defaultEmoji }
        return trimmedEmoji ?? mood.defaultEmoji
    }

    public var validation: GoalValidationResult {
        GoalValidation.validate(
            title: title,
            details: details,
            startDate: startDate,
            deadline: deadline,
            emoji: emoji
        )
    }

    public var isValid: Bool {
        validation.isValid
    }
}
