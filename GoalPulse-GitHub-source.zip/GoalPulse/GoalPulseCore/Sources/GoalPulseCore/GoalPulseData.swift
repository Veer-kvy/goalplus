import Foundation

/// The on-disk payload. A schema version is stored so future migrations can be
/// applied without guessing at the file's age.
public struct GoalPulseData: Codable, Equatable, Sendable {
    public static let currentSchemaVersion = 1

    public var schemaVersion: Int
    public var goals: [Goal]
    public var activeGoalID: UUID?

    public init(
        schemaVersion: Int = GoalPulseData.currentSchemaVersion,
        goals: [Goal] = [],
        activeGoalID: UUID? = nil
    ) {
        self.schemaVersion = schemaVersion
        self.goals = goals
        self.activeGoalID = activeGoalID
    }

    private enum CodingKeys: String, CodingKey {
        case schemaVersion
        case goals
        case activeGoalID
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        schemaVersion = try container.decodeIfPresent(Int.self, forKey: .schemaVersion)
            ?? GoalPulseData.currentSchemaVersion
        goals = try container.decodeIfPresent([Goal].self, forKey: .goals) ?? []
        activeGoalID = try container.decodeIfPresent(UUID.self, forKey: .activeGoalID)
    }

    public static let empty = GoalPulseData()
}

public struct GoalPulseNormalization: Equatable, Sendable {
    public let data: GoalPulseData
    public let droppedGoals: Int
    public let repairedActiveGoal: Bool

    public init(data: GoalPulseData, droppedGoals: Int, repairedActiveGoal: Bool) {
        self.data = data
        self.droppedGoals = droppedGoals
        self.repairedActiveGoal = repairedActiveGoal
    }
}

extension GoalPulseData {
    /// Drops invalid or duplicate goals, trims titles, and guarantees that the
    /// active goal id either points at a real goal or is `nil`. Running this on
    /// every load keeps a hand-edited or partially corrupt file safe to use.
    public func normalized() -> GoalPulseNormalization {
        var seen = Set<UUID>()
        var validGoals: [Goal] = []
        var dropped = 0

        for var goal in goals {
            guard GoalValidation.isPersistable(goal), !seen.contains(goal.id) else {
                dropped += 1
                continue
            }
            seen.insert(goal.id)
            goal.title = goal.trimmedTitle
            goal.emoji = goal.trimmedEmoji
            goal.details = goal.trimmedDetails
            validGoals.append(goal)
        }

        let repairedActive: Bool
        let repairedID: UUID?
        if let activeGoalID, validGoals.contains(where: { $0.id == activeGoalID }) {
            repairedID = activeGoalID
            repairedActive = false
        } else {
            repairedID = validGoals.first?.id
            repairedActive = validGoals.isEmpty ? (activeGoalID != nil) : true
        }

        let normalized = GoalPulseData(
            schemaVersion: Self.currentSchemaVersion,
            goals: validGoals,
            activeGoalID: repairedID
        )
        return GoalPulseNormalization(
            data: normalized,
            droppedGoals: dropped,
            repairedActiveGoal: repairedActive
        )
    }
}
