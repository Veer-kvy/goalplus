import Foundation

/// Merges the date components of one `Date` with the time components of
/// another. Used by the goal editor, where date and time have separate pickers.
public enum DateTimeMerger {
    /// - Parameters:
    ///   - date: Supplies year, month and day in `calendar`'s time zone.
    ///   - time: Supplies hour, minute and second.
    ///   - calendar: The calendar (and thus time zone) in which to interpret
    ///     both values.
    /// - Returns: A valid `Date`, even for wall-clock times that do not exist
    ///   because of a spring-forward DST transition. In that rare case the
    ///   system's normalized instant is used.
    public static func combine(date: Date, time: Date, calendar: Calendar = .current) -> Date {
        let dateParts = calendar.dateComponents([.year, .month, .day], from: date)
        let timeParts = calendar.dateComponents([.hour, .minute, .second], from: time)

        var components = DateComponents()
        components.calendar = calendar
        components.timeZone = calendar.timeZone
        components.year = dateParts.year
        components.month = dateParts.month
        components.day = dateParts.day
        components.hour = timeParts.hour
        components.minute = timeParts.minute
        components.second = timeParts.second

        if let combined = calendar.date(from: components) {
            return combined
        }

        // A non-existent wall time (e.g. 02:30 on the spring-forward day).
        // Falling back to an offset from the start of the day always yields a
        // real instant instead of failing or jumping to another day.
        let secondsIntoDay = (timeParts.hour ?? 0) * 3_600
            + (timeParts.minute ?? 0) * 60
            + (timeParts.second ?? 0)
        let startOfDay = calendar.startOfDay(for: date)
        return calendar.date(byAdding: .second, value: secondsIntoDay, to: startOfDay) ?? date
    }

    /// Rounds a date up to the next whole minute. New goals get tidy start and
    /// deadline defaults without surprising second-level values.
    public static func roundingUpToMinute(_ date: Date, calendar: Calendar = .current) -> Date {
        let seconds = calendar.component(.second, from: date)
        guard seconds != 0 else {
            return calendar.date(bySetting: .nanosecond, value: 0, of: date) ?? date
        }
        let startOfMinute = calendar.date(byAdding: .second, value: -seconds, to: date) ?? date
        return calendar.date(byAdding: .minute, value: 1, to: startOfMinute) ?? date
    }
}
