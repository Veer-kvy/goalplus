import Foundation

/// Persisted user preferences. This type is kept Foundation-only so it can be
/// validated in tests without booting AppKit or user defaults.
public struct AppPreferences: Codable, Equatable, Sendable {
    public var menuBarDisplayMode: MenuBarDisplayMode
    public var countdownFormat: CountdownFormat
    public var thresholds: EmojiThresholds
    public var animationIntensity: AnimationIntensity
    public var notificationsEnabled: Bool
    public var notificationMilestones: Set<NotificationMilestone>
    public var theme: ThemePreference
    public var reduceMotion: Bool

    public init(
        menuBarDisplayMode: MenuBarDisplayMode = .emojiAndCountdown,
        countdownFormat: CountdownFormat = .segmented,
        thresholds: EmojiThresholds = .standard,
        animationIntensity: AnimationIntensity = .balanced,
        notificationsEnabled: Bool = false,
        notificationMilestones: Set<NotificationMilestone> = Set(NotificationMilestone.allCases),
        theme: ThemePreference = .system,
        reduceMotion: Bool = false
    ) {
        self.menuBarDisplayMode = menuBarDisplayMode
        self.countdownFormat = countdownFormat
        self.thresholds = thresholds
        self.animationIntensity = animationIntensity
        self.notificationsEnabled = notificationsEnabled
        self.notificationMilestones = notificationMilestones
        self.theme = theme
        self.reduceMotion = reduceMotion
    }

    private enum CodingKeys: String, CodingKey {
        case menuBarDisplayMode
        case countdownFormat
        case thresholds
        case animationIntensity
        case notificationsEnabled
        case notificationMilestones
        case theme
        case reduceMotion
    }

    /// Defaults per key make settings forward- and backward-compatible as new
    /// preferences are added.
    public init(from decoder: Decoder) throws {
        let defaults = AppPreferences()
        let container = try decoder.container(keyedBy: CodingKeys.self)
        menuBarDisplayMode = try container.decodeIfPresent(MenuBarDisplayMode.self, forKey: .menuBarDisplayMode) ?? defaults.menuBarDisplayMode
        countdownFormat = try container.decodeIfPresent(CountdownFormat.self, forKey: .countdownFormat) ?? defaults.countdownFormat
        thresholds = try container.decodeIfPresent(EmojiThresholds.self, forKey: .thresholds) ?? defaults.thresholds
        animationIntensity = try container.decodeIfPresent(AnimationIntensity.self, forKey: .animationIntensity) ?? defaults.animationIntensity
        notificationsEnabled = try container.decodeIfPresent(Bool.self, forKey: .notificationsEnabled) ?? defaults.notificationsEnabled
        notificationMilestones = try container.decodeIfPresent(Set<NotificationMilestone>.self, forKey: .notificationMilestones) ?? defaults.notificationMilestones
        theme = try container.decodeIfPresent(ThemePreference.self, forKey: .theme) ?? defaults.theme
        reduceMotion = try container.decodeIfPresent(Bool.self, forKey: .reduceMotion) ?? defaults.reduceMotion
    }

    /// Repairs values that were corrupted or made obsolete on disk.
    public func sanitized() -> AppPreferences {
        var copy = self
        copy.thresholds = thresholds.isValid ? thresholds : .standard
        copy.notificationMilestones = notificationMilestones.intersection(Set(NotificationMilestone.allCases))
        return copy
    }
}
