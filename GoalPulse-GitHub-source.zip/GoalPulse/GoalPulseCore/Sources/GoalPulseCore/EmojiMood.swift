import Foundation

/// The emotional phase of a countdown. Moods drive the animated emoji, accent
/// color, progress bar treatment and the short motivational copy in the UI.
public enum EmojiMood: String, CaseIterable, Codable, Identifiable, Sendable {
    case calm
    case steady
    case focus
    case intense
    case urgent
    case complete

    public var id: String { rawValue }

    public var defaultEmoji: String {
        switch self {
        case .calm: return "😎"
        case .steady: return "🙂"
        case .focus: return "🎯"
        case .intense: return "🔥"
        case .urgent: return "🚨"
        case .complete: return "🏆"
        }
    }

    public var title: String {
        switch self {
        case .calm: return "Calm"
        case .steady: return "Steady"
        case .focus: return "Focus"
        case .intense: return "Intense"
        case .urgent: return "Urgent"
        case .complete: return "Complete"
        }
    }

    public var headline: String {
        switch self {
        case .calm: return "Plenty of runway"
        case .steady: return "Building momentum"
        case .focus: return "Time to focus"
        case .intense: return "The finish line is close"
        case .urgent: return "Final push"
        case .complete: return "Goal complete"
        }
    }

    public var motivation: String {
        switch self {
        case .calm: return "You have room to plan well. Start with one meaningful step."
        case .steady: return "Keep showing up. Small, consistent work is compounding."
        case .focus: return "Protect your next block of deep work — it matters now."
        case .intense: return "Momentum beats perfection. Finish the most important thing first."
        case .urgent: return "It is time to close the loop. Remove distractions and finish strong."
        case .complete: return "You crossed the line. Take a moment to appreciate the effort."
        }
    }

    /// Resolves the mood from the percentage of the total goal duration that
    /// remains. A finished goal is always `complete` regardless of thresholds.
    public static func resolve(
        countdown: GoalCountdown,
        thresholds: EmojiThresholds = .standard
    ) -> EmojiMood {
        if countdown.isComplete { return .complete }
        let t = thresholds.isValid ? thresholds : .standard
        let fraction = countdown.remainingFraction
        if fraction > t.calm { return .calm }
        if fraction > t.steady { return .steady }
        if fraction > t.focus { return .focus }
        if fraction > t.intense { return .intense }
        return .urgent
    }
}

/// Percentage-of-time-remaining boundaries for each mood.
///
/// Values are fractions in `0...1`, ordered so that:
/// `intense < focus < steady < calm`. A goal enters a mood when more than the
/// corresponding fraction remains. Below `intense`, the goal is urgent.
public struct EmojiThresholds: Codable, Equatable, Sendable {
    public var calm: Double
    public var steady: Double
    public var focus: Double
    public var intense: Double

    public init(calm: Double = 0.75, steady: Double = 0.50, focus: Double = 0.25, intense: Double = 0.10) {
        self.calm = calm
        self.steady = steady
        self.focus = focus
        self.intense = intense
    }

    public static let standard = EmojiThresholds()

    public var isValid: Bool {
        let values = [intense, focus, steady, calm]
        guard values.allSatisfy({ $0.isFinite && $0 > 0 && $0 <= 1 }) else { return false }
        return intense < focus && focus < steady && steady < calm
    }

    /// Clamps an arbitrary (for example, hand-edited) set of values into a
    /// valid, ordered threshold set. Useful for defensive settings loading.
    public func sanitized() -> EmojiThresholds {
        guard isValid else { return .standard }
        return self
    }

    public func mood(for countdown: GoalCountdown) -> EmojiMood {
        EmojiMood.resolve(countdown: countdown, thresholds: self)
    }
}
