import Foundation

public enum NotificationMilestone: String, CaseIterable, Codable, Identifiable, Sendable {
    case sevenDays
    case oneDay
    case oneHour
    case tenMinutes

    public var id: String { rawValue }

    public var seconds: TimeInterval {
        switch self {
        case .sevenDays: return 7 * 86_400
        case .oneDay: return 86_400
        case .oneHour: return 3_600
        case .tenMinutes: return 600
        }
    }

    /// Largest milestone first, which is also chronological when planning.
    public static let ordered: [NotificationMilestone] = [.sevenDays, .oneDay, .oneHour, .tenMinutes]
}

public struct PlannedMilestone: Identifiable, Equatable, Sendable {
    public let goal: Goal
    public let milestone: NotificationMilestone
    public let fireDate: Date

    public var id: String {
        "\(goal.id.uuidString).\(milestone.rawValue)"
    }

    public init(goal: Goal, milestone: NotificationMilestone, fireDate: Date) {
        self.goal = goal
        self.milestone = milestone
        self.fireDate = fireDate
    }
}

public enum MilestonePlanner {
    /// Builds the future local-notification schedule.
    ///
    /// - Missed milestones (their fire date is already in the past) are never
    ///   queued, so relaunching the app cannot produce a burst of stale alerts.
    /// - Milestones that occur before the goal starts are skipped: the alert is
    ///   meant to help while the goal is in flight.
    /// - The result is chronological and capped to respect the system's pending
    ///   notification limit.
    public static func plan(
        goals: [Goal],
        milestones: Set<NotificationMilestone>,
        now: Date,
        limit: Int = 60
    ) -> [PlannedMilestone] {
        guard !goals.isEmpty, !milestones.isEmpty, limit > 0 else { return [] }

        var planned: [PlannedMilestone] = []
        for goal in goals where goal.isValid {
            for milestone in milestones {
                let fireDate = goal.deadline.addingTimeInterval(-milestone.seconds)
                guard fireDate > now, fireDate >= goal.startDate else { continue }
                planned.append(PlannedMilestone(goal: goal, milestone: milestone, fireDate: fireDate))
            }
        }

        planned.sort {
            if $0.fireDate != $1.fireDate { return $0.fireDate < $1.fireDate }
            if $0.goal.deadline != $1.goal.deadline { return $0.goal.deadline < $1.goal.deadline }
            if $0.milestone.seconds != $1.milestone.seconds { return $0.milestone.seconds > $1.milestone.seconds }
            return $0.goal.id.uuidString < $1.goal.id.uuidString
        }

        return Array(planned.prefix(limit))
    }
}
