#!/bin/bash

# Builds GoalPulse.app.
#
# - With full Xcode installed, builds GoalPulse.xcodeproj.
# - With Command Line Tools only, builds the local GoalPulseCore package and
#   compiles the app with swiftc against a compatible macOS SDK.
#
# Usage:  bash scripts/build_app.sh [--run]
# Env:    GOALPULSE_BUILD_DIR, GOALPULSE_SDK, GOALPULSE_CODESIGN_IDENTITY
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${GOALPULSE_BUILD_DIR:-$ROOT/build}"
APP="$BUILD_DIR/GoalPulse.app"
BUNDLE_ID="com.goalpulse.GoalPulse"
DEPLOYMENT_TARGET="14.0"
RUN_AFTER_BUILD=0

for argument in "$@"; do
    case "$argument" in
        --run) RUN_AFTER_BUILD=1 ;;
        *)
            echo "Unknown option: $argument" >&2
            exit 64
            ;;
    esac
done

mkdir -p "$BUILD_DIR"

sign_app() {
    local identity="${GOALPULSE_CODESIGN_IDENTITY:--}"
    if [[ "$identity" == "-" ]]; then
        codesign --force --sign - "$APP" >/dev/null
        echo "Signed ad-hoc (local use)."
    else
        codesign --force --options runtime --timestamp --sign "$identity" "$APP"
        echo "Signed with identity: $identity"
    fi
}

print_next_steps() {
    echo
    echo "App bundle: $APP"
    echo "Run it with: open \"$APP\""
    echo "Install with: cp -R \"$APP\" /Applications/"
}

if xcodebuild -version >/dev/null 2>&1; then
    echo "Xcode found — building GoalPulse.xcodeproj."
    DERIVED_DATA="$BUILD_DIR/DerivedData"
    xcodebuild \
        -project "$ROOT/GoalPulse.xcodeproj" \
        -scheme GoalPulse \
        -configuration Release \
        -derivedDataPath "$DERIVED_DATA" \
        -destination "platform=macOS" \
        CODE_SIGNING_ALLOWED=NO \
        build

    BUILT_APP="$DERIVED_DATA/Build/Products/Release/GoalPulse.app"
    if [[ ! -d "$BUILT_APP" ]]; then
        echo "Xcode build did not produce GoalPulse.app." >&2
        exit 1
    fi

    rm -rf "$APP"
    ditto "$BUILT_APP" "$APP"
    sign_app
    print_next_steps
    if [[ "$RUN_AFTER_BUILD" -eq 1 ]]; then
        open "$APP"
    fi
    exit 0
fi

echo "Full Xcode not found — using the Command Line Tools build path."

SDK="${GOALPULSE_SDK:-}"
if [[ -z "$SDK" ]]; then
    # SDK 27's SwiftUI module exposes macros that the Command Line Tools
    # toolchain does not ship. The 26.x SDK uses plain property wrappers and
    # builds cleanly. Xcode itself does not need this workaround.
    if [[ -d /Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk ]]; then
        SDK=/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk
    elif [[ -d /Library/Developer/CommandLineTools/SDKs/MacOSX26.sdk ]]; then
        SDK=/Library/Developer/CommandLineTools/SDKs/MacOSX26.sdk
    else
        SDK="$(xcrun --sdk macosx --show-sdk-path)"
    fi
fi

if [[ ! -d "$SDK" ]]; then
    echo "macOS SDK not found at: $SDK" >&2
    echo "Set GOALPULSE_SDK to a valid SDK path and retry." >&2
    exit 1
fi

echo "SDK: $SDK"
CORE_SCRATCH="$BUILD_DIR/core"
SDKROOT="$SDK" swift build \
    -c release \
    --package-path "$ROOT/GoalPulseCore" \
    --scratch-path "$CORE_SCRATCH" \
    --product GoalPulseCore
CORE_BIN="$(SDKROOT="$SDK" swift build \
    -c release \
    --package-path "$ROOT/GoalPulseCore" \
    --scratch-path "$CORE_SCRATCH" \
    --show-bin-path)"

if [[ ! -f "$CORE_BIN/libGoalPulseCore.a" ]]; then
    echo "GoalPulseCore static library was not produced in $CORE_BIN." >&2
    exit 1
fi

APP_CONTENTS="$APP/Contents"
rm -rf "$APP"
mkdir -p "$APP_CONTENTS/MacOS" "$APP_CONTENTS/Resources"

SOURCES=()
while IFS= read -r file; do
    SOURCES+=("$file")
done < <(find "$ROOT/GoalPulse" -name '*.swift' -type f | sort)

if [[ ${#SOURCES[@]} -eq 0 ]]; then
    echo "No Swift sources found." >&2
    exit 1
fi

echo "Compiling ${#SOURCES[@]} Swift sources..."
swiftc \
    -sdk "$SDK" \
    -target "$(uname -m)-apple-macos$DEPLOYMENT_TARGET" \
    -swift-version 5 \
    -O \
    -module-name GoalPulse \
    -parse-as-library \
    -I "$CORE_BIN" \
    -L "$CORE_BIN" \
    -lGoalPulseCore \
    -framework SwiftUI \
    -framework AppKit \
    -framework UserNotifications \
    -framework ServiceManagement \
    -o "$APP_CONTENTS/MacOS/GoalPulse" \
    "${SOURCES[@]}"

cp "$ROOT/GoalPulse/Resources/Info.plist" "$APP_CONTENTS/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleExecutable GoalPulse" "$APP_CONTENTS/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier $BUNDLE_ID" "$APP_CONTENTS/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Set :CFBundleName GoalPulse" "$APP_CONTENTS/Info.plist" >/dev/null
/usr/libexec/PlistBuddy -c "Set :LSMinimumSystemVersion $DEPLOYMENT_TARGET" "$APP_CONTENTS/Info.plist" >/dev/null
plutil -lint "$APP_CONTENTS/Info.plist" >/dev/null

cp "$ROOT/GoalPulse/Resources/AppIcon.icns" "$APP_CONTENTS/Resources/AppIcon.icns"
printf 'APPL????' > "$APP_CONTENTS/PkgInfo"

chmod +x "$APP_CONTENTS/MacOS/GoalPulse"
sign_app

# Refresh LaunchServices' view of the freshly built bundle so the menu bar app
# and its notifications are associated with this build immediately.
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister \
    -f "$APP" >/dev/null 2>&1 || true

print_next_steps
if [[ "$RUN_AFTER_BUILD" -eq 1 ]]; then
    open "$APP"
fi
