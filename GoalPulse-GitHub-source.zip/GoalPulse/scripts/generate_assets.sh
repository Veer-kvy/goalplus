#!/bin/bash

# Regenerates the app icon PNGs, asset catalog and .icns from the vector-style
# renderer in scripts/generate_icon.swift. Output is checked in, so this only
# needs to run when the icon design changes.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ASSETS="$ROOT/GoalPulse/Resources/Assets.xcassets"
ICON_DIR="$ASSETS/AppIcon.appiconset"
ICNS="$ROOT/GoalPulse/Resources/AppIcon.icns"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/goalpulse-icon.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

mkdir -p "$ICON_DIR" "$TMP/AppIcon.iconset"
printf '{\n  "info" : {\n    "author" : "xcode",\n    "version" : 1\n  }\n}\n' > "$ASSETS/Contents.json"

swift "$ROOT/scripts/generate_icon.swift" "$TMP/icon_1024.png"

make_icon() {
    local pixels="$1"
    local filename="$2"
    sips -z "$pixels" "$pixels" "$TMP/icon_1024.png" --out "$ICON_DIR/$filename" >/dev/null
}

make_icon 16   icon_16x16.png
make_icon 32   icon_16x16@2x.png
make_icon 32   icon_32x32.png
make_icon 64   icon_32x32@2x.png
make_icon 128  icon_128x128.png
make_icon 256  icon_128x128@2x.png
make_icon 256  icon_256x256.png
make_icon 512  icon_256x256@2x.png
make_icon 512  icon_512x512.png
make_icon 1024 icon_512x512@2x.png

for file in "$ICON_DIR"/icon_*.png; do
    cp "$file" "$TMP/AppIcon.iconset/$(basename "$file")"
done

iconutil -c icns "$TMP/AppIcon.iconset" -o "$ICNS"

cat > "$ICON_DIR/Contents.json" <<'JSON'
{
  "images" : [
    {
      "filename" : "icon_16x16.png",
      "idiom" : "mac",
      "scale" : "1x",
      "size" : "16x16"
    },
    {
      "filename" : "icon_16x16@2x.png",
      "idiom" : "mac",
      "scale" : "2x",
      "size" : "16x16"
    },
    {
      "filename" : "icon_32x32.png",
      "idiom" : "mac",
      "scale" : "1x",
      "size" : "32x32"
    },
    {
      "filename" : "icon_32x32@2x.png",
      "idiom" : "mac",
      "scale" : "2x",
      "size" : "32x32"
    },
    {
      "filename" : "icon_128x128.png",
      "idiom" : "mac",
      "scale" : "1x",
      "size" : "128x128"
    },
    {
      "filename" : "icon_128x128@2x.png",
      "idiom" : "mac",
      "scale" : "2x",
      "size" : "128x128"
    },
    {
      "filename" : "icon_256x256.png",
      "idiom" : "mac",
      "scale" : "1x",
      "size" : "256x256"
    },
    {
      "filename" : "icon_256x256@2x.png",
      "idiom" : "mac",
      "scale" : "2x",
      "size" : "256x256"
    },
    {
      "filename" : "icon_512x512.png",
      "idiom" : "mac",
      "scale" : "1x",
      "size" : "512x512"
    },
    {
      "filename" : "icon_512x512@2x.png",
      "idiom" : "mac",
      "scale" : "2x",
      "size" : "512x512"
    }
  ],
  "info" : {
    "author" : "xcode",
    "version" : 1
  }
}
JSON

echo "Generated app icon assets:"
echo "  $ICON_DIR"
echo "  $ICNS"
