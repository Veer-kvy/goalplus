#!/usr/bin/env swift

import AppKit
import CoreGraphics
import Foundation

let outputPath = CommandLine.arguments.count > 1
    ? CommandLine.arguments[1]
    : "AppIcon-1024.png"

let side = 1024
let width = CGFloat(side)
let height = CGFloat(side)
let colorSpace = CGColorSpaceCreateDeviceRGB()

guard let context = CGContext(
    data: nil,
    width: side,
    height: side,
    bitsPerComponent: 8,
    bytesPerRow: 0,
    space: colorSpace,
    bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
) else {
    FileHandle.standardError.write(Data("Could not create icon context.\n".utf8))
    exit(1)
}

context.setAllowsAntialiasing(true)
context.setShouldAntialias(true)

func color(_ red: CGFloat, _ green: CGFloat, _ blue: CGFloat, _ alpha: CGFloat = 1) -> CGColor {
    CGColor(colorSpace: colorSpace, components: [red, green, blue, alpha])!
}

let iconRect = CGRect(x: 70, y: 70, width: width - 140, height: height - 140)
let iconPath = CGPath(
    roundedRect: iconRect,
    cornerWidth: 208,
    cornerHeight: 208,
    transform: nil
)

// Soft shadow beneath the icon tile.
context.saveGState()
context.setShadow(
    offset: CGSize(width: 0, height: -22),
    blur: 44,
    color: color(0.03, 0.05, 0.15, 0.34)
)
context.addPath(iconPath)
context.setFillColor(color(0.22, 0.35, 0.82))
context.fillPath()
context.restoreGState()

// Blue-to-violet gradient tile.
context.saveGState()
context.addPath(iconPath)
context.clip()

let tileGradient = CGGradient(
    colorsSpace: colorSpace,
    colors: [
        color(0.22, 0.50, 0.98),
        color(0.33, 0.29, 0.92),
        color(0.42, 0.22, 0.79)
    ] as CFArray,
    locations: [0, 0.58, 1]
)
if let tileGradient {
    context.drawLinearGradient(
        tileGradient,
        start: CGPoint(x: 210, y: 910),
        end: CGPoint(x: 880, y: 120),
        options: [.drawsBeforeStartLocation, .drawsAfterEndLocation]
    )
}

let glow = CGGradient(
    colorsSpace: colorSpace,
    colors: [color(1, 1, 1, 0.22), color(1, 1, 1, 0)] as CFArray,
    locations: [0, 1]
)
if let glow {
    context.drawRadialGradient(
        glow,
        startCenter: CGPoint(x: 300, y: 850),
        startRadius: 0,
        endCenter: CGPoint(x: 300, y: 850),
        endRadius: 620,
        options: []
    )
}

let footShade = CGGradient(
    colorsSpace: colorSpace,
    colors: [color(0.05, 0.03, 0.20, 0), color(0.04, 0.02, 0.16, 0.24)] as CFArray,
    locations: [0, 1]
)
if let footShade {
    context.drawLinearGradient(
        footShade,
        start: CGPoint(x: 512, y: 520),
        end: CGPoint(x: 512, y: 70),
        options: []
    )
}

context.restoreGState()

// Crisp inner rim.
context.saveGState()
let rimRect = iconRect.insetBy(dx: 2.5, dy: 2.5)
context.addPath(CGPath(
    roundedRect: rimRect,
    cornerWidth: 206,
    cornerHeight: 206,
    transform: nil
))
context.setStrokeColor(color(1, 1, 1, 0.18))
context.setLineWidth(5)
context.strokePath()
context.restoreGState()

let center = CGPoint(x: 512, y: 492)
let ringRadius: CGFloat = 208
let ringWidth: CGFloat = 42

// Side button, drawn beneath the ring.
context.saveGState()
context.translateBy(x: center.x, y: center.y)
context.rotate(by: .pi / 4)
let sideButton = CGRect(x: ringRadius - 4, y: -30, width: 64, height: 60)
context.addPath(CGPath(
    roundedRect: sideButton,
    cornerWidth: 22,
    cornerHeight: 22,
    transform: nil
))
context.setFillColor(color(1, 1, 1, 0.95))
context.fillPath()
context.restoreGState()

// Crown and top button.
context.addPath(CGPath(
    roundedRect: CGRect(x: center.x - 31, y: center.y + ringRadius - 18, width: 62, height: 66),
    cornerWidth: 17,
    cornerHeight: 17,
    transform: nil
))
context.setFillColor(color(1, 1, 1, 0.96))
context.fillPath()

context.addPath(CGPath(
    roundedRect: CGRect(x: center.x - 16, y: center.y + ringRadius + 40, width: 32, height: 30),
    cornerWidth: 11,
    cornerHeight: 11,
    transform: nil
))
context.setFillColor(color(1, 1, 1, 0.96))
context.fillPath()

// Face interior.
context.setFillColor(color(0.10, 0.14, 0.48, 0.14))
context.fillEllipse(in: CGRect(
    x: center.x - (ringRadius - ringWidth / 2),
    y: center.y - (ringRadius - ringWidth / 2),
    width: (ringRadius - ringWidth / 2) * 2,
    height: (ringRadius - ringWidth / 2) * 2
))

// Ring.
context.setStrokeColor(color(1, 1, 1, 0.97))
context.setLineWidth(ringWidth)
context.strokeEllipse(in: CGRect(
    x: center.x - ringRadius,
    y: center.y - ringRadius,
    width: ringRadius * 2,
    height: ringRadius * 2
))

// Tick marks.
let tickRadius: CGFloat = 157
for index in 0..<12 {
    let angle = CGFloat.pi / 2 - CGFloat(index) * (CGFloat.pi / 6)
    let isMajor = index % 3 == 0
    let inner = tickRadius - (isMajor ? 20 : 12)
    let outer = tickRadius + (isMajor ? 11 : 6)
    let start = CGPoint(x: center.x + cos(angle) * inner, y: center.y + sin(angle) * inner)
    let end = CGPoint(x: center.x + cos(angle) * outer, y: center.y + sin(angle) * outer)

    context.setStrokeColor(color(1, 1, 1, isMajor ? 0.72 : 0.48))
    context.setLineWidth(isMajor ? 11 : 8)
    context.setLineCap(.round)
    context.move(to: start)
    context.addLine(to: end)
    context.strokePath()
}

// Timer hands.
context.setStrokeColor(color(1, 1, 1, 0.98))
context.setLineCap(.round)

let minuteAngle = CGFloat.pi / 2 - CGFloat.pi / 7
let minuteTip = CGPoint(
    x: center.x + cos(minuteAngle) * 126,
    y: center.y + sin(minuteAngle) * 126
)
context.setLineWidth(29)
context.move(to: center)
context.addLine(to: minuteTip)
context.strokePath()

let hourAngle = CGFloat.pi / 2 + CGFloat.pi / 3.1
let hourTip = CGPoint(
    x: center.x + cos(hourAngle) * 84,
    y: center.y + sin(hourAngle) * 84
)
context.setLineWidth(23)
context.move(to: center)
context.addLine(to: hourTip)
context.strokePath()

context.setFillColor(color(1, 1, 1, 1))
context.fillEllipse(in: CGRect(x: center.x - 21, y: center.y - 21, width: 42, height: 42))
context.setFillColor(color(0.42, 0.35, 0.92, 1))
context.fillEllipse(in: CGRect(x: center.x - 8, y: center.y - 8, width: 16, height: 16))

// Sparkle details.
func sparklePath(center: CGPoint, radius: CGFloat, waist: CGFloat = 0.18) -> CGPath {
    let path = CGMutablePath()
    path.move(to: CGPoint(x: center.x, y: center.y + radius))
    path.addQuadCurve(
        to: CGPoint(x: center.x + radius, y: center.y),
        control: CGPoint(x: center.x + radius * waist, y: center.y + radius * waist)
    )
    path.addQuadCurve(
        to: CGPoint(x: center.x, y: center.y - radius),
        control: CGPoint(x: center.x + radius * waist, y: center.y - radius * waist)
    )
    path.addQuadCurve(
        to: CGPoint(x: center.x - radius, y: center.y),
        control: CGPoint(x: center.x - radius * waist, y: center.y - radius * waist)
    )
    path.addQuadCurve(
        to: CGPoint(x: center.x, y: center.y + radius),
        control: CGPoint(x: center.x - radius * waist, y: center.y + radius * waist)
    )
    path.closeSubpath()
    return path
}

context.addPath(sparklePath(center: CGPoint(x: 800, y: 776), radius: 35))
context.setFillColor(color(1, 1, 1, 0.78))
context.fillPath()

context.addPath(sparklePath(center: CGPoint(x: 846, y: 692), radius: 15))
context.setFillColor(color(1, 1, 1, 0.50))
context.fillPath()

guard let image = context.makeImage() else {
    FileHandle.standardError.write(Data("Could not render icon.\n".utf8))
    exit(1)
}

let representation = NSBitmapImageRep(cgImage: image)
guard let pngData = representation.representation(using: .png, properties: [:]) else {
    FileHandle.standardError.write(Data("Could not encode icon.\n".utf8))
    exit(1)
}

let url = URL(fileURLWithPath: outputPath)
try FileManager.default.createDirectory(
    at: url.deletingLastPathComponent(),
    withIntermediateDirectories: true
)
try pngData.write(to: url)
print("Wrote \(url.path)")
