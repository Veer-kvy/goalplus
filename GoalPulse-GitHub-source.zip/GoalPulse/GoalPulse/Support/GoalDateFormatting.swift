import Foundation
import GoalPulseCore

enum GoalDateFormatting {
    static func dateAndTime(_ date: Date) -> String {
        date.formatted(date: .abbreviated, time: .shortened)
    }

    static func dateOnly(_ date: Date) -> String {
        date.formatted(.dateTime.weekday(.abbreviated).day().month(.abbreviated).year())
    }

    static func timeOnly(_ date: Date) -> String {
        date.formatted(date: .omitted, time: .shortened)
    }

    static func compactDeadline(_ date: Date) -> String {
        date.formatted(.dateTime.month(.abbreviated).day().hour().minute())
    }

    static var currentTimeZoneName: String {
        TimeZone.current.localizedName(for: .shortGeneric, locale: .current) ?? TimeZone.current.identifier
    }
}

enum GoalStatusCopy {
    static func upcomingDetail(start: Date, now: Date) -> String {
        let interval = start.timeIntervalSince(now)
        guard interval > 0 else { return "Starts \(GoalDateFormatting.dateAndTime(start))" }
        return "Starts in \(GoalFormatting.duration(interval)) · \(GoalDateFormatting.dateAndTime(start))"
    }

    static func completionDetail(deadline: Date) -> String {
        "Finished \(GoalDateFormatting.dateOnly(deadline))"
    }
}
