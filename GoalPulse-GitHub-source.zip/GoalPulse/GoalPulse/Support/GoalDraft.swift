import Foundation
import GoalPulseCore

/// Editable, view-facing copy of a goal.
///
/// Start and deadline are kept as separate date and time values so the editor
/// can offer four native pickers. They are merged into absolute instants only
/// when validating, previewing or saving, which keeps DST and time-zone
/// handling in one tested place.
struct GoalDraft: Equatable {
    var existingID: UUID?
    var createdAt: Date
    var title: String
    var details: String
    var emoji: String
    var accentID: String?
    var startDate: Date
    var startTime: Date
    var deadlineDate: Date
    var deadlineTime: Date

    init(now: Date = Date(), calendar: Calendar = .current) {
        let start = DateTimeMerger.roundingUpToMinute(now, calendar: calendar)
        let deadline = calendar.date(byAdding: .day, value: 30, to: start)
            ?? start.addingTimeInterval(30 * 86_400)

        existingID = nil
        createdAt = now
        title = ""
        details = ""
        emoji = ""
        accentID = nil
        startDate = start
        startTime = start
        deadlineDate = deadline
        deadlineTime = deadline
    }

    init(goal: Goal) {
        existingID = goal.id
        createdAt = goal.createdAt
        title = goal.title
        details = goal.details
        emoji = goal.trimmedEmoji ?? ""
        accentID = goal.accentID
        startDate = goal.startDate
        startTime = goal.startDate
        deadlineDate = goal.deadline
        deadlineTime = goal.deadline
    }

    var isEditing: Bool { existingID != nil }

    func startInstant(calendar: Calendar = .current) -> Date {
        DateTimeMerger.combine(date: startDate, time: startTime, calendar: calendar)
    }

    func deadlineInstant(calendar: Calendar = .current) -> Date {
        DateTimeMerger.combine(date: deadlineDate, time: deadlineTime, calendar: calendar)
    }

    var totalDuration: TimeInterval {
        max(0, deadlineInstant().timeIntervalSince(startInstant()))
    }

    var validation: GoalValidationResult {
        GoalValidation.validate(
            title: title,
            details: details,
            startDate: startInstant(),
            deadline: deadlineInstant(),
            emoji: emoji
        )
    }

    var isValid: Bool { validation.isValid }

    var trimmedTitle: String {
        title.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var trimmedEmoji: String? {
        let trimmed = emoji.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    /// Applies a duration preset from the start instant, preserving the
    /// intended wall-clock time across daylight-saving transitions.
    mutating func apply(_ preset: GoalDurationPreset, calendar: Calendar = .current) {
        let start = startInstant(calendar: calendar)
        let target = calendar.date(byAdding: preset.component, value: preset.amount, to: start)
            ?? start.addingTimeInterval(preset.fallbackSeconds)
        deadlineDate = target
        deadlineTime = target
    }

    func buildGoal(now: Date = Date()) -> Goal {
        Goal(
            id: existingID ?? UUID(),
            title: title,
            details: details,
            startDate: startInstant(),
            deadline: deadlineInstant(),
            emoji: emoji,
            accentID: accentID,
            createdAt: createdAt
        )
    }

    var accentColorName: String? {
        guard let accentID, let accent = GoalAccent(rawValue: accentID) else { return nil }
        return accent.name
    }
}

enum GoalDurationPreset: String, CaseIterable, Identifiable {
    case week
    case month
    case quarter
    case year

    var id: String { rawValue }

    var label: String {
        switch self {
        case .week: return "7 days"
        case .month: return "30 days"
        case .quarter: return "90 days"
        case .year: return "1 year"
        }
    }

    var compactLabel: String {
        switch self {
        case .week: return "7D"
        case .month: return "30D"
        case .quarter: return "90D"
        case .year: return "1Y"
        }
    }

    var component: Calendar.Component {
        switch self {
        case .week, .month, .quarter: return .day
        case .year: return .year
        }
    }

    var amount: Int {
        switch self {
        case .week: return 7
        case .month: return 30
        case .quarter: return 90
        case .year: return 1
        }
    }

    var fallbackSeconds: TimeInterval {
        switch self {
        case .week: return 7 * 86_400
        case .month: return 30 * 86_400
        case .quarter: return 90 * 86_400
        case .year: return 365 * 86_400
        }
    }
}
