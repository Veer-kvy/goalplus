import AppKit
import GoalPulseCore
import SwiftUI

enum GoalAccent: String, CaseIterable, Identifiable {
    case ocean
    case teal
    case indigo
    case plum
    case rose
    case amber
    case forest
    case slate

    var id: String { rawValue }

    var name: String {
        switch self {
        case .ocean: return "Ocean"
        case .teal: return "Teal"
        case .indigo: return "Indigo"
        case .plum: return "Plum"
        case .rose: return "Rose"
        case .amber: return "Amber"
        case .forest: return "Forest"
        case .slate: return "Slate"
        }
    }

    var color: Color {
        switch self {
        case .ocean: return .blue
        case .teal: return .teal
        case .indigo: return .indigo
        case .plum: return .purple
        case .rose: return .pink
        case .amber: return .orange
        case .forest: return .green
        case .slate: return .secondary
        }
    }
}

extension EmojiMood {
    var tint: Color {
        switch self {
        case .calm: return .blue
        case .steady: return .teal
        case .focus: return .indigo
        case .intense: return .orange
        case .urgent: return .red
        case .complete: return .green
        }
    }
}

enum GoalPalette {
    /// Progress and primary actions use the goal's own accent; otherwise the
    /// countdown mood supplies a tasteful, state-appropriate color. Urgency and
    /// completion deliberately override the accent so those states always read
    /// clearly in the progress bar, emoji aura and card tint.
    static func progressTint(for goal: Goal, mood: EmojiMood) -> Color {
        if mood == .complete { return .green }
        if mood == .urgent { return .red }
        if let raw = goal.accentID, let accent = GoalAccent(rawValue: raw) {
            return accent.color
        }
        return mood.tint
    }

    static func stateTint(for mood: EmojiMood) -> Color {
        mood.tint
    }
}

extension ThemePreference {
    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}

extension AnimationIntensity {
    var pulseScale: Double {
        switch self {
        case .off: return 0
        case .subtle: return 0.02
        case .balanced: return 0.045
        case .lively: return 0.075
        }
    }

    var pulseDuration: Double {
        switch self {
        case .off: return 0
        case .subtle: return 4.0
        case .balanced: return 3.0
        case .lively: return 2.1
        }
    }

    var glowOpacity: Double {
        switch self {
        case .off: return 0.08
        case .subtle: return 0.18
        case .balanced: return 0.30
        case .lively: return 0.45
        }
    }
}

extension MenuBarDisplayMode {
    var label: String {
        switch self {
        case .emojiAndCountdown: return "Emoji + countdown"
        case .emojiOnly: return "Emoji only"
        case .countdownOnly: return "Countdown only"
        }
    }
}

extension CountdownFormat {
    var label: String {
        switch self {
        case .segmented: return "Segmented tiles"
        case .inline: return "Inline sentence"
        case .compact: return "Compact"
        }
    }
}

extension AnimationIntensity {
    var label: String {
        switch self {
        case .off: return "Off"
        case .subtle: return "Subtle"
        case .balanced: return "Balanced"
        case .lively: return "Lively"
        }
    }
}

extension ThemePreference {
    var label: String {
        switch self {
        case .system: return "System"
        case .light: return "Light"
        case .dark: return "Dark"
        }
    }
}

extension View {
    func surfaceCard(
        padding: CGFloat = 14,
        cornerRadius: CGFloat = 16,
        tint: Color? = nil
    ) -> some View {
        modifier(SurfaceCardModifier(padding: padding, cornerRadius: cornerRadius, tint: tint))
    }
}

private struct SurfaceCardModifier: ViewModifier {
    @Environment(\.colorScheme) private var colorScheme
    let padding: CGFloat
    let cornerRadius: CGFloat
    let tint: Color?

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .fill(.thinMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .fill(Color(nsColor: .controlBackgroundColor)
                                .opacity(colorScheme == .dark ? 0.34 : 0.46))
                    }
                    .overlay {
                        if let tint {
                            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                                .fill(
                                    LinearGradient(
                                        colors: [
                                            tint.opacity(colorScheme == .dark ? 0.16 : 0.10),
                                            tint.opacity(0)
                                        ],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                        }
                    }
            }
            .overlay {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .strokeBorder(Color.primary.opacity(colorScheme == .dark ? 0.10 : 0.07), lineWidth: 1)
            }
            .shadow(color: .black.opacity(colorScheme == .dark ? 0.16 : 0.05), radius: 10, y: 4)
    }
}

struct PopoverBackground: View {
    @Environment(\.colorScheme) private var colorScheme
    let tint: Color

    var body: some View {
        ZStack {
            Rectangle()
                .fill(.regularMaterial)
            RadialGradient(
                colors: [
                    tint.opacity(colorScheme == .dark ? 0.16 : 0.09),
                    tint.opacity(0)
                ],
                center: .topTrailing,
                startRadius: 4,
                endRadius: 320
            )
        }
        .ignoresSafeArea()
    }
}

struct ToolbarIconButton: View {
    let systemName: String
    let help: String
    var foreground: Color = .secondary
    let action: () -> Void

    @State private var isHovering = false

    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 12.5, weight: .semibold))
                .foregroundStyle(foreground)
                .frame(width: 26, height: 26)
                .background {
                    Circle()
                        .fill(Color.primary.opacity(isHovering ? 0.085 : 0))
                }
                .contentShape(Circle())
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            withAnimation(.easeOut(duration: 0.12)) {
                isHovering = hovering
            }
        }
        .help(help)
        .accessibilityLabel(help)
    }
}

struct MoodChip: View {
    let mood: EmojiMood
    let labelOverride: String?
    let tint: Color

    init(mood: EmojiMood, labelOverride: String? = nil, tint: Color? = nil) {
        self.mood = mood
        self.labelOverride = labelOverride
        self.tint = tint ?? mood.tint
    }

    var body: some View {
        HStack(spacing: 5) {
            Circle()
                .fill(tint)
                .frame(width: 5, height: 5)
            Text(labelOverride ?? mood.title)
                .font(.system(size: 10.5, weight: .semibold))
                .textCase(.uppercase)
                .tracking(0.5)
        }
        .foregroundStyle(tint)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(tint.opacity(0.12), in: Capsule())
        .accessibilityElement(children: .combine)
    }
}
