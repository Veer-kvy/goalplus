import Foundation
import Observation
import ServiceManagement

/// Thin wrapper around `SMAppService.mainApp`.
///
/// Registering a login item is a system-level operation. macOS may require the
/// user's approval in System Settings, and unsigned or ad-hoc signed builds can
/// be rejected by the system. Failures are surfaced in Settings rather than
/// silently leaving the toggle in the wrong position.
@MainActor
@Observable
final class LaunchAtLoginService {
    private(set) var status: SMAppService.Status
    private(set) var errorMessage: String?

    init() {
        status = SMAppService.mainApp.status
    }

    var isEnabled: Bool {
        status == .enabled || status == .requiresApproval
    }

    var requiresApproval: Bool {
        status == .requiresApproval
    }

    var detail: String? {
        if let errorMessage { return errorMessage }
        switch status {
        case .enabled:
            return "GoalPulse will open automatically when you sign in."
        case .requiresApproval:
            return "Approve GoalPulse in System Settings › General › Login Items."
        case .notRegistered:
            return "GoalPulse will not open automatically."
        case .notFound:
            return "Move GoalPulse to Applications, then try again."
        @unknown default:
            return nil
        }
    }

    func refresh() {
        status = SMAppService.mainApp.status
    }

    func setEnabled(_ enabled: Bool) {
        errorMessage = nil
        do {
            if enabled {
                try SMAppService.mainApp.register()
            } else {
                try SMAppService.mainApp.unregister()
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        refresh()
    }

    func openLoginItemsSettings() {
        SMAppService.openSystemSettingsLoginItems()
    }
}
