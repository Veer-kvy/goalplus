import Foundation
import Observation

/// A single, app-wide wall clock. Countdown values are always recomputed from
/// `now` and the goal deadline; this task never decrements a counter, so sleep,
/// wake, timer coalescing and clock changes cannot make the display drift.
@MainActor
@Observable
final class CountdownClock {
    private(set) var now: Date
    private var tickTask: Task<Void, Never>?

    init(now: Date = Date()) {
        self.now = now
    }

    func start() {
        guard tickTask == nil else { return }
        tickTask = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                let delay = Self.nanosecondsUntilNextSecond(from: Date())
                do {
                    try await Task.sleep(nanoseconds: delay)
                } catch {
                    return
                }
                guard let self, !Task.isCancelled else { return }
                self.now = Date()
            }
        }
    }

    func stop() {
        tickTask?.cancel()
        tickTask = nil
    }

    /// Called on launch, wake, activation and clock/time-zone changes.
    func refresh() {
        now = Date()
    }

    private static func nanosecondsUntilNextSecond(from date: Date) -> UInt64 {
        let fractional = date.timeIntervalSince1970.truncatingRemainder(dividingBy: 1)
        var delay = 1.0 - fractional
        if delay < 0.05 {
            delay += 1.0
        }
        return UInt64(delay * 1_000_000_000)
    }
}
