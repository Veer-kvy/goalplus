import Foundation
import GoalPulseCore
import Observation

/// Loads and atomically saves goals as human-readable JSON in Application
/// Support. All mutations go through this store on the main actor, so UI state
/// and disk state cannot be written concurrently.
@MainActor
@Observable
final class GoalStore {
    private(set) var goals: [Goal] = []
    private(set) var activeGoalID: UUID?
    private(set) var persistenceError: String?
    private(set) var dataNotice: String?

    private let fileURL: URL
    private let encoder: JSONEncoder
    private let decoder: JSONDecoder

    init(fileURL: URL? = nil) {
        self.fileURL = fileURL ?? GoalStore.defaultFileURL()

        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        self.encoder = encoder

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        self.decoder = decoder

        load()
    }

    var activeGoal: Goal? {
        guard let activeGoalID else { return nil }
        return goals.first { $0.id == activeGoalID }
    }

    var isEmpty: Bool { goals.isEmpty }

    static func defaultFileURL() -> URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support")
        return base
            .appendingPathComponent("GoalPulse", isDirectory: true)
            .appendingPathComponent("goals.json")
    }

    var dataFileURL: URL { fileURL }

    @discardableResult
    func add(_ goal: Goal) -> Bool {
        guard goal.validation.isValid else { return false }
        goals.append(sanitized(goal))
        if activeGoalID == nil {
            activeGoalID = goal.id
        }
        save()
        return true
    }

    @discardableResult
    func update(_ goal: Goal) -> Bool {
        guard goal.validation.isValid,
              let index = goals.firstIndex(where: { $0.id == goal.id }) else {
            return false
        }
        goals[index] = sanitized(goal)
        save()
        return true
    }

    func delete(id: UUID) {
        guard goals.contains(where: { $0.id == id }) else { return }
        goals.removeAll { $0.id == id }
        if activeGoalID == id {
            activeGoalID = goals.first?.id
        }
        save()
    }

    func setActive(_ id: UUID?) {
        guard let id else {
            guard activeGoalID != nil else { return }
            activeGoalID = nil
            save()
            return
        }
        guard goals.contains(where: { $0.id == id }) else { return }
        guard activeGoalID != id else { return }
        activeGoalID = id
        save()
    }

    func clearDataNotice() {
        dataNotice = nil
    }

    func clearPersistenceError() {
        persistenceError = nil
    }

    // MARK: - Persistence

    private func sanitized(_ goal: Goal) -> Goal {
        var copy = goal
        copy.title = goal.trimmedTitle
        copy.details = goal.trimmedDetails
        copy.emoji = goal.trimmedEmoji
        if let accentID = copy.accentID, accentID.trimmingCharacters(in: .whitespaces).isEmpty {
            copy.accentID = nil
        }
        return copy
    }

    private func load() {
        guard FileManager.default.fileExists(atPath: fileURL.path) else { return }

        do {
            let rawData = try Data(contentsOf: fileURL)
            let decoded = try decoder.decode(GoalPulseData.self, from: rawData)
            let result = decoded.normalized()

            goals = result.data.goals
            activeGoalID = result.data.activeGoalID

            if result.droppedGoals > 0 {
                _ = backup(rawData: rawData)
                dataNotice = result.droppedGoals == 1
                    ? "One invalid goal could not be loaded. A backup of your goal file was kept."
                    : "\(result.droppedGoals) invalid goals could not be loaded. A backup of your goal file was kept."
                save()
            } else if result.repairedActiveGoal {
                save()
            }
        } catch {
            let rawData = (try? Data(contentsOf: fileURL)) ?? Data()
            let backupKept = rawData.isEmpty ? false : backup(rawData: rawData)
            goals = []
            activeGoalID = nil
            dataNotice = backupKept
                ? "Your goal file could not be read. It was backed up and a fresh file will be created."
                : "Your goal file could not be read. No goals were loaded."
        }
    }

    private func save() {
        do {
            let directory = fileURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)

            let payload = GoalPulseData(goals: goals, activeGoalID: activeGoalID)
            let data = try encoder.encode(payload)
            try data.write(to: fileURL, options: .atomic)
            persistenceError = nil
        } catch {
            persistenceError = "Your changes could not be saved. \(error.localizedDescription)"
        }
    }

    @discardableResult
    private func backup(rawData: Data) -> Bool {
        let directory = fileURL.deletingLastPathComponent()
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = .current
        formatter.dateFormat = "yyyyMMdd-HHmmss"
        let stamp = formatter.string(from: Date())
        let backupURL = directory.appendingPathComponent("goals-backup-\(stamp)-\(UUID().uuidString.prefix(6)).json")
        do {
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            try rawData.write(to: backupURL, options: .atomic)
            return true
        } catch {
            return false
        }
    }
}
