import Foundation
import GoalPulseCore
import Observation

@MainActor
@Observable
final class SettingsStore {
    private static let storageKey = "goalPulse.preferences.v1"
    private let defaults: UserDefaults

    var preferences: AppPreferences {
        didSet {
            guard preferences != oldValue else { return }
            persist()
        }
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let data = defaults.data(forKey: Self.storageKey),
           let decoded = try? JSONDecoder().decode(AppPreferences.self, from: data) {
            self.preferences = decoded.sanitized()
        } else {
            self.preferences = AppPreferences()
        }
    }

    func reset() {
        preferences = AppPreferences()
    }

    func resetThresholds() {
        var updated = preferences
        updated.thresholds = .standard
        preferences = updated
    }

    enum ThresholdLevel {
        case calm
        case steady
        case focus
        case intense
    }

    /// Applies a threshold percentage while preserving the required ordering
    /// (intense < focus < steady < calm). Invalid edits are clamped rather than
    /// allowing the emoji engine into an undefined state.
    func setThreshold(_ level: ThresholdLevel, percent: Int) {
        var thresholds = preferences.thresholds.isValid ? preferences.thresholds : .standard
        let clampedPercent = min(99, max(1, percent))
        let value = (Double(clampedPercent) / 100 * 100).rounded() / 100
        let gap = 0.01

        switch level {
        case .calm:
            thresholds.calm = min(1.0, max(value, thresholds.steady + gap))
        case .steady:
            thresholds.steady = max(thresholds.focus + gap, min(value, thresholds.calm - gap))
        case .focus:
            thresholds.focus = max(thresholds.intense + gap, min(value, thresholds.steady - gap))
        case .intense:
            thresholds.intense = min(thresholds.focus - gap, max(value, gap))
        }

        var updated = preferences
        updated.thresholds = thresholds
        preferences = updated
    }

    func thresholdPercent(_ level: ThresholdLevel) -> Int {
        let thresholds = preferences.thresholds.isValid ? preferences.thresholds : .standard
        let value: Double
        switch level {
        case .calm: value = thresholds.calm
        case .steady: value = thresholds.steady
        case .focus: value = thresholds.focus
        case .intense: value = thresholds.intense
        }
        return Int((value * 100).rounded())
    }

    private func persist() {
        guard let data = try? JSONEncoder().encode(preferences) else { return }
        defaults.set(data, forKey: Self.storageKey)
    }
}
