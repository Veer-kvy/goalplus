import AppKit
import Foundation
import GoalPulseCore
import Observation
import UserNotifications

@MainActor
@Observable
final class NotificationManager {
    private static let milestonePrefix = "goalpulse.milestone."
    private static let testIdentifier = "goalpulse.test"

    private let center: UNUserNotificationCenter?
    private let delegateProxy = NotificationDelegateProxy()

    private(set) var authorizationStatus: UNAuthorizationStatus = .notDetermined
    private(set) var lastError: String?

    init() {
        // UNUserNotificationCenter requires a real application bundle. This
        // guard keeps command-line / test launches from trapping.
        if Bundle.main.bundleIdentifier == nil {
            center = nil
        } else {
            center = UNUserNotificationCenter.current()
        }
    }

    var isAvailable: Bool { center != nil }

    var canDeliver: Bool {
        authorizationStatus == .authorized || authorizationStatus == .provisional
    }

    func configure() {
        guard let center else { return }
        center.delegate = delegateProxy
    }

    func clearLastError() {
        lastError = nil
    }

    func refreshAuthorizationStatus() async {
        guard let center else { return }
        let settings = await center.notificationSettings()
        authorizationStatus = settings.authorizationStatus
    }

    /// Only triggers the system prompt from an explicit user action.
    @discardableResult
    func requestAuthorizationIfNeeded() async -> Bool {
        guard let center else { return false }

        let settings = await center.notificationSettings()
        authorizationStatus = settings.authorizationStatus

        switch settings.authorizationStatus {
        case .notDetermined:
            do {
                let granted = try await center.requestAuthorization(options: [.alert, .sound])
                authorizationStatus = granted ? .authorized : .denied
                return granted
            } catch {
                lastError = "Notification permission could not be requested. \(error.localizedDescription)"
                return false
            }
        case .authorized, .provisional:
            return true
        default:
            return false
        }
    }

    /// Replaces all pending milestone requests with a fresh plan. Identifiers
    /// are deterministic, so a relaunch or an edit can never create duplicate
    /// alerts. Past milestones are never queued.
    func syncSchedule(goals: [Goal], preferences: AppPreferences) async {
        guard let center else { return }

        let settings = await center.notificationSettings()
        authorizationStatus = settings.authorizationStatus

        let pending = await center.pendingNotificationRequests()
        let staleIDs = pending
            .map(\.identifier)
            .filter { $0.hasPrefix(Self.milestonePrefix) }
        if !staleIDs.isEmpty {
            center.removePendingNotificationRequests(withIdentifiers: staleIDs)
        }

        guard preferences.notificationsEnabled, canDeliver else {
            lastError = nil
            return
        }

        let now = Date()
        let plan = MilestonePlanner.plan(
            goals: goals,
            milestones: preferences.notificationMilestones,
            now: now,
            limit: 60
        )

        var failureCount = 0
        for item in plan {
            let request = makeRequest(
                for: item,
                thresholds: preferences.thresholds,
                timeZone: .current
            )
            do {
                try await center.add(request)
            } catch {
                failureCount += 1
            }
        }

        lastError = failureCount > 0
            ? "Some reminders could not be scheduled. \(failureCount) of \(plan.count) failed."
            : nil
    }

    func sendTestNotification() async {
        guard let center else { return }
        guard await requestAuthorizationIfNeeded() else { return }

        center.removePendingNotificationRequests(withIdentifiers: [Self.testIdentifier])

        let content = UNMutableNotificationContent()
        content.title = "GoalPulse"
        content.subtitle = "🎯 Notifications are ready"
        content.body = "You'll be reminded as each milestone approaches. You can change this in Settings."
        content.sound = .default
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 3, repeats: false)
        let request = UNNotificationRequest(
            identifier: Self.testIdentifier,
            content: content,
            trigger: trigger
        )
        do {
            try await center.add(request)
            lastError = nil
        } catch {
            lastError = "The test notification could not be scheduled. \(error.localizedDescription)"
        }
    }

    func openSystemNotificationSettings() {
        let candidates = [
            "x-apple.systempreferences:com.apple.Notifications-Settings.extension",
            "x-apple.systempreferences:com.apple.preference.notifications"
        ]
        for candidate in candidates {
            if let url = URL(string: candidate) {
                NSWorkspace.shared.open(url)
                return
            }
        }
    }

    private func makeRequest(
        for item: PlannedMilestone,
        thresholds: EmojiThresholds,
        timeZone: TimeZone
    ) -> UNNotificationRequest {
        let mood = item.goal.mood(at: item.fireDate, thresholds: thresholds)
        let emoji = item.goal.displayEmoji(for: mood)

        let content = UNMutableNotificationContent()
        content.title = item.goal.trimmedTitle
        content.subtitle = "\(emoji) \(item.milestone.remainingPhrase)"
        content.body = "\(mood.motivation) Deadline: \(item.goal.deadline.formatted(date: .abbreviated, time: .shortened))."
        content.sound = item.milestone.usesSound ? .default : nil
        content.userInfo = [
            "goalID": item.goal.id.uuidString,
            "milestone": item.milestone.rawValue
        ]

        var components = Calendar.current.dateComponents(
            [.year, .month, .day, .hour, .minute, .second],
            from: item.fireDate
        )
        // Include the zone so the trigger resolves to the intended absolute
        // instant, even if the system zone changes before it fires.
        components.timeZone = timeZone
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)

        return UNNotificationRequest(
            identifier: Self.milestonePrefix + item.id,
            content: content,
            trigger: trigger
        )
    }
}

private final class NotificationDelegateProxy: NSObject, UNUserNotificationCenterDelegate {
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void
    ) {
        // The user explicitly opted into milestones; still surface them when
        // GoalPulse is frontmost instead of silently swallowing the banner.
        completionHandler([.banner, .list, .sound])
    }
}

extension NotificationMilestone {
    var shortLabel: String {
        switch self {
        case .sevenDays: return "7 days"
        case .oneDay: return "24 hours"
        case .oneHour: return "1 hour"
        case .tenMinutes: return "10 minutes"
        }
    }

    var reminderDetail: String {
        switch self {
        case .sevenDays: return "A week to go"
        case .oneDay: return "One day to go"
        case .oneHour: return "One hour to go"
        case .tenMinutes: return "Final 10 minutes"
        }
    }

    var remainingPhrase: String {
        "\(shortLabel) remaining"
    }

    var usesSound: Bool {
        self == .oneHour || self == .tenMinutes
    }
}

extension UNAuthorizationStatus {
    var goalPulseLabel: String {
        switch self {
        case .notDetermined: return "Not requested"
        case .denied: return "Denied in System Settings"
        case .authorized: return "Allowed"
        case .provisional: return "Delivered quietly"
        case .ephemeral: return "Temporary permission"
        @unknown default: return "Unknown"
        }
    }
}
