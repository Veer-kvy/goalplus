import AppKit
import Foundation
import GoalPulseCore
import Observation

/// App-wide coordinator that owns persistence, settings, the shared clock and
/// system integrations. Views talk to this object; they never perform disk or
/// notification work themselves.
@MainActor
@Observable
final class AppModel {
    static let shared = AppModel()

    let store: GoalStore
    let settings: SettingsStore
    let clock: CountdownClock
    let notifications: NotificationManager
    let launchAtLogin: LaunchAtLoginService

    private var didStart = false
    private var notificationSyncTask: Task<Void, Never>?

    init(
        store: GoalStore? = nil,
        settings: SettingsStore? = nil,
        clock: CountdownClock? = nil,
        notifications: NotificationManager? = nil,
        launchAtLogin: LaunchAtLoginService? = nil
    ) {
        self.store = store ?? GoalStore()
        self.settings = settings ?? SettingsStore()
        self.clock = clock ?? CountdownClock()
        self.notifications = notifications ?? NotificationManager()
        self.launchAtLogin = launchAtLogin ?? LaunchAtLoginService()
    }

    var activeGoal: Goal? { store.activeGoal }

    func start() {
        guard !didStart else { return }
        didStart = true

        clock.start()
        notifications.configure()
        launchAtLogin.refresh()

        Task { await notifications.refreshAuthorizationStatus() }
        scheduleNotificationSync()
    }

    func stop() {
        notificationSyncTask?.cancel()
        clock.stop()
    }

    func refreshAfterSystemChange(syncNotifications: Bool) {
        clock.refresh()
        launchAtLogin.refresh()
        if syncNotifications {
            scheduleNotificationSync()
        }
    }

    func countdown(for goal: Goal, at now: Date? = nil) -> GoalCountdown {
        goal.countdown(at: now ?? clock.now)
    }

    func mood(for goal: Goal, at now: Date? = nil) -> EmojiMood {
        goal.mood(at: now ?? clock.now, thresholds: settings.preferences.thresholds)
    }

    @discardableResult
    func addGoal(_ goal: Goal) -> Bool {
        let added = store.add(goal)
        if added { scheduleNotificationSync() }
        return added
    }

    @discardableResult
    func updateGoal(_ goal: Goal) -> Bool {
        let updated = store.update(goal)
        if updated { scheduleNotificationSync() }
        return updated
    }

    func deleteGoal(id: UUID) {
        store.delete(id: id)
        scheduleNotificationSync()
    }

    func setActiveGoal(id: UUID) {
        store.setActive(id)
    }

    /// Called after the Settings view mutates `settings.preferences`.
    func preferencesDidChange() {
        scheduleNotificationSync()
    }

    func setNotificationsEnabled(_ enabled: Bool) async {
        if enabled {
            _ = await notifications.requestAuthorizationIfNeeded()
        }
        scheduleNotificationSync()
    }

    /// Debounces schedule churn while sliders/steppers are being adjusted.
    func scheduleNotificationSync() {
        notificationSyncTask?.cancel()
        let goals = store.goals
        let preferences = settings.preferences
        notificationSyncTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 120_000_000)
            guard !Task.isCancelled, let self else { return }
            await self.notifications.syncSchedule(goals: goals, preferences: preferences)
        }
    }

    func quit() {
        NSApp.terminate(nil)
    }
}
