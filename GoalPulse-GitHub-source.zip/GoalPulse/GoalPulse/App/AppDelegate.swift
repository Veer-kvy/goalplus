import AppKit
import Foundation

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var observers: [NSObjectProtocol] = []

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        AppModel.shared.start()
        installSystemObservers()
    }

    func applicationDidBecomeActive(_ notification: Notification) {
        // Force a fresh snapshot immediately when the user opens the popover.
        AppModel.shared.refreshAfterSystemChange(syncNotifications: false)
    }

    func applicationWillTerminate(_ notification: Notification) {
        AppModel.shared.stop()
        for observer in observers {
            NotificationCenter.default.removeObserver(observer)
            NSWorkspace.shared.notificationCenter.removeObserver(observer)
        }
        observers.removeAll()
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        false
    }

    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        true
    }

    private func installSystemObservers() {
        let center = NSWorkspace.shared.notificationCenter
        observers.append(center.addObserver(
            forName: NSWorkspace.didWakeNotification,
            object: nil,
            queue: .main
        ) { _ in
            Task { @MainActor in
                AppModel.shared.refreshAfterSystemChange(syncNotifications: true)
            }
        })

        for name in [Notification.Name.NSSystemClockDidChange, .NSSystemTimeZoneDidChange] {
            observers.append(NotificationCenter.default.addObserver(
                forName: name,
                object: nil,
                queue: .main
            ) { _ in
                Task { @MainActor in
                    AppModel.shared.refreshAfterSystemChange(syncNotifications: true)
                }
            })
        }
    }
}
