import SwiftUI

@main
struct GoalPulseApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    private var model: AppModel { AppModel.shared }

    var body: some Scene {
        MenuBarExtra {
            PopoverView()
                .environment(model)
                .preferredColorScheme(model.settings.preferences.theme.colorScheme)
                .onAppear { model.start() }
        } label: {
            MenuBarLabelView()
                .environment(model)
                .onAppear { model.start() }
        }
        .menuBarExtraStyle(.window)
    }
}
