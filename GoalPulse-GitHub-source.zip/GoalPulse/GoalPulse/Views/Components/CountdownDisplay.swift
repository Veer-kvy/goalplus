import GoalPulseCore
import SwiftUI

struct CountdownDisplay: View {
    let countdown: GoalCountdown
    let format: CountdownFormat
    let tint: Color
    let reduceMotion: Bool
    var valueSize: CGFloat = 27
    var labelSize: CGFloat = 8.5
    var inlineSize: CGFloat = 17.5
    var compactSize: CGFloat = 27

    var body: some View {
        Group {
            switch format {
            case .segmented:
                segmented
            case .inline:
                Text(GoalFormatting.fullCountdown(countdown))
                    .font(.system(size: inlineSize, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                    .lineLimit(1)
                    .minimumScaleFactor(0.62)
                    .frame(maxWidth: .infinity)
            case .compact:
                Text(GoalFormatting.compactCountdown(countdown))
                    .font(.system(size: compactSize, weight: .semibold, design: .rounded))
                    .monospacedDigit()
                    .lineLimit(1)
                    .minimumScaleFactor(0.62)
                    .frame(maxWidth: .infinity)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(GoalFormatting.accessibilityCountdown(countdown))
    }

    private var segmented: some View {
        HStack(alignment: .center, spacing: 1) {
            unit(value: countdown.days, label: "Days")
            colon
            unit(value: countdown.hours, label: "Hours")
            colon
            unit(value: countdown.minutes, label: "Minutes")
            colon
            unit(value: countdown.seconds, label: "Seconds")
        }
        .frame(maxWidth: .infinity)
    }

    private func unit(value: Int, label: String) -> some View {
        VStack(spacing: 1) {
            Text("\(value)")
                .font(.system(size: valueSize, weight: .semibold, design: .rounded))
                .monospacedDigit()
                .lineLimit(1)
                .minimumScaleFactor(0.48)
                .foregroundStyle(.primary)
            Text(label)
                .font(.system(size: labelSize, weight: .medium))
                .textCase(.uppercase)
                .tracking(0.55)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    private var colon: some View {
        Text(":")
            .font(.system(size: valueSize * 0.74, weight: .medium, design: .rounded))
            .foregroundStyle(.tertiary)
            .offset(y: -valueSize * 0.18)
            .accessibilityHidden(true)
    }
}

struct GoalProgressBar: View {
    let countdown: GoalCountdown
    let tint: Color
    let reduceMotion: Bool

    var body: some View {
        VStack(spacing: 6) {
            GeometryReader { proxy in
                ZStack(alignment: .leading) {
                    Capsule(style: .continuous)
                        .fill(Color.primary.opacity(0.08))
                        .overlay {
                            Capsule(style: .continuous)
                                .strokeBorder(Color.primary.opacity(0.05), lineWidth: 0.5)
                        }

                    Capsule(style: .continuous)
                        .fill(tint)
                        .frame(width: max(0, proxy.size.width * countdown.progress))
                }
            }
            .frame(height: 8)
            .animation(reduceMotion ? nil : .easeInOut(duration: 0.45), value: countdown.progress)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Goal progress")
            .accessibilityValue(GoalFormatting.progressAccessibilityValue(countdown))

            HStack(spacing: 8) {
                Text("\(GoalFormatting.wholePercent(countdown.progress))% elapsed")
                Spacer()
                Text("\(GoalFormatting.wholePercent(countdown.remainingFraction))% remaining")
            }
            .font(.system(size: 9.5, weight: .medium))
            .foregroundStyle(.secondary)
            .accessibilityHidden(true)
        }
    }
}
