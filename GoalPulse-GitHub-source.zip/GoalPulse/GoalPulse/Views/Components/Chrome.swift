import SwiftUI

struct GoalPulseMark: View {
    var tint: Color = .blue
    var size: CGFloat = 27

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.31, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [tint, tint.opacity(0.62)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )

            Image(systemName: "timer")
                .font(.system(size: size * 0.48, weight: .semibold))
                .foregroundStyle(.white)
        }
        .frame(width: size, height: size)
        .overlay {
            RoundedRectangle(cornerRadius: size * 0.31, style: .continuous)
                .strokeBorder(.white.opacity(0.22), lineWidth: 0.75)
        }
        .shadow(color: tint.opacity(0.28), radius: 5, y: 2)
        .accessibilityHidden(true)
    }
}

struct EmptyStateView: View {
    let systemImage: String
    let title: String
    let message: String
    var actionTitle: String?
    var action: (() -> Void)?
    var tint: Color = .blue

    var body: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(tint.opacity(0.055))
                    .frame(width: 142, height: 142)

                Circle()
                    .strokeBorder(
                        tint.opacity(0.13),
                        style: StrokeStyle(lineWidth: 1, dash: [3, 6])
                    )
                    .frame(width: 112, height: 112)

                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [tint, tint.opacity(0.62)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 54, height: 54)
                    .overlay {
                        Image(systemName: systemImage)
                            .font(.system(size: 22, weight: .semibold))
                            .foregroundStyle(.white)
                    }
                    .shadow(color: tint.opacity(0.25), radius: 8, y: 3)

                Image(systemName: "sparkle")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(tint.opacity(0.7))
                    .offset(x: 53, y: -40)

                Image(systemName: "sparkle")
                    .font(.system(size: 7, weight: .semibold))
                    .foregroundStyle(tint.opacity(0.5))
                    .offset(x: -46, y: 38)
            }
            .accessibilityHidden(true)

            VStack(spacing: 4) {
                Text(title)
                    .font(.system(size: 15.5, weight: .semibold))
                    .multilineTextAlignment(.center)

                Text(message)
                    .font(.system(size: 10.5))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
                    .padding(.horizontal, 10)
            }

            if let actionTitle, let action {
                Button(action: action) {
                    Text(actionTitle)
                        .font(.system(size: 11, weight: .semibold))
                        .padding(.horizontal, 6)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .tint(tint)
                .padding(.top, 2)
            }
        }
        .frame(maxWidth: .infinity)
    }
}

struct SubscreenHeader: View {
    let title: String
    var subtitle: String?
    var trailing: AnyView?
    let onBack: () -> Void

    init(
        title: String,
        subtitle: String? = nil,
        trailing: AnyView? = nil,
        onBack: @escaping () -> Void
    ) {
        self.title = title
        self.subtitle = subtitle
        self.trailing = trailing
        self.onBack = onBack
    }

    var body: some View {
        HStack(spacing: 8) {
            ToolbarIconButton(systemName: "chevron.left", help: "Back", action: onBack)

            VStack(alignment: .leading, spacing: 1) {
                Text(title)
                    .font(.system(size: 13, weight: .semibold))
                if let subtitle {
                    Text(subtitle)
                        .font(.system(size: 10))
                        .foregroundStyle(.secondary)
                }
            }

            Spacer(minLength: 8)

            if let trailing {
                trailing
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 10)
    }
}

enum NoticeKind {
    case warning
    case error
    case info

    var color: Color {
        switch self {
        case .warning: return .orange
        case .error: return .red
        case .info: return .blue
        }
    }

    var icon: String {
        switch self {
        case .warning: return "exclamationmark.triangle.fill"
        case .error: return "xmark.octagon.fill"
        case .info: return "info.circle.fill"
        }
    }
}

struct NoticeBanner: View {
    let kind: NoticeKind
    let message: String
    var onDismiss: (() -> Void)?

    var body: some View {
        HStack(alignment: .top, spacing: 7) {
            Image(systemName: kind.icon)
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(kind.color)
                .padding(.top, 1)

            Text(message)
                .font(.system(size: 10.5))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Spacer(minLength: 4)

            if let onDismiss {
                Button(action: onDismiss) {
                    Image(systemName: "xmark")
                        .font(.system(size: 8, weight: .semibold))
                        .foregroundStyle(.secondary)
                        .frame(width: 16, height: 16)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Dismiss")
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(kind.color.opacity(0.09), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .strokeBorder(kind.color.opacity(0.20), lineWidth: 1)
        }
    }
}

struct SectionEyebrow: View {
    let text: String

    var body: some View {
        Text(text)
            .font(.system(size: 9, weight: .semibold))
            .textCase(.uppercase)
            .tracking(0.7)
            .foregroundStyle(.secondary)
    }
}

struct SmallChipButton: View {
    let title: String
    var systemImage: String?
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 4) {
                if let systemImage {
                    Image(systemName: systemImage)
                        .font(.system(size: 8.5, weight: .semibold))
                }
                Text(title)
                    .font(.system(size: 9.5, weight: .medium))
            }
            .foregroundStyle(.secondary)
            .padding(.horizontal, 7)
            .padding(.vertical, 4)
            .background(Color.primary.opacity(0.05), in: Capsule())
            .overlay {
                Capsule().strokeBorder(Color.primary.opacity(0.07), lineWidth: 0.5)
            }
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}

struct FooterLinks: View {
    let goalCount: Int
    let onGoals: () -> Void
    let onQuit: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            if goalCount > 0 {
                Button {
                    onGoals()
                } label: {
                    Label(goalCount == 1 ? "All goals" : "All goals (\(goalCount))", systemImage: "square.stack")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
                .help("Manage goals")
            }

            Spacer(minLength: 0)

            Label("On-device", systemImage: "lock.fill")
                .font(.system(size: 9.5))
                .foregroundStyle(.tertiary)
                .accessibilityLabel("Goals are stored only on this Mac")

            Button("Quit", action: onQuit)
                .buttonStyle(.plain)
                .font(.system(size: 10, weight: .medium))
                .foregroundStyle(.tertiary)
                .help("Quit GoalPulse")
        }
        .padding(.horizontal, 2)
    }
}

struct FieldLabel: View {
    let text: String
    var trailing: String?

    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            SectionEyebrow(text: text)
            Spacer(minLength: 6)
            if let trailing {
                Text(trailing)
                    .font(.system(size: 9))
                    .foregroundStyle(.tertiary)
            }
        }
    }
}

struct EmojiSuggestionRow: View {
    let selected: String
    let tint: Color
    let onSelect: (String) -> Void

    private let suggestions = ["😎", "🎯", "🔥", "🚀", "🌱", "📚", "💪", "✨"]

    var body: some View {
        HStack(spacing: 5) {
            ForEach(suggestions, id: \.self) { emoji in
                Button {
                    onSelect(emoji)
                } label: {
                    Text(emoji)
                        .font(.system(size: 15))
                        .frame(width: 25, height: 25)
                        .background {
                            Circle()
                                .fill(selected == emoji ? tint.opacity(0.18) : Color.clear)
                        }
                        .overlay {
                            if selected == emoji {
                                Circle().strokeBorder(tint.opacity(0.35), lineWidth: 1)
                            }
                        }
                        .contentShape(Circle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Use emoji \(emoji)")
            }
            Spacer(minLength: 0)
        }
    }
}

struct AccentPickerRow: View {
    let selection: String?
    let tint: Color
    let onSelect: (String?) -> Void

    var body: some View {
        HStack(spacing: 6) {
            Button {
                onSelect(nil)
            } label: {
                ZStack {
                    Circle()
                        .fill(
                            AngularGradient(
                                colors: [.blue, .teal, .indigo, .pink, .orange, .green, .blue],
                                center: .center
                            )
                        )
                        .frame(width: 17, height: 17)
                        .opacity(0.9)
                    if selection == nil {
                        Circle()
                            .fill(.black.opacity(0.55))
                            .frame(width: 17, height: 17)
                        Image(systemName: "checkmark")
                            .font(.system(size: 8, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }
                .overlay {
                    if selection == nil {
                        Circle().strokeBorder(Color.primary.opacity(0.6), lineWidth: 1.5).padding(-2)
                    }
                }
                .contentShape(Circle())
            }
            .buttonStyle(.plain)
            .help("Automatic — follows the countdown mood")
            .accessibilityLabel("Automatic accent color")

            ForEach(GoalAccent.allCases) { accent in
                Button {
                    onSelect(accent.rawValue)
                } label: {
                    Circle()
                        .fill(accent.color)
                        .frame(width: 17, height: 17)
                        .overlay {
                            if selection == accent.rawValue {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 8, weight: .bold))
                                    .foregroundStyle(.white)
                            }
                        }
                        .overlay {
                            if selection == accent.rawValue {
                                Circle().strokeBorder(Color.primary.opacity(0.6), lineWidth: 1.5).padding(-2)
                            }
                        }
                        .contentShape(Circle())
                }
                .buttonStyle(.plain)
                .help(accent.name)
                .accessibilityLabel("\(accent.name) accent")
            }

            Spacer(minLength: 0)

            Circle()
                .fill(tint)
                .frame(width: 4, height: 4)
                .opacity(0)
        }
    }
}
