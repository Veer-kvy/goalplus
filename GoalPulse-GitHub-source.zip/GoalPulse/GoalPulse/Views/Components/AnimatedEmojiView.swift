import AppKit
import GoalPulseCore
import SwiftUI

/// Animated pixel-art emoji with a tinted aura.
///
/// The six mood emoji are hand-drawn on a 16×16 grid and rasterised with
/// nearest-neighbour scaling, so they stay crisp at any size. Custom emoji
/// supplied by the user are down-sampled to the same grid and up-scaled
/// without smoothing. Sprite motion is driven by lightweight SwiftUI
/// animations plus a frame task that only runs while the popover is open;
/// Reduce Motion and the animation setting keep everything still.
struct AnimatedEmojiView: View {
    let emoji: String
    let mood: EmojiMood
    let intensity: AnimationIntensity
    let reduceMotion: Bool
    var size: CGFloat = 52

    @State private var isPulsing = false
    @State private var isBobbing = false
    @State private var frameIndex = 0
    @State private var bounceScale: CGFloat = 1

    private var motionAllowed: Bool {
        !reduceMotion && intensity != .off
    }

    private var pixelMood: EmojiMood? {
        EmojiMood.allCases.first { $0.defaultEmoji == emoji }
    }

    private var frameSchedule: PixelFrameSchedule {
        guard let pixelMood, motionAllowed else { return .none }
        switch pixelMood {
        case .calm: return .alternate(1.8)
        case .steady: return .blink(interval: 2.9, duration: 0.14)
        case .focus: return .alternate(1.7)
        case .intense: return .alternate(0.42)
        case .urgent: return .alternate(0.55)
        case .complete: return .alternate(1.25)
        }
    }

    var body: some View {
        ZStack {
            Circle()
                .fill(
                    RadialGradient(
                        colors: [mood.tint.opacity(intensity.glowOpacity), mood.tint.opacity(0)],
                        center: .center,
                        startRadius: size * 0.10,
                        endRadius: size * 0.78
                    )
                )
                .frame(width: size * 1.55, height: size * 1.55)
                .scaleEffect(isPulsing ? 1.06 : 0.94)
                .opacity(isPulsing ? 1 : 0.6)

            RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [mood.tint.opacity(0.17), mood.tint.opacity(0.035)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: size + 4, height: size + 4)
                .overlay {
                    RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                        .strokeBorder(mood.tint.opacity(0.22), lineWidth: 1)
                }

            PixelEmojiSprite(emoji: emoji, frame: frameIndex, size: size)
                .shadow(color: .black.opacity(0.16), radius: size * 0.07, y: size * 0.035)
                .offset(y: isBobbing ? -bobDistance : 0)
                .scaleEffect(bounceScale * (isPulsing ? 1 + intensity.pulseScale * 0.4 : 1))

            pixelAccents
        }
        .frame(width: size + 18, height: size + 18)
        .onAppear(perform: restartMotion)
        .onChange(of: motionAllowed) { _, _ in restartMotion() }
        .onChange(of: mood) { _, _ in bounceForChange() }
        .onChange(of: emoji) { _, _ in bounceForChange() }
        .task(id: taskID) {
            frameIndex = 0
            switch frameSchedule {
            case .none:
                return
            case .blink(let interval, let duration):
                do {
                    while !Task.isCancelled {
                        try await Task.sleep(nanoseconds: nanoseconds(interval))
                        frameIndex = 1
                        try await Task.sleep(nanoseconds: nanoseconds(duration))
                        frameIndex = 0
                    }
                } catch {
                    frameIndex = 0
                }
            case .alternate(let interval):
                do {
                    while !Task.isCancelled {
                        try await Task.sleep(nanoseconds: nanoseconds(interval))
                        frameIndex = frameIndex == 0 ? 1 : 0
                    }
                } catch {
                    frameIndex = 0
                }
            }
        }
        .accessibilityHidden(true)
    }

    private var pixelAccents: some View {
        ZStack {
            Rectangle()
                .fill(mood.tint.opacity(0.62))
                .frame(width: 3, height: 3)
                .offset(x: size * 0.5 + 3, y: -size * 0.5 - 2)

            Rectangle()
                .fill(mood.tint.opacity(0.32))
                .frame(width: 2, height: 2)
                .offset(x: -size * 0.5 - 4, y: size * 0.5 - 2)
        }
        .opacity(isPulsing ? 1 : 0.55)
    }

    private var taskID: String {
        "\(emoji)|\(mood.rawValue)|\(motionAllowed)"
    }

    private var bobDistance: CGFloat {
        switch intensity {
        case .off: return 0
        case .subtle: return 1.1
        case .balanced: return 2.0
        case .lively: return 3.2
        }
    }

    private var bobDuration: Double {
        switch intensity {
        case .off: return 0
        case .subtle: return 4.6
        case .balanced: return 3.6
        case .lively: return 2.7
        }
    }

    private func nanoseconds(_ seconds: Double) -> UInt64 {
        UInt64(max(0.01, seconds) * 1_000_000_000)
    }

    private func restartMotion() {
        guard motionAllowed else {
            withAnimation(.easeOut(duration: 0.2)) {
                isPulsing = false
                isBobbing = false
            }
            return
        }

        isPulsing = false
        isBobbing = false
        withAnimation(
            .easeInOut(duration: max(1.4, intensity.pulseDuration))
                .repeatForever(autoreverses: true)
        ) {
            isPulsing = true
        }
        withAnimation(
            .easeInOut(duration: bobDuration)
                .repeatForever(autoreverses: true)
        ) {
            isBobbing = true
        }
    }

    private func bounceForChange() {
        frameIndex = 0
        guard motionAllowed else { return }
        bounceScale = 1.13
        withAnimation(.spring(response: 0.32, dampingFraction: 0.48)) {
            bounceScale = 1
        }
    }
}

// MARK: - Sprite view

struct PixelEmojiSprite: View {
    let emoji: String
    var frame: Int = 0
    var size: CGFloat

    var body: some View {
        Group {
            if let image = PixelEmojiImages.image(emoji: emoji, frame: frame, pointSize: size) {
                Image(nsImage: image)
                    .interpolation(.none)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } else {
                Text(emoji)
                    .font(.system(size: size * 0.78))
            }
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}

private enum PixelFrameSchedule {
    case none
    case blink(interval: Double, duration: Double)
    case alternate(Double)
}

// MARK: - Rasterised sprites

private enum PixelEmojiImages {
    private static let moodGrid = 16
    private static let glyphGrid = 24
    private static let cache = NSCache<NSString, NSImage>()

    static func mood(for emoji: String) -> EmojiMood? {
        EmojiMood.allCases.first { $0.defaultEmoji == emoji }
    }

    static func image(emoji: String, frame: Int, pointSize: CGFloat) -> NSImage? {
        let points = max(16, Int(pointSize.rounded()))
        let pixels = points * 2

        if let artMood = mood(for: emoji) {
            let frameIndex = abs(frame) % 2
            let key = "mood.\(artMood.rawValue).\(frameIndex).\(pixels)" as NSString
            if let cached = cache.object(forKey: key) {
                return cached
            }
            guard let image = renderMood(
                artMood,
                frame: frameIndex,
                pixels: pixels,
                points: CGFloat(points)
            ) else { return nil }
            cache.setObject(image, forKey: key)
            return image
        }

        let key = "glyph.\(emoji).\(pixels)" as NSString
        if let cached = cache.object(forKey: key) {
            return cached
        }
        guard let image = renderGlyph(emoji, pixels: pixels, points: CGFloat(points)) else {
            return nil
        }
        cache.setObject(image, forKey: key)
        return image
    }

    private static func renderMood(
        _ mood: EmojiMood,
        frame: Int,
        pixels: Int,
        points: CGFloat
    ) -> NSImage? {
        guard let context = makeContext(pixels: pixels) else { return nil }
        let cellSize = CGFloat(pixels) / CGFloat(moodGrid)
        context.scaleBy(x: cellSize, y: cellSize)

        switch mood {
        case .calm: drawCalm(context, frame)
        case .steady: drawSteady(context, frame)
        case .focus: drawTarget(context, frame: frame)
        case .intense: drawFlame(context, frame: frame)
        case .urgent: drawSiren(context, frame: frame)
        case .complete: drawTrophy(context, frame: frame)
        }

        guard let cgImage = context.makeImage() else { return nil }
        return NSImage(cgImage: cgImage, size: NSSize(width: points, height: points))
    }

    private static func makeContext(pixels: Int) -> CGContext? {
        guard let space = CGColorSpace(name: CGColorSpace.sRGB),
              let context = CGContext(
                data: nil,
                width: pixels,
                height: pixels,
                bitsPerComponent: 8,
                bytesPerRow: pixels * 4,
                space: space,
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue
                    | CGBitmapInfo.byteOrder32Big.rawValue
              )
        else { return nil }

        context.clear(CGRect(x: 0, y: 0, width: pixels, height: pixels))
        context.setShouldAntialias(false)
        context.interpolationQuality = .none
        return context
    }

    private static func renderGlyph(_ emoji: String, pixels: Int, points: CGFloat) -> NSImage? {
        guard let source = renderGlyphSource(emoji),
              let cgSource = source.cgImage,
              let context = makeContext(pixels: pixels)
        else { return nil }

        context.interpolationQuality = .none
        context.draw(
            cgSource,
            in: CGRect(x: 0, y: 0, width: pixels, height: pixels)
        )
        guard let cgImage = context.makeImage() else { return nil }
        return NSImage(cgImage: cgImage, size: NSSize(width: points, height: points))
    }

    private static func renderGlyphSource(_ emoji: String) -> NSBitmapImageRep? {
        guard let bitmap = NSBitmapImageRep(
            bitmapDataPlanes: nil,
            pixelsWide: glyphGrid,
            pixelsHigh: glyphGrid,
            bitsPerSample: 8,
            samplesPerPixel: 4,
            hasAlpha: true,
            isPlanar: false,
            colorSpaceName: .deviceRGB,
            bytesPerRow: glyphGrid * 4,
            bitsPerPixel: 32
        ),
        let graphics = NSGraphicsContext(bitmapImageRep: bitmap)
        else { return nil }

        bitmap.size = NSSize(width: glyphGrid, height: glyphGrid)
        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = graphics
        graphics.imageInterpolation = .high
        graphics.cgContext.setShouldAntialias(true)

        let baseSize: CGFloat = 24
        let baseFont = NSFont(name: "Apple Color Emoji", size: baseSize)
            ?? NSFont.systemFont(ofSize: baseSize)
        let baseMeasured = NSAttributedString(
            string: emoji,
            attributes: [.font: baseFont]
        ).size()
        let fit = min(
            CGFloat(glyphGrid) / max(1, baseMeasured.width),
            CGFloat(glyphGrid) / max(1, baseMeasured.height)
        )
        let font = NSFont(name: "Apple Color Emoji", size: baseSize * fit)
            ?? NSFont.systemFont(ofSize: baseSize * fit)
        let attributed = NSAttributedString(string: emoji, attributes: [.font: font])
        let measured = attributed.size()
        attributed.draw(
            at: NSPoint(
                x: (CGFloat(glyphGrid) - measured.width) / 2,
                y: (CGFloat(glyphGrid) - measured.height) / 2
            )
        )
        NSGraphicsContext.restoreGraphicsState()
        return bitmap
    }
}

// MARK: - Pixel drawing

private struct RGBA {
    let red: CGFloat
    let green: CGFloat
    let blue: CGFloat
    let alpha: CGFloat

    init(hex: UInt32, alpha: CGFloat = 1) {
        red = CGFloat((hex >> 16) & 0xFF) / 255
        green = CGFloat((hex >> 8) & 0xFF) / 255
        blue = CGFloat(hex & 0xFF) / 255
        self.alpha = alpha
    }

    var cgColor: CGColor {
        CGColor(red: red, green: green, blue: blue, alpha: alpha)
    }
}

private enum SpritePalette {
    static let ink = RGBA(hex: 0x2A211F)
    static let face = RGBA(hex: 0xFFD447)
    static let faceLight = RGBA(hex: 0xFFEAA0)
    static let faceShade = RGBA(hex: 0xEAAF2E)
    static let feature = RGBA(hex: 0x3A2521)
    static let blush = RGBA(hex: 0xF08A72)
    static let lens = RGBA(hex: 0x24242D)
    static let glint = RGBA(hex: 0xFFFEF7)

    static let paper = RGBA(hex: 0xFFF7E4)
    static let paperLight = RGBA(hex: 0xFFFFFF)
    static let targetRed = RGBA(hex: 0xE7483F)
    static let targetDeep = RGBA(hex: 0xA82A28)
    static let steel = RGBA(hex: 0x8E9AAB)

    static let gold = RGBA(hex: 0xFFC83C)
    static let goldLight = RGBA(hex: 0xFFEAA0)
    static let goldShade = RGBA(hex: 0xD6971B)

    static let flameEdge = RGBA(hex: 0xA8311D)
    static let flameOrange = RGBA(hex: 0xFF7A1C)
    static let flameYellow = RGBA(hex: 0xFFC93C)
    static let flameCream = RGBA(hex: 0xFFF2C0)

    static let sirenBright = RGBA(hex: 0xFF6653)
    static let sirenDeep = RGBA(hex: 0xB61F2B)
    static let sirenGlow = RGBA(hex: 0xFFD96B)
    static let sirenGlowDim = RGBA(hex: 0xC59543)
    static let metalLight = RGBA(hex: 0xD7DFEA)
    static let metalMid = RGBA(hex: 0x94A1B4)
    static let metalDark = RGBA(hex: 0x4F5A6D)
}

private enum Pixel {
    static let grid = 16

    static func set(_ context: CGContext, _ x: Int, _ y: Int, _ color: RGBA) {
        guard x >= 0, x < grid, y >= 0, y < grid else { return }
        context.setFillColor(color.cgColor)
        context.fill(CGRect(x: x, y: grid - 1 - y, width: 1, height: 1))
    }

    static func fill(
        _ context: CGContext,
        x: Int,
        y: Int,
        width: Int,
        height: Int,
        color: RGBA
    ) {
        guard width > 0, height > 0 else { return }
        for row in y..<(y + height) {
            for column in x..<(x + width) {
                set(context, column, row, color)
            }
        }
    }

    static func row(_ context: CGContext, y: Int, from: Int, to: Int, color: RGBA) {
        guard from <= to else { return }
        fill(context, x: from, y: y, width: to - from + 1, height: 1, color: color)
    }

    static func ellipse(
        _ context: CGContext,
        cx: CGFloat,
        cy: CGFloat,
        rx: CGFloat,
        ry: CGFloat,
        color: RGBA
    ) {
        guard rx > 0, ry > 0 else { return }
        for y in 0..<grid {
            for x in 0..<grid {
                let dx = (CGFloat(x) + 0.5 - cx) / rx
                let dy = (CGFloat(y) + 0.5 - cy) / ry
                if dx * dx + dy * dy <= 1 {
                    set(context, x, y, color)
                }
            }
        }
    }
}

// MARK: - Mood sprites

private func drawSteady(_ context: CGContext, _ frame: Int) {
    drawFace(.steady, context, frame)
}

private func drawCalm(_ context: CGContext, _ frame: Int) {
    drawFace(.calm, context, frame)
}

private func drawFace(_ mood: EmojiMood, _ context: CGContext, _ frame: Int) {
    drawFaceBase(context)

    if mood == .calm {
        drawSunglasses(context, frame: frame)
        Pixel.fill(context, x: 6, y: 10, width: 4, height: 1, color: SpritePalette.feature)
        Pixel.set(context, 10, 9, SpritePalette.feature)
        return
    }

    if frame == 0 {
        Pixel.fill(context, x: 4, y: 5, width: 2, height: 2, color: SpritePalette.ink)
        Pixel.fill(context, x: 10, y: 5, width: 2, height: 2, color: SpritePalette.ink)
        Pixel.set(context, 4, 5, SpritePalette.glint)
        Pixel.set(context, 10, 5, SpritePalette.glint)
    } else {
        Pixel.fill(context, x: 4, y: 6, width: 2, height: 1, color: SpritePalette.ink)
        Pixel.fill(context, x: 10, y: 6, width: 2, height: 1, color: SpritePalette.ink)
    }

    Pixel.fill(context, x: 2, y: 8, width: 2, height: 1, color: SpritePalette.blush)
    Pixel.fill(context, x: 12, y: 8, width: 2, height: 1, color: SpritePalette.blush)
    Pixel.set(context, 5, 9, SpritePalette.feature)
    Pixel.set(context, 10, 9, SpritePalette.feature)
    Pixel.fill(context, x: 6, y: 10, width: 4, height: 1, color: SpritePalette.feature)
}

private func drawFaceBase(_ context: CGContext) {
    Pixel.ellipse(
        context,
        cx: 7.5,
        cy: 8.2,
        rx: 7.1,
        ry: 7.1,
        color: SpritePalette.ink
    )
    Pixel.ellipse(
        context,
        cx: 7.5,
        cy: 8.2,
        rx: 6.35,
        ry: 6.35,
        color: SpritePalette.face
    )

    Pixel.set(context, 4, 3, SpritePalette.faceLight)
    Pixel.set(context, 5, 3, SpritePalette.faceLight)
    Pixel.set(context, 3, 4, SpritePalette.faceLight)
    Pixel.set(context, 4, 4, SpritePalette.faceLight)
    Pixel.set(context, 3, 5, SpritePalette.faceLight)

    for y in 0..<Pixel.grid {
        for x in 0..<Pixel.grid {
            let dx = (CGFloat(x) + 0.5 - 7.5) / 6.35
            let dy = (CGFloat(y) + 0.5 - 8.2) / 6.35
            let distance = dx * dx + dy * dy
            if distance <= 1, distance > 0.58, x > 9, y > 9 {
                Pixel.set(context, x, y, SpritePalette.faceShade)
            }
        }
    }
}

private func drawSunglasses(_ context: CGContext, frame: Int) {
    Pixel.row(context, y: 4, from: 2, to: 13, color: SpritePalette.lens)
    Pixel.fill(context, x: 2, y: 5, width: 5, height: 2, color: SpritePalette.lens)
    Pixel.fill(context, x: 9, y: 5, width: 5, height: 2, color: SpritePalette.lens)
    Pixel.fill(context, x: 7, y: 5, width: 2, height: 1, color: SpritePalette.lens)
    Pixel.row(context, y: 7, from: 3, to: 6, color: SpritePalette.lens)
    Pixel.row(context, y: 7, from: 9, to: 12, color: SpritePalette.lens)

    if frame == 0 {
        Pixel.set(context, 3, 5, SpritePalette.glint)
        Pixel.set(context, 10, 5, SpritePalette.glint)
    } else {
        Pixel.set(context, 4, 6, SpritePalette.glint)
        Pixel.set(context, 11, 6, SpritePalette.glint)
    }
}

private func drawTarget(_ context: CGContext, frame: Int) {
    let cx: CGFloat = 7.5
    let cy: CGFloat = 8
    Pixel.ellipse(context, cx: cx, cy: cy, rx: 7.15, ry: 7.15, color: SpritePalette.targetDeep)
    Pixel.ellipse(context, cx: cx, cy: cy, rx: 6.55, ry: 6.55, color: SpritePalette.paper)
    Pixel.ellipse(context, cx: cx, cy: cy, rx: 5.2, ry: 5.2, color: SpritePalette.targetRed)
    Pixel.ellipse(context, cx: cx, cy: cy, rx: 3.55, ry: 3.55, color: SpritePalette.paper)
    Pixel.ellipse(context, cx: cx, cy: cy, rx: 1.9, ry: 1.9, color: SpritePalette.targetRed)

    Pixel.set(context, 13, 1, SpritePalette.targetRed)
    Pixel.set(context, 14, 1, SpritePalette.paper)
    Pixel.set(context, 14, 2, SpritePalette.targetRed)
    Pixel.set(context, 13, 2, SpritePalette.steel)
    Pixel.set(context, 12, 3, SpritePalette.steel)
    Pixel.set(context, 11, 4, SpritePalette.steel)
    Pixel.set(context, 10, 5, SpritePalette.steel)
    Pixel.set(context, 9, 6, SpritePalette.steel)
    Pixel.set(context, 8, 7, SpritePalette.goldLight)

    if frame == 0 {
        Pixel.set(context, 7, 7, SpritePalette.paperLight)
    } else {
        Pixel.set(context, 6, 5, SpritePalette.paperLight)
    }
}

private let flameFrameA: [ClosedRange<Int>?] = [
    7...8, 6...9, 6...10, 5...10, 4...11, 4...11, 3...12,
    3...12, 2...13, 2...13, 3...13, 4...12, 5...11, 6...10
]

private let flameFrameB: [ClosedRange<Int>?] = [
    7...9, 6...9, 5...10, 5...11, 4...11, 3...11, 3...12,
    2...12, 2...13, 3...13, 3...12, 4...12, 5...10, 6...9
]

private func drawFlame(_ context: CGContext, frame: Int) {
    let ranges = frame == 0 ? flameFrameA : flameFrameB

    for (offset, range) in ranges.enumerated() {
        guard let range else { continue }
        Pixel.row(context, y: offset + 1, from: range.lowerBound, to: range.upperBound, color: SpritePalette.flameEdge)
    }

    for (offset, range) in ranges.enumerated() {
        guard let range else { continue }
        let y = offset + 1
        if y >= 2 {
            Pixel.row(context, y: y, from: range.lowerBound + 1, to: range.upperBound - 1, color: SpritePalette.flameOrange)
        }
        if y >= 5 {
            Pixel.row(context, y: y, from: range.lowerBound + 2, to: range.upperBound - 2, color: SpritePalette.flameYellow)
        }
        if y >= 9 {
            Pixel.row(context, y: y, from: range.lowerBound + 3, to: range.upperBound - 3, color: SpritePalette.flameCream)
        }
    }

    if frame == 0 {
        Pixel.set(context, 11, 0, SpritePalette.flameOrange)
        Pixel.set(context, 4, 2, SpritePalette.flameYellow)
    } else {
        Pixel.set(context, 4, 0, SpritePalette.flameOrange)
        Pixel.set(context, 12, 4, SpritePalette.flameYellow)
    }
}

private func drawSiren(_ context: CGContext, frame: Int) {
    if frame == 0 {
        Pixel.set(context, 1, 3, SpritePalette.sirenGlow)
        Pixel.set(context, 2, 2, SpritePalette.sirenGlow)
        Pixel.set(context, 1, 7, SpritePalette.sirenGlowDim)
        Pixel.set(context, 2, 8, SpritePalette.sirenGlowDim)
    } else {
        Pixel.set(context, 14, 3, SpritePalette.sirenGlow)
        Pixel.set(context, 13, 2, SpritePalette.sirenGlow)
        Pixel.set(context, 14, 7, SpritePalette.sirenGlowDim)
        Pixel.set(context, 13, 8, SpritePalette.sirenGlowDim)
    }

    for y in 2...10 {
        for x in 0..<Pixel.grid {
            let dx = (CGFloat(x) + 0.5 - 7.5) / 5.8
            let dy = (CGFloat(y) + 0.5 - 8.0) / 6.0
            if dx * dx + dy * dy <= 1 {
                Pixel.set(context, x, y, SpritePalette.ink)
            }
        }
    }

    for y in 3...9 {
        for x in 0..<Pixel.grid {
            let dx = (CGFloat(x) + 0.5 - 7.5) / 5.05
            let dy = (CGFloat(y) + 0.5 - 8.0) / 5.3
            guard dx * dx + dy * dy <= 1 else { continue }
            let split = 7 + (y % 2)
            let isBright = frame == 0 ? x < split : x >= split
            Pixel.set(context, x, y, isBright ? SpritePalette.sirenBright : SpritePalette.sirenDeep)
        }
    }

    Pixel.fill(context, x: 2, y: 10, width: 12, height: 1, color: SpritePalette.metalLight)
    Pixel.fill(context, x: 2, y: 11, width: 12, height: 1, color: SpritePalette.metalDark)
    Pixel.fill(context, x: 3, y: 12, width: 10, height: 2, color: SpritePalette.metalMid)
    Pixel.fill(context, x: 3, y: 14, width: 3, height: 1, color: SpritePalette.metalDark)
    Pixel.fill(context, x: 10, y: 14, width: 3, height: 1, color: SpritePalette.metalDark)

    if frame == 0 {
        Pixel.set(context, 5, 4, SpritePalette.glint)
        Pixel.set(context, 6, 4, SpritePalette.glint)
        Pixel.set(context, 4, 5, SpritePalette.sirenGlow)
    } else {
        Pixel.set(context, 10, 4, SpritePalette.glint)
        Pixel.set(context, 11, 4, SpritePalette.glint)
        Pixel.set(context, 12, 5, SpritePalette.sirenGlow)
    }
}

private func drawTrophy(_ context: CGContext, frame: Int) {
    let leftHandle: [(Int, Int)] = [(1, 2), (0, 3), (0, 4), (0, 5), (1, 6)]
    let rightHandle: [(Int, Int)] = [(14, 2), (15, 3), (15, 4), (15, 5), (14, 6)]
    for (x, y) in leftHandle + rightHandle {
        Pixel.set(context, x, y, SpritePalette.ink)
    }
    Pixel.fill(context, x: 1, y: 3, width: 1, height: 3, color: SpritePalette.goldShade)
    Pixel.fill(context, x: 14, y: 3, width: 1, height: 3, color: SpritePalette.goldShade)

    let bowlRows: [(Int, Int, Int)] = [
        (2, 2, 13), (3, 2, 13), (4, 3, 12), (5, 3, 12),
        (6, 4, 11), (7, 5, 10), (8, 6, 9)
    ]
    for (y, left, right) in bowlRows {
        Pixel.row(context, y: y, from: left, to: right, color: SpritePalette.ink)
        Pixel.row(context, y: y, from: left + 1, to: right - 1, color: y == 2 ? SpritePalette.goldLight : SpritePalette.gold)
    }

    Pixel.fill(context, x: 7, y: 9, width: 2, height: 1, color: SpritePalette.goldShade)
    Pixel.row(context, y: 10, from: 6, to: 9, color: SpritePalette.ink)
    Pixel.fill(context, x: 7, y: 10, width: 2, height: 1, color: SpritePalette.gold)
    Pixel.row(context, y: 11, from: 5, to: 10, color: SpritePalette.ink)
    Pixel.fill(context, x: 6, y: 11, width: 4, height: 1, color: SpritePalette.gold)
    Pixel.row(context, y: 12, from: 3, to: 12, color: SpritePalette.ink)
    Pixel.fill(context, x: 4, y: 12, width: 8, height: 1, color: SpritePalette.gold)
    Pixel.fill(context, x: 4, y: 13, width: 8, height: 1, color: SpritePalette.goldShade)

    Pixel.fill(context, x: 4, y: 3, width: 2, height: 3, color: SpritePalette.goldLight)
    Pixel.fill(context, x: 10, y: 4, width: 2, height: 3, color: SpritePalette.goldShade)

    Pixel.set(context, 7, 4, SpritePalette.paperLight)
    Pixel.set(context, 6, 5, SpritePalette.paperLight)
    Pixel.set(context, 7, 5, SpritePalette.paperLight)
    Pixel.set(context, 8, 5, SpritePalette.paperLight)
    Pixel.set(context, 7, 6, SpritePalette.paperLight)

    if frame == 0 {
        Pixel.set(context, 13, 0, SpritePalette.paperLight)
        Pixel.set(context, 12, 1, SpritePalette.goldLight)
        Pixel.set(context, 2, 1, SpritePalette.goldLight)
    } else {
        Pixel.set(context, 1, 1, SpritePalette.paperLight)
        Pixel.set(context, 2, 0, SpritePalette.goldLight)
        Pixel.set(context, 14, 1, SpritePalette.goldLight)
    }
}
