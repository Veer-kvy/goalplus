import AppKit
import GoalPulseCore
import SwiftUI
import UserNotifications

struct SettingsView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion

    var onBack: () -> Void = {}

    @State private var showResetConfirmation = false
    @State private var isSendingTest = false
    @State private var isRequestingPermission = false

    private var preferences: AppPreferences { model.settings.preferences }

    var body: some View {
        VStack(spacing: 0) {
            SubscreenHeader(
                title: "Settings",
                subtitle: "Preferences for this Mac",
                onBack: onBack
            )

            Divider().opacity(0.5)

            ScrollView {
                VStack(spacing: 12) {
                    menuBarCard
                    appearanceCard
                    emojiCard
                    remindersCard
                    startupCard
                    aboutCard
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 16)
            }
            .scrollIndicators(.hidden)
        }
        .alert("Reset settings?", isPresented: $showResetConfirmation) {
            Button("Cancel", role: .cancel) {}
            Button("Reset", role: .destructive) {
                model.settings.reset()
                model.preferencesDidChange()
                Task { await model.notifications.refreshAuthorizationStatus() }
            }
        } message: {
            Text("Preferences return to their defaults. Your goals and countdowns are not affected.")
        }
        .task {
            await model.notifications.refreshAuthorizationStatus()
        }
    }

    // MARK: - Menu bar

    private var menuBarCard: some View {
        settingsCard("Menu Bar") {
            FieldLabel(text: "Goal shown in the menu bar")

            activeGoalMenu

            if model.store.isEmpty {
                Text("Create a goal first, then choose which countdown appears in the menu bar.")
                    .font(.system(size: 8.5))
                    .foregroundStyle(.tertiary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Divider().opacity(0.55)

            FieldLabel(text: "Label style", trailing: preferences.menuBarDisplayMode.label)

            Picker("Menu bar label style", selection: binding(\.menuBarDisplayMode)) {
                ForEach(MenuBarDisplayMode.allCases) { mode in
                    Text(mode.shortLabel).tag(mode)
                }
            }
            .pickerStyle(.segmented)
            .labelsHidden()

            Text(preferences.menuBarDisplayMode.helperText)
                .font(.system(size: 8.5))
                .foregroundStyle(.tertiary)
        }
    }

    private var activeGoalMenu: some View {
        Menu {
            if model.store.goals.isEmpty {
                Text("No goals yet")
            } else {
                ForEach(model.store.goals) { goal in
                    Button {
                        model.setActiveGoal(id: goal.id)
                    } label: {
                        if goal.id == model.store.activeGoalID {
                            Label(goal.trimmedTitle, systemImage: "checkmark")
                        } else {
                            Text(goal.trimmedTitle)
                        }
                    }
                }
            }
        } label: {
            HStack(spacing: 8) {
                if let activeGoal = model.activeGoal {
                    Text(activeGoal.displayEmoji(for: model.mood(for: activeGoal)))
                        .font(.system(size: 15))
                } else {
                    Image(systemName: "menubar.rectangle")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.secondary)
                        .frame(width: 18)
                }

                VStack(alignment: .leading, spacing: 1) {
                    Text(model.activeGoal?.trimmedTitle ?? "No active goal")
                        .font(.system(size: 10.5, weight: .medium))
                        .lineLimit(1)

                    Text(model.store.isEmpty ? "Create a goal to get started" : "Shown in the menu bar")
                        .font(.system(size: 8.5))
                        .foregroundStyle(.secondary)
                }

                Spacer(minLength: 8)

                Image(systemName: "chevron.up.chevron.down")
                    .font(.system(size: 8, weight: .semibold))
                    .foregroundStyle(.tertiary)
            }
            .padding(.horizontal, 9)
            .padding(.vertical, 7)
            .background(Color.primary.opacity(0.04), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
            .contentShape(Rectangle())
        }
        .menuStyle(.button)
        .buttonStyle(.plain)
        .menuIndicator(.hidden)
        .disabled(model.store.isEmpty)
        .help("Choose the goal whose countdown appears in the menu bar")
    }

    // MARK: - Appearance

    private var appearanceCard: some View {
        settingsCard("Appearance") {
            FieldLabel(text: "Countdown format", trailing: preferences.countdownFormat.label)

            Picker("Countdown format", selection: binding(\.countdownFormat)) {
                ForEach(CountdownFormat.allCases) { format in
                    Text(format.shortLabel).tag(format)
                }
            }
            .pickerStyle(.segmented)
            .labelsHidden()

            Text(preferences.countdownFormat.helperText)
                .font(.system(size: 8.5))
                .foregroundStyle(.tertiary)

            Divider().opacity(0.55)

            FieldLabel(text: "Theme", trailing: preferences.theme.label)

            Picker("Theme", selection: binding(\.theme)) {
                ForEach(ThemePreference.allCases) { theme in
                    Text(theme.label).tag(theme)
                }
            }
            .pickerStyle(.segmented)
            .labelsHidden()
        }
    }

    // MARK: - Emoji engine

    private var emojiCard: some View {
        settingsCard("Emoji & Motion") {
            FieldLabel(text: "Animation intensity", trailing: preferences.animationIntensity.label)

            Picker("Emoji animation intensity", selection: binding(\.animationIntensity)) {
                ForEach(AnimationIntensity.allCases) { intensity in
                    Text(intensity.label).tag(intensity)
                }
            }
            .pickerStyle(.segmented)
            .labelsHidden()

            Text("Pulses and bounces run only while the popover is open.")
                .font(.system(size: 8.5))
                .foregroundStyle(.tertiary)

            Divider().opacity(0.55)

            FieldLabel(text: "Mood thresholds", trailing: "Share of time left")

            VStack(spacing: 4) {
                thresholdRow(
                    emoji: EmojiMood.calm.defaultEmoji,
                    title: "Calm above",
                    tint: EmojiMood.calm.tint,
                    level: .calm
                )
                thresholdRow(
                    emoji: EmojiMood.steady.defaultEmoji,
                    title: "Steady above",
                    tint: EmojiMood.steady.tint,
                    level: .steady
                )
                thresholdRow(
                    emoji: EmojiMood.focus.defaultEmoji,
                    title: "Focus above",
                    tint: EmojiMood.focus.tint,
                    level: .focus
                )
                thresholdRow(
                    emoji: EmojiMood.intense.defaultEmoji,
                    title: "Intense above",
                    tint: EmojiMood.intense.tint,
                    level: .intense
                )
            }

            HStack(alignment: .firstTextBaseline, spacing: 6) {
                Text("Below \(model.settings.thresholdPercent(.intense))% the mood becomes urgent \(EmojiMood.urgent.defaultEmoji).")
                    .font(.system(size: 8.5))
                    .foregroundStyle(.tertiary)
                    .fixedSize(horizontal: false, vertical: true)

                Spacer(minLength: 4)

                Button("Reset") {
                    model.settings.resetThresholds()
                }
                .buttonStyle(.plain)
                .font(.system(size: 8.5, weight: .medium))
                .foregroundStyle(.secondary)
                .help("Restore the standard thresholds")
            }

            Divider().opacity(0.55)

            Toggle(isOn: binding(\.reduceMotion)) {
                VStack(alignment: .leading, spacing: 1) {
                    Text("Reduce emoji motion")
                        .font(.system(size: 10, weight: .medium))
                    Text("Turns off pulses, bounces and animated progress.")
                        .font(.system(size: 8.5))
                        .foregroundStyle(.secondary)
                }
            }
            .toggleStyle(.switch)
            .controlSize(.mini)

            if systemReduceMotion {
                Label("System Reduce Motion is on, so animation is paused.", systemImage: "figure.walk.motion")
                    .font(.system(size: 8.5))
                    .foregroundStyle(.tertiary)
            }
        }
    }

    private func thresholdRow(
        emoji: String,
        title: String,
        tint: Color,
        level: SettingsStore.ThresholdLevel
    ) -> some View {
        HStack(spacing: 6) {
            Text(emoji)
                .font(.system(size: 13))
                .frame(width: 20)

            Text(title)
                .font(.system(size: 9.5))
                .foregroundStyle(.secondary)

            Spacer(minLength: 6)

            Text("\(model.settings.thresholdPercent(level))%")
                .font(.system(size: 9.5, weight: .semibold, design: .rounded))
                .monospacedDigit()
                .foregroundStyle(tint)
                .frame(width: 32, alignment: .trailing)

            Stepper(
                "Threshold",
                value: thresholdBinding(level),
                in: 1...99
            )
            .labelsHidden()
            .controlSize(.mini)
        }
        .padding(.vertical, 1)
        .accessibilityElement(children: .combine)
        .accessibilityValue("\(model.settings.thresholdPercent(level)) percent")
    }

    // MARK: - Reminders

    private var remindersCard: some View {
        settingsCard("Reminders") {
            Toggle(isOn: notificationsEnabledBinding) {
                VStack(alignment: .leading, spacing: 1) {
                    Text("Milestone reminders")
                        .font(.system(size: 10, weight: .medium))
                    Text("Local notifications before each deadline.")
                        .font(.system(size: 8.5))
                        .foregroundStyle(.secondary)
                }
            }
            .toggleStyle(.switch)
            .controlSize(.mini)

            VStack(spacing: 6) {
                ForEach(NotificationMilestone.ordered) { milestone in
                    Toggle(isOn: milestoneBinding(milestone)) {
                        HStack(spacing: 6) {
                            Image(systemName: milestoneIcon(milestone))
                                .font(.system(size: 9, weight: .medium))
                                .foregroundStyle(.secondary)
                                .frame(width: 13)

                            VStack(alignment: .leading, spacing: 0.5) {
                                Text("\(milestone.shortLabel) before")
                                    .font(.system(size: 9.5, weight: .medium))
                                Text(milestone.reminderDetail)
                                    .font(.system(size: 8.5))
                                    .foregroundStyle(.tertiary)
                            }

                            Spacer(minLength: 4)

                            if milestone.usesSound {
                                Image(systemName: "speaker.wave.2.fill")
                                    .font(.system(size: 8))
                                    .foregroundStyle(.tertiary)
                                    .help("Includes a notification sound")
                            }
                        }
                    }
                    .toggleStyle(.checkbox)
                    .controlSize(.small)
                }
            }
            .padding(.leading, 2)

            if preferences.notificationsEnabled && preferences.notificationMilestones.isEmpty {
                Label(
                    "Choose at least one milestone to receive reminders.",
                    systemImage: "exclamationmark.triangle.fill"
                )
                .font(.system(size: 8.5))
                .foregroundStyle(.orange)
            }

            Divider().opacity(0.55)

            permissionRow

            if preferences.notificationsEnabled && model.notifications.authorizationStatus == .denied {
                NoticeBanner(
                    kind: .warning,
                    message: "Notifications are blocked for GoalPulse. Allow them in System Settings to receive reminders."
                )
            }

            if let error = model.notifications.lastError {
                NoticeBanner(kind: .error, message: error) {
                    model.notifications.clearLastError()
                }
            }
        }
    }

    private var permissionRow: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(permissionColor)
                .frame(width: 5, height: 5)

            Text(model.notifications.authorizationStatus.goalPulseLabel)
                .font(.system(size: 9))
                .foregroundStyle(.secondary)

            Spacer(minLength: 6)

            if !model.notifications.isAvailable {
                Text("Unavailable")
                    .font(.system(size: 8.5))
                    .foregroundStyle(.tertiary)
            } else if model.notifications.authorizationStatus == .denied {
                Button("System Settings…") {
                    model.notifications.openSystemNotificationSettings()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            } else if model.notifications.canDeliver {
                Button(isSendingTest ? "Sending…" : "Send test") {
                    isSendingTest = true
                    Task {
                        await model.notifications.sendTestNotification()
                        isSendingTest = false
                    }
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .disabled(isSendingTest)
            } else {
                Button(isRequestingPermission ? "Requesting…" : "Allow") {
                    isRequestingPermission = true
                    Task {
                        _ = await model.notifications.requestAuthorizationIfNeeded()
                        if !preferences.notificationsEnabled {
                            setNotificationsEnabled(true)
                        }
                        isRequestingPermission = false
                    }
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
                .disabled(isRequestingPermission)
            }
        }
    }

    // MARK: - Startup

    private var startupCard: some View {
        settingsCard("Startup") {
            Toggle(isOn: launchAtLoginBinding) {
                VStack(alignment: .leading, spacing: 1) {
                    Text("Launch at login")
                        .font(.system(size: 10, weight: .medium))
                    Text(model.launchAtLogin.detail ?? "Open GoalPulse automatically after sign-in.")
                        .font(.system(size: 8.5))
                        .foregroundStyle(model.launchAtLogin.errorMessage == nil ? Color.secondary : Color.red)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            .toggleStyle(.switch)
            .controlSize(.mini)

            if model.launchAtLogin.requiresApproval || model.launchAtLogin.errorMessage != nil {
                Button("Open Login Items") {
                    model.launchAtLogin.openLoginItemsSettings()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            }
        }
    }

    // MARK: - About and data

    private var aboutCard: some View {
        settingsCard("Data & About") {
            HStack(spacing: 8) {
                Image(systemName: "internaldrive")
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
                    .frame(width: 14)

                VStack(alignment: .leading, spacing: 1) {
                    Text("Stored on this Mac")
                        .font(.system(size: 9.5, weight: .medium))
                    Text(displayDataPath)
                        .font(.system(size: 8.5))
                        .foregroundStyle(.tertiary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }

                Spacer(minLength: 6)

                Button("Show") {
                    revealDataFolder()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)
            }

            Label("No account, no analytics, no network requests.", systemImage: "lock.shield")
                .font(.system(size: 8.5))
                .foregroundStyle(.tertiary)

            Divider().opacity(0.55)

            HStack(spacing: 6) {
                Button("Reset settings") {
                    showResetConfirmation = true
                }
                .buttonStyle(.bordered)
                .controlSize(.small)

                Button("Quit GoalPulse") {
                    model.quit()
                }
                .buttonStyle(.bordered)
                .controlSize(.small)

                Spacer(minLength: 4)

                Text("v\(appVersion)")
                    .font(.system(size: 8.5))
                    .foregroundStyle(.tertiary)
            }
        }
    }

    // MARK: - Helpers

    private func settingsCard<Content: View>(
        _ title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionEyebrow(text: title)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .surfaceCard(padding: 13)
    }

    private func binding<Value>(_ keyPath: WritableKeyPath<AppPreferences, Value>) -> Binding<Value> {
        Binding(
            get: { model.settings.preferences[keyPath: keyPath] },
            set: { newValue in
                var updated = model.settings.preferences
                updated[keyPath: keyPath] = newValue
                model.settings.preferences = updated
            }
        )
    }

    private func thresholdBinding(_ level: SettingsStore.ThresholdLevel) -> Binding<Int> {
        Binding(
            get: { model.settings.thresholdPercent(level) },
            set: { model.settings.setThreshold(level, percent: $0) }
        )
    }

    private var notificationsEnabledBinding: Binding<Bool> {
        Binding(
            get: { preferences.notificationsEnabled },
            set: { setNotificationsEnabled($0) }
        )
    }

    private func setNotificationsEnabled(_ enabled: Bool) {
        var updated = model.settings.preferences
        guard updated.notificationsEnabled != enabled else { return }
        updated.notificationsEnabled = enabled
        model.settings.preferences = updated

        Task {
            await model.setNotificationsEnabled(enabled)
            await model.notifications.refreshAuthorizationStatus()
        }
    }

    private func milestoneBinding(_ milestone: NotificationMilestone) -> Binding<Bool> {
        Binding(
            get: { preferences.notificationMilestones.contains(milestone) },
            set: { isEnabled in
                var updated = model.settings.preferences
                if isEnabled {
                    updated.notificationMilestones.insert(milestone)
                } else {
                    updated.notificationMilestones.remove(milestone)
                }
                model.settings.preferences = updated
            }
        )
    }

    private var launchAtLoginBinding: Binding<Bool> {
        Binding(
            get: { model.launchAtLogin.isEnabled },
            set: { model.launchAtLogin.setEnabled($0) }
        )
    }

    private func milestoneIcon(_ milestone: NotificationMilestone) -> String {
        switch milestone {
        case .sevenDays: return "calendar"
        case .oneDay: return "sun.max"
        case .oneHour: return "clock"
        case .tenMinutes: return "alarm"
        }
    }

    private var permissionColor: Color {
        switch model.notifications.authorizationStatus {
        case .authorized, .provisional:
            return .green
        case .denied:
            return .red
        case .notDetermined:
            return .orange
        case .ephemeral:
            return .blue
        @unknown default:
            return .secondary
        }
    }

    private var displayDataPath: String {
        let folder = model.store.dataFileURL.deletingLastPathComponent().path
        return folder.replacingOccurrences(of: NSHomeDirectory(), with: "~")
    }

    private var appVersion: String {
        Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0.0"
    }

    private func revealDataFolder() {
        let fileURL = model.store.dataFileURL
        let folderURL = fileURL.deletingLastPathComponent()
        let target: URL
        if FileManager.default.fileExists(atPath: fileURL.path) {
            target = fileURL
        } else if FileManager.default.fileExists(atPath: folderURL.path) {
            target = folderURL
        } else {
            target = folderURL.deletingLastPathComponent()
        }
        NSWorkspace.shared.activateFileViewerSelecting([target])
    }
}

private extension MenuBarDisplayMode {
    var shortLabel: String {
        switch self {
        case .emojiAndCountdown: return "Emoji + time"
        case .emojiOnly: return "Emoji"
        case .countdownOnly: return "Countdown"
        }
    }

    var helperText: String {
        switch self {
        case .emojiAndCountdown:
            return "The mood emoji and a compact countdown share the menu bar."
        case .emojiOnly:
            return "Only the animated-goal emoji is shown."
        case .countdownOnly:
            return "Only the compact countdown is shown."
        }
    }
}

private extension CountdownFormat {
    var shortLabel: String {
        switch self {
        case .segmented: return "Tiles"
        case .inline: return "Inline"
        case .compact: return "Compact"
        }
    }

    var helperText: String {
        switch self {
        case .segmented:
            return "Large day, hour, minute and second tiles for quick scanning."
        case .inline:
            return "A single readable line: days, hours, minutes and seconds."
        case .compact:
            return "A denser countdown for a quieter, minimal look."
        }
    }
}
