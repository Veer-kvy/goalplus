import Foundation
import GoalPulseCore
import SwiftUI

struct GoalEditorView: View {
    @Environment(AppModel.self) private var model

    let originalGoal: Goal?
    let onClose: () -> Void

    @State private var draft: GoalDraft
    @State private var initialDraft: GoalDraft
    @State private var didAttemptSave = false
    @State private var saveError: String?
    @State private var showDiscardAlert = false
    @State private var titleTouched = false
    @FocusState private var titleFocused: Bool

    init(goal: Goal?, onClose: @escaping () -> Void) {
        originalGoal = goal
        let startingDraft = goal.map { GoalDraft(goal: $0) } ?? GoalDraft()
        _draft = State(initialValue: startingDraft)
        _initialDraft = State(initialValue: startingDraft)
        self.onClose = onClose
    }

    private var isEditing: Bool { originalGoal != nil }

    private var tint: Color {
        if let raw = draft.accentID, let accent = GoalAccent(rawValue: raw) {
            return accent.color
        }
        return .blue
    }

    private var titleError: String? {
        guard titleTouched || didAttemptSave else { return nil }
        if draft.trimmedTitle.isEmpty {
            return GoalValidationError.emptyTitle.errorDescription
        }
        if draft.trimmedTitle.count > GoalValidation.maxTitleLength {
            return GoalValidationError.titleTooLong.errorDescription
        }
        return nil
    }

    private var detailsError: String? {
        guard draft.details.trimmingCharacters(in: .whitespacesAndNewlines).count
            > GoalValidation.maxDetailsLength else { return nil }
        return GoalValidationError.detailsTooLong.errorDescription
    }

    private var emojiError: String? {
        guard (draft.trimmedEmoji ?? "").count > GoalValidation.maxEmojiCharacters else { return nil }
        return GoalValidationError.emojiTooLong.errorDescription
    }

    private var deadlineError: String? {
        guard draft.validation.errors.contains(.deadlineNotAfterStart) else { return nil }
        return GoalValidationError.deadlineNotAfterStart.errorDescription
    }

    private var footerMessage: String? {
        if let saveError { return saveError }
        guard didAttemptSave else { return nil }
        return draft.validation.firstError?.errorDescription
    }

    var body: some View {
        VStack(spacing: 0) {
            SubscreenHeader(
                title: isEditing ? "Edit goal" : "New goal",
                subtitle: isEditing ? "Changes save on this Mac" : "Stored only on this Mac",
                onBack: attemptClose
            )

            Divider().opacity(0.5)

            ScrollView {
                VStack(spacing: 12) {
                    goalFields
                    scheduleFields
                    appearanceFields
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 14)
            }
            .scrollIndicators(.hidden)

            footer
        }
        .alert("Discard changes?", isPresented: $showDiscardAlert) {
            Button("Keep Editing", role: .cancel) {}
            Button("Discard", role: .destructive, action: onClose)
        } message: {
            Text("Your changes to this goal will be lost.")
        }
        .onAppear {
            guard !isEditing else { return }
            DispatchQueue.main.async {
                titleFocused = true
            }
        }
    }

    // MARK: - Goal fields

    private var goalFields: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionEyebrow(text: "Goal")

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 8) {
                    TextField("What are you working toward?", text: $draft.title)
                        .textFieldStyle(.plain)
                        .font(.system(size: 14, weight: .semibold))
                        .focused($titleFocused)
                        .onSubmit(save)
                        .onChange(of: draft.title) { _, _ in
                            titleTouched = true
                        }

                    Text("\(draft.title.count)/\(GoalValidation.maxTitleLength)")
                        .font(.system(size: 8.5, weight: .medium))
                        .monospacedDigit()
                        .foregroundStyle(
                            draft.title.count > GoalValidation.maxTitleLength ? Color.red : Color.secondary
                        )
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .background(fieldFill)
                .overlay {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .strokeBorder(
                            titleError == nil ? Color.primary.opacity(0.07) : Color.red.opacity(0.55),
                            lineWidth: 1
                        )
                }

                if let titleError {
                    inlineError(titleError)
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                ZStack(alignment: .topLeading) {
                    TextEditor(text: $draft.details)
                        .font(.system(size: 11))
                        .scrollContentBackground(.hidden)
                        .scrollIndicators(.hidden)
                        .padding(4)
                        .frame(height: 72)
                        .background(fieldFill)
                        .overlay {
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .strokeBorder(
                                    detailsError == nil ? Color.primary.opacity(0.07) : Color.red.opacity(0.55),
                                    lineWidth: 1
                                )
                        }

                    if draft.details.isEmpty {
                        Text("Add context, a plan, or what done looks like…")
                            .font(.system(size: 11))
                            .foregroundStyle(.tertiary)
                            .padding(.horizontal, 9)
                            .padding(.vertical, 8)
                            .allowsHitTesting(false)
                    }
                }

                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    if let detailsError {
                        inlineError(detailsError)
                    }
                    Spacer(minLength: 0)
                    Text("\(draft.details.count)/\(GoalValidation.maxDetailsLength)")
                        .font(.system(size: 8.5, weight: .medium))
                        .monospacedDigit()
                        .foregroundStyle(
                            draft.details.count > GoalValidation.maxDetailsLength ? Color.red : Color.secondary
                        )
                }
            }
        }
        .surfaceCard(padding: 13)
    }

    // MARK: - Schedule fields

    private var scheduleFields: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 6) {
                SectionEyebrow(text: "Schedule")
                Spacer()
                Label(GoalDateFormatting.currentTimeZoneName, systemImage: "globe")
                    .labelStyle(.titleAndIcon)
                    .font(.system(size: 8.5))
                    .foregroundStyle(.tertiary)
            }

            scheduleRow(
                label: "Start",
                systemImage: "play.circle.fill",
                date: $draft.startDate,
                time: $draft.startTime
            )

            Divider().opacity(0.55).padding(.leading, 23)

            scheduleRow(
                label: "Deadline",
                systemImage: "flag.checkered",
                date: $draft.deadlineDate,
                time: $draft.deadlineTime
            )

            if let deadlineError {
                HStack(alignment: .top, spacing: 6) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .font(.system(size: 8.5))
                    Text(deadlineError)
                        .font(.system(size: 9))
                        .fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .foregroundStyle(.red)
                .padding(.leading, 23)
            }

            HStack(spacing: 7) {
                Image(systemName: "hourglass")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundStyle(tint)

                Text("Total duration")
                    .font(.system(size: 9.5, weight: .medium))
                    .foregroundStyle(.secondary)

                Spacer(minLength: 6)

                Text(GoalFormatting.duration(draft.totalDuration))
                    .font(.system(size: 10.5, weight: .semibold, design: .rounded))
                    .monospacedDigit()
            }
            .padding(.horizontal, 9)
            .padding(.vertical, 7)
            .background(tint.opacity(0.07), in: RoundedRectangle(cornerRadius: 8, style: .continuous))

            HStack(spacing: 5) {
                Text("Quick set")
                    .font(.system(size: 8.5, weight: .medium))
                    .foregroundStyle(.tertiary)

                Spacer(minLength: 4)

                ForEach(GoalDurationPreset.allCases) { preset in
                    SmallChipButton(title: preset.compactLabel) {
                        draft.apply(preset)
                    }
                    .help("Set the deadline to \(preset.label) after the start")
                }
            }
            .padding(.top, 1)
        }
        .surfaceCard(padding: 13)
    }

    private func scheduleRow(
        label: String,
        systemImage: String,
        date: Binding<Date>,
        time: Binding<Date>
    ) -> some View {
        HStack(alignment: .top, spacing: 9) {
            Image(systemName: systemImage)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(tint.opacity(0.85))
                .frame(width: 14)
                .padding(.top, 2)

            VStack(alignment: .leading, spacing: 3) {
                Text(label)
                    .font(.system(size: 9.5, weight: .medium))
                    .foregroundStyle(.secondary)

                HStack(spacing: 6) {
                    DatePicker("", selection: date, displayedComponents: .date)
                        .labelsHidden()
                        .datePickerStyle(.compact)

                    DatePicker("", selection: time, displayedComponents: .hourAndMinute)
                        .labelsHidden()
                        .datePickerStyle(.compact)
                }
            }

            Spacer(minLength: 0)
        }
        .padding(.vertical, 3)
        .accessibilityElement(children: .contain)
        .accessibilityLabel(label)
    }

    // MARK: - Appearance fields

    private var appearanceFields: some View {
        VStack(alignment: .leading, spacing: 11) {
            SectionEyebrow(text: "Appearance")

            HStack(alignment: .top, spacing: 10) {
                TextField("😎", text: $draft.emoji)
                    .textFieldStyle(.plain)
                    .font(.system(size: 20))
                    .multilineTextAlignment(.center)
                    .frame(width: 46, height: 44)
                    .background(fieldFill)
                    .overlay {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .strokeBorder(
                                emojiError == nil ? Color.primary.opacity(0.07) : Color.red.opacity(0.55),
                                lineWidth: 1
                            )
                    }
                    .accessibilityLabel("Custom emoji")

                VStack(alignment: .leading, spacing: 7) {
                    FieldLabel(text: "Emoji", trailing: "Optional")
                    EmojiSuggestionRow(
                        selected: draft.trimmedEmoji ?? "",
                        tint: tint
                    ) { suggestion in
                        draft.emoji = suggestion
                    }
                }
            }

            if let emojiError {
                inlineError(emojiError)
            }

            Divider().opacity(0.55)

            VStack(alignment: .leading, spacing: 7) {
                FieldLabel(
                    text: "Accent",
                    trailing: draft.accentColorName ?? "Automatic"
                )

                AccentPickerRow(
                    selection: draft.accentID,
                    tint: tint
                ) { selection in
                    draft.accentID = selection
                }

                Text("Automatic follows the countdown mood. Urgent and completed states always use their own color.")
                    .font(.system(size: 8.5))
                    .foregroundStyle(.tertiary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .surfaceCard(padding: 13)
    }

    // MARK: - Footer

    private var footer: some View {
        VStack(spacing: 7) {
            Divider().opacity(0.55)

            if let footerMessage {
                HStack(alignment: .top, spacing: 5) {
                    Image(systemName: "exclamationmark.circle.fill")
                        .font(.system(size: 8.5))
                    Text(footerMessage)
                        .font(.system(size: 9))
                        .fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .foregroundStyle(.red)
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .transition(.opacity)
            }

            HStack(spacing: 8) {
                Button("Cancel", action: attemptClose)
                    .buttonStyle(.plain)
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(.secondary)
                    .keyboardShortcut(.cancelAction)

                Spacer(minLength: 8)

                Button(action: save) {
                    Text(isEditing ? "Save changes" : "Add goal")
                        .font(.system(size: 11, weight: .semibold))
                        .padding(.horizontal, 8)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .tint(tint)
                .keyboardShortcut(.defaultAction)
                .help("Save this goal on your Mac")
            }
            .padding(.horizontal, 16)
            .padding(.top, footerMessage == nil ? 4 : 0)
            .padding(.bottom, 11)
        }
        .background(Color.primary.opacity(0.015))
    }

    // MARK: - Helpers

    private var fieldFill: some View {
        RoundedRectangle(cornerRadius: 8, style: .continuous)
            .fill(Color.primary.opacity(0.035))
    }

    private func inlineError(_ message: String) -> some View {
        HStack(alignment: .top, spacing: 4) {
            Image(systemName: "exclamationmark.circle.fill")
                .font(.system(size: 7.5))
            Text(message)
                .font(.system(size: 8.5))
        }
        .foregroundStyle(.red)
    }

    private func attemptClose() {
        guard draft != initialDraft else {
            onClose()
            return
        }
        showDiscardAlert = true
    }

    private func save() {
        didAttemptSave = true
        saveError = nil

        guard draft.isValid else { return }

        let goal = draft.buildGoal()
        let saved: Bool
        if isEditing {
            saved = model.updateGoal(goal)
        } else {
            saved = model.addGoal(goal)
            if saved {
                model.setActiveGoal(id: goal.id)
            }
        }

        guard saved else {
            saveError = "This goal could not be saved. Please check the fields and try again."
            return
        }

        onClose()
    }
}
