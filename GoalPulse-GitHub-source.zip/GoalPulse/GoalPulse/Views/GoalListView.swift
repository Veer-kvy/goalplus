import GoalPulseCore
import SwiftUI

struct GoalListView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion

    var onBack: () -> Void = {}
    var onNewGoal: () -> Void = {}
    var onEditGoal: (Goal) -> Void = { _ in }

    @State private var pendingDeletion: Goal?

    private var reduceMotion: Bool {
        model.settings.preferences.reduceMotion || systemReduceMotion
    }

    private var sortedGoals: [Goal] {
        let now = model.clock.now
        let activeID = model.store.activeGoalID

        return model.store.goals.sorted { lhs, rhs in
            let lhsActive = lhs.id == activeID
            let rhsActive = rhs.id == activeID
            if lhsActive != rhsActive { return lhsActive }

            let lhsComplete = lhs.countdown(at: now).isComplete
            let rhsComplete = rhs.countdown(at: now).isComplete
            if lhsComplete != rhsComplete { return !lhsComplete }

            if lhsComplete {
                return lhs.deadline > rhs.deadline
            }
            return lhs.deadline < rhs.deadline
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            SubscreenHeader(
                title: "All goals",
                subtitle: subtitle,
                trailing: AnyView(
                    ToolbarIconButton(systemName: "plus", help: "New goal", action: onNewGoal)
                ),
                onBack: onBack
            )

            ScrollView {
                VStack(spacing: 9) {
                    notices

                    if sortedGoals.isEmpty {
                        EmptyStateView(
                            systemImage: "square.stack.3d.up",
                            title: "No goals yet",
                            message: "Create a goal with a start, a deadline and an emoji. You can switch which goal appears in the menu bar at any time.",
                            actionTitle: "Create a goal",
                            action: onNewGoal,
                            tint: .blue
                        )
                        .padding(.vertical, 44)
                    } else {
                        ForEach(sortedGoals) { goal in
                            GoalListRow(
                                goal: goal,
                                countdown: model.countdown(for: goal),
                                mood: model.mood(for: goal),
                                isActive: goal.id == model.store.activeGoalID,
                                onEdit: { onEditGoal(goal) },
                                onSelect: { model.setActiveGoal(id: goal.id) },
                                onDelete: { pendingDeletion = goal }
                            )
                        }

                        Text("Click a goal to edit. Use ⋯ to show it in the menu bar or delete it.")
                            .font(.system(size: 9))
                            .foregroundStyle(.tertiary)
                            .multilineTextAlignment(.center)
                            .fixedSize(horizontal: false, vertical: true)
                            .padding(.top, 4)
                            .padding(.horizontal, 12)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 4)
                .padding(.bottom, 14)
                .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: sortedGoals.map(\.id))
            }
            .scrollIndicators(.hidden)
        }
        .alert(
            "Delete goal?",
            isPresented: Binding(
                get: { pendingDeletion != nil },
                set: { if !$0 { pendingDeletion = nil } }
            ),
            presenting: pendingDeletion
        ) { goal in
            Button("Cancel", role: .cancel) {
                pendingDeletion = nil
            }
            Button("Delete", role: .destructive) {
                model.deleteGoal(id: goal.id)
                pendingDeletion = nil
            }
        } message: { goal in
            Text("\"\(goal.trimmedTitle)\" will be removed from this Mac. This can't be undone.")
        }
    }

    private var subtitle: String {
        let count = model.store.goals.count
        switch count {
        case 0: return "Nothing tracked"
        case 1: return "1 goal on this Mac"
        default: return "\(count) goals on this Mac"
        }
    }

    @ViewBuilder
    private var notices: some View {
        if let error = model.store.persistenceError {
            NoticeBanner(kind: .error, message: error) {
                model.store.clearPersistenceError()
            }
        }

        if let notice = model.store.dataNotice {
            NoticeBanner(kind: .warning, message: notice) {
                model.store.clearDataNotice()
            }
        }
    }
}

private struct GoalListRow: View {
    let goal: Goal
    let countdown: GoalCountdown
    let mood: EmojiMood
    let isActive: Bool

    let onEdit: () -> Void
    let onSelect: () -> Void
    let onDelete: () -> Void

    private var tint: Color {
        GoalPalette.progressTint(for: goal, mood: mood)
    }

    var body: some View {
        HStack(alignment: .center, spacing: 6) {
            Button(action: onEdit) {
                HStack(alignment: .center, spacing: 9) {
                    emojiBadge
                    details
                    Spacer(minLength: 4)
                }
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .help("Edit goal")

            Menu {
                Button {
                    onSelect()
                } label: {
                    Label("Show in Menu Bar", systemImage: "menubar.rectangle")
                }
                .disabled(isActive)

                Button {
                    onEdit()
                } label: {
                    Label("Edit Goal", systemImage: "square.and.pencil")
                }

                Divider()

                Button(role: .destructive) {
                    onDelete()
                } label: {
                    Label("Delete Goal", systemImage: "trash")
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.secondary)
                    .frame(width: 22, height: 24)
                    .contentShape(Rectangle())
            }
            .menuStyle(.borderlessButton)
            .menuIndicator(.hidden)
            .fixedSize()
            .help("Goal actions")
        }
        .padding(10)
        .background {
            RoundedRectangle(cornerRadius: 13, style: .continuous)
                .fill(Color.primary.opacity(isActive ? 0.055 : 0.028))
        }
        .overlay {
            RoundedRectangle(cornerRadius: 13, style: .continuous)
                .strokeBorder(
                    isActive ? tint.opacity(0.30) : Color.primary.opacity(0.06),
                    lineWidth: 1
                )
        }
    }

    private var emojiBadge: some View {
        ZStack {
            Circle()
                .fill(tint.opacity(0.12))
                .frame(width: 32, height: 32)

            PixelEmojiSprite(
                emoji: goal.displayEmoji(for: mood),
                size: 24
            )
        }
        .overlay {
            if isActive {
                Circle()
                    .strokeBorder(tint.opacity(0.35), lineWidth: 1)
            }
        }
        .accessibilityHidden(true)
    }

    private var details: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(spacing: 5) {
                Text(goal.trimmedTitle)
                    .font(.system(size: 11.5, weight: .semibold))
                    .lineLimit(1)

                if isActive {
                    Text("ACTIVE")
                        .font(.system(size: 7, weight: .bold))
                        .tracking(0.4)
                        .foregroundStyle(tint)
                        .padding(.horizontal, 4)
                        .padding(.vertical, 1.5)
                        .background(tint.opacity(0.12), in: Capsule())
                }

                Spacer(minLength: 0)
            }

            Text(subtitle)
                .font(.system(size: 9.5))
                .foregroundStyle(.secondary)
                .lineLimit(1)

            miniProgress
                .padding(.top, 1)
        }
    }

    private var miniProgress: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule()
                    .fill(Color.primary.opacity(0.07))
                Capsule()
                    .fill(tint)
                    .frame(width: max(2, proxy.size.width * countdown.progress))
            }
        }
        .frame(height: 3)
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Progress")
        .accessibilityValue(GoalFormatting.progressAccessibilityValue(countdown))
    }

    private var subtitle: String {
        if countdown.isComplete {
            return "Complete · finished \(GoalDateFormatting.dateOnly(goal.deadline))"
        }
        if countdown.isUpcoming {
            return "Scheduled · starts \(GoalDateFormatting.compactDeadline(goal.startDate))"
        }
        return "Due \(GoalDateFormatting.compactDeadline(goal.deadline)) · \(GoalFormatting.duration(countdown.remaining)) left"
    }
}
