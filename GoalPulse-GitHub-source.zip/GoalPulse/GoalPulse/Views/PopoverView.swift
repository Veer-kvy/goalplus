import GoalPulseCore
import SwiftUI

private enum PopoverRoute: Equatable {
    case dashboard
    case goals
    case settings
    case editor(Goal?)
}

struct PopoverView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion

    @State private var route: PopoverRoute = .dashboard
    @State private var editorReturnRoute: PopoverRoute = .dashboard

    private var reduceMotion: Bool {
        model.settings.preferences.reduceMotion || systemReduceMotion
    }

    var body: some View {
        ZStack {
            PopoverBackground(tint: backgroundTint)

            screen
                .id(routeKey)
                .transition(
                    reduceMotion
                        ? .opacity
                        : .asymmetric(
                            insertion: .opacity.combined(with: .scale(scale: 0.985)),
                            removal: .opacity
                        )
                )
        }
        .frame(width: 384, height: 600)
        .preferredColorScheme(model.settings.preferences.theme.colorScheme)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.18), value: routeKey)
        .onAppear {
            model.start()
        }
        .onChange(of: model.settings.preferences) { _, _ in
            model.preferencesDidChange()
        }
    }

    @ViewBuilder
    private var screen: some View {
        switch route {
        case .dashboard:
            CountdownDashboardView(
                onOpenGoals: { navigate(.goals) },
                onEditGoal: { goal in openEditor(for: goal) },
                onNewGoal: { openEditor(for: nil) },
                onOpenSettings: { navigate(.settings) }
            )

        case .goals:
            GoalListView(
                onBack: { navigate(.dashboard) },
                onNewGoal: { openEditor(for: nil) },
                onEditGoal: { goal in openEditor(for: goal) }
            )

        case .settings:
            SettingsView(
                onBack: { navigate(.dashboard) }
            )

        case .editor(let goal):
            GoalEditorView(
                goal: goal,
                onClose: { navigate(editorReturnRoute) }
            )
        }
    }

    private var routeKey: String {
        switch route {
        case .dashboard:
            return "dashboard"
        case .goals:
            return "goals"
        case .settings:
            return "settings"
        case .editor(let goal):
            return "editor-\(goal?.id.uuidString ?? "new")"
        }
    }

    private var activeTint: Color {
        guard let goal = model.activeGoal else { return .blue }
        return GoalPalette.progressTint(for: goal, mood: model.mood(for: goal))
    }

    private var backgroundTint: Color {
        switch route {
        case .dashboard, .goals:
            return activeTint
        case .settings, .editor:
            return .blue
        }
    }

    private func openEditor(for goal: Goal?) {
        editorReturnRoute = route
        navigate(.editor(goal))
    }

    private func navigate(_ newRoute: PopoverRoute) {
        route = newRoute
    }
}
