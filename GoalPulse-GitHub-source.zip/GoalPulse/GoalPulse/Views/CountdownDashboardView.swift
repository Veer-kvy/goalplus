import GoalPulseCore
import SwiftUI

struct CountdownDashboardView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.accessibilityReduceMotion) private var systemReduceMotion

    var onOpenGoals: () -> Void = {}
    var onEditGoal: (Goal) -> Void = { _ in }
    var onNewGoal: () -> Void = {}
    var onOpenSettings: () -> Void = {}

    private var preferences: AppPreferences { model.settings.preferences }
    private var reduceMotion: Bool { preferences.reduceMotion || systemReduceMotion }
    private var activeGoal: Goal? { model.activeGoal }

    private var tint: Color {
        guard let activeGoal else { return .blue }
        return GoalPalette.progressTint(for: activeGoal, mood: model.mood(for: activeGoal))
    }

    var body: some View {
        VStack(spacing: 0) {
            header

            ScrollView {
                VStack(spacing: 12) {
                    notices
                    dashboardContent
                }
                .padding(.horizontal, 16)
                .padding(.top, 6)
                .padding(.bottom, 12)
            }
            .scrollIndicators(.hidden)

            footer
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: activeGoal?.id)
    }

    private var header: some View {
        HStack(spacing: 9) {
            GoalPulseMark(tint: tint)

            VStack(alignment: .leading, spacing: 1) {
                Text("GoalPulse")
                    .font(.system(size: 14.5, weight: .semibold, design: .rounded))

                Text(activeGoal == nil ? "LOCAL COUNTDOWNS" : "MAKE IT COUNT")
                    .font(.system(size: 8, weight: .semibold))
                    .tracking(0.75)
                    .foregroundStyle(.secondary)
            }

            Spacer(minLength: 8)

            ToolbarIconButton(systemName: "plus", help: "New goal", action: onNewGoal)
            ToolbarIconButton(systemName: "gearshape", help: "Settings", action: onOpenSettings)
        }
        .padding(.horizontal, 16)
        .padding(.top, 14)
        .padding(.bottom, 8)
    }

    @ViewBuilder
    private var notices: some View {
        if let error = model.store.persistenceError {
            NoticeBanner(kind: .error, message: error) {
                model.store.clearPersistenceError()
            }
        }

        if let notice = model.store.dataNotice {
            NoticeBanner(kind: .warning, message: notice) {
                model.store.clearDataNotice()
            }
        }
    }

    @ViewBuilder
    private var dashboardContent: some View {
        if let goal = activeGoal {
            ActiveGoalCard(
                goal: goal,
                goals: model.store.goals,
                countdown: model.countdown(for: goal),
                mood: model.mood(for: goal),
                preferences: preferences,
                reduceMotion: reduceMotion,
                tint: tint,
                onEdit: { onEditGoal(goal) },
                onNewGoal: onNewGoal,
                onSelectGoal: { candidate in
                    model.setActiveGoal(id: candidate.id)
                },
                onOpenGoals: onOpenGoals
            )

            TimelineCard(
                goal: goal,
                countdown: model.countdown(for: goal),
                tint: tint
            )
        } else if model.store.isEmpty {
            EmptyStateView(
                systemImage: "timer",
                title: "Give your milestone a finish line",
                message: "Set a start, a deadline and a mood emoji. GoalPulse keeps the countdown in your menu bar — stored only on this Mac.",
                actionTitle: "Create your first goal",
                action: onNewGoal,
                tint: .blue
            )
            .padding(.vertical, 42)
        } else {
            EmptyStateView(
                systemImage: "menubar.rectangle",
                title: "Nothing in the menu bar",
                message: "You have \(model.store.goals.count) saved \(model.store.goals.count == 1 ? "goal" : "goals"). Pick one to feature its countdown in the menu bar.",
                actionTitle: "Choose a goal",
                action: onOpenGoals,
                tint: .blue
            )
            .padding(.vertical, 42)
        }
    }

    private var footer: some View {
        VStack(spacing: 0) {
            Divider().opacity(0.55)

            FooterLinks(
                goalCount: model.store.goals.count,
                onGoals: onOpenGoals,
                onQuit: { model.quit() }
            )
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
        }
    }
}

// MARK: - Active goal card

private struct ActiveGoalCard: View {
    let goal: Goal
    let goals: [Goal]
    let countdown: GoalCountdown
    let mood: EmojiMood
    let preferences: AppPreferences
    let reduceMotion: Bool
    let tint: Color

    let onEdit: () -> Void
    let onNewGoal: () -> Void
    let onSelectGoal: (Goal) -> Void
    let onOpenGoals: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            topRow

            identityBlock

            heroRow

            GoalProgressBar(
                countdown: countdown,
                tint: tint,
                reduceMotion: reduceMotion
            )

            motivationBox

            actionRow
        }
        .surfaceCard(padding: 14, tint: tint)
        .accessibilityElement(children: .contain)
    }

    private var topRow: some View {
        HStack(spacing: 6) {
            MoodChip(
                mood: mood,
                labelOverride: statusOverride
            )

            Button {
                onOpenGoals()
            } label: {
                Image(systemName: "chevron.down")
                    .font(.system(size: 7.5, weight: .bold))
                    .foregroundStyle(.tertiary)
                    .frame(width: 13, height: 13)
                    .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .help("Manage goals")
            .accessibilityLabel("Manage goals")

            Spacer(minLength: 6)

            Label("In menu bar", systemImage: "menubar.rectangle")
                .labelStyle(.titleAndIcon)
                .font(.system(size: 8.5, weight: .medium))
                .foregroundStyle(.tertiary)
                .help("This goal is shown in the menu bar")
        }
    }

    private var identityBlock: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(goal.trimmedTitle)
                .font(.system(size: 16.5, weight: .semibold))
                .lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)

            if !goal.trimmedDetails.isEmpty {
                Text(goal.trimmedDetails)
                    .font(.system(size: 10))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.horizontal, 1)
        .padding(.trailing, 2)
    }

    private var heroRow: some View {
        HStack(alignment: .center, spacing: 8) {
            AnimatedEmojiView(
                emoji: goal.displayEmoji(for: mood),
                mood: mood,
                intensity: preferences.animationIntensity,
                reduceMotion: reduceMotion,
                size: 64
            )

            VStack(alignment: .leading, spacing: 5) {
                CountdownDisplay(
                    countdown: countdown,
                    format: preferences.countdownFormat,
                    tint: tint,
                    reduceMotion: reduceMotion,
                    valueSize: 22,
                    labelSize: 8,
                    inlineSize: 15,
                    compactSize: 23
                )

                statusLine
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var statusLine: some View {
        HStack(spacing: 4) {
            Image(systemName: statusIcon)
                .font(.system(size: 8, weight: .semibold))
            Text(statusDetail)
                .font(.system(size: 9.5, weight: .medium))
                .lineLimit(2)
                .multilineTextAlignment(.leading)
        }
        .foregroundStyle(countdown.isComplete ? mood.tint : Color.secondary)
        .frame(maxWidth: .infinity, alignment: .leading)
        .accessibilityElement(children: .combine)
    }

    private var motivationBox: some View {
        HStack(alignment: .top, spacing: 7) {
            Image(systemName: motivationIcon)
                .font(.system(size: 9, weight: .semibold))
                .foregroundStyle(tint)
                .padding(.top, 1)

            VStack(alignment: .leading, spacing: 1) {
                Text(motivationHeadline)
                    .font(.system(size: 10, weight: .semibold))

                Text(motivationMessage)
                    .font(.system(size: 9.5))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 9)
        .padding(.vertical, 8)
        .background(tint.opacity(0.075), in: RoundedRectangle(cornerRadius: 9, style: .continuous))
        .accessibilityElement(children: .combine)
    }

    private var actionRow: some View {
        HStack(spacing: 6) {
            Button(action: onEdit) {
                DashboardActionLabel(title: "Edit", systemImage: "square.and.pencil", tint: tint)
            }
            .buttonStyle(.plain)
            .help("Edit this goal")
            .frame(maxWidth: .infinity)

            Menu {
                ForEach(goals) { candidate in
                    Button {
                        onSelectGoal(candidate)
                    } label: {
                        if candidate.id == goal.id {
                            Label(candidate.trimmedTitle, systemImage: "checkmark")
                        } else {
                            Text(candidate.trimmedTitle)
                        }
                    }
                }

                Divider()

                Button("All goals…", action: onOpenGoals)
            } label: {
                DashboardActionLabel(
                    title: "Switch",
                    systemImage: "arrow.left.arrow.right",
                    tint: tint
                )
            }
            .menuStyle(.button)
            .buttonStyle(.plain)
            .menuIndicator(.hidden)
            .frame(maxWidth: .infinity)
            .help("Choose the goal shown in the menu bar")

            Button(action: onNewGoal) {
                DashboardActionLabel(title: "New", systemImage: "plus", tint: tint)
            }
            .buttonStyle(.plain)
            .help("Create a new goal")
            .frame(maxWidth: .infinity)
        }
    }

    private var statusOverride: String? {
        if countdown.isUpcoming { return "Scheduled" }
        if countdown.isComplete { return "Complete" }
        return nil
    }

    private var statusIcon: String {
        if countdown.isComplete { return "checkmark.seal.fill" }
        if countdown.isUpcoming { return "calendar.badge.clock" }
        return "clock"
    }

    private var statusDetail: String {
        if countdown.isComplete {
            return GoalStatusCopy.completionDetail(deadline: goal.deadline)
        }
        if countdown.isUpcoming {
            return GoalStatusCopy.upcomingDetail(start: goal.startDate, now: countdown.now)
        }
        return "Due \(GoalDateFormatting.compactDeadline(goal.deadline))"
    }

    private var motivationIcon: String {
        if countdown.isComplete { return "checkmark.seal.fill" }
        if countdown.isUpcoming { return "calendar" }
        return "sparkles"
    }

    private var motivationHeadline: String {
        if countdown.isComplete { return EmojiMood.complete.headline }
        if countdown.isUpcoming { return "Waiting for the start" }
        return mood.headline
    }

    private var motivationMessage: String {
        if countdown.isComplete { return EmojiMood.complete.motivation }
        if countdown.isUpcoming {
            return "Your plan is in place. The countdown begins at the scheduled start time."
        }
        return mood.motivation
    }
}

// MARK: - Timeline

private struct TimelineCard: View {
    let goal: Goal
    let countdown: GoalCountdown
    let tint: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 6) {
                SectionEyebrow(text: "Timeline")
                Spacer()

                Label(GoalDateFormatting.currentTimeZoneName, systemImage: "globe")
                    .font(.system(size: 8.5))
                    .foregroundStyle(.tertiary)
                    .labelStyle(.titleAndIcon)
                    .help("Dates are shown in your current time zone")
            }

            HStack(spacing: 6) {
                StatTile(
                    label: "Total",
                    value: GoalFormatting.duration(countdown.totalDuration),
                    detail: nil
                )
                StatTile(
                    label: "Elapsed",
                    value: GoalFormatting.duration(countdown.elapsed),
                    detail: GoalFormatting.percent(countdown.progress)
                )
                StatTile(
                    label: "Remaining",
                    value: GoalFormatting.duration(countdown.remaining),
                    detail: GoalFormatting.percent(countdown.remainingFraction)
                )
            }

            VStack(spacing: 0) {
                TimelineRow(
                    systemImage: "play.circle.fill",
                    label: "Start",
                    value: GoalDateFormatting.dateAndTime(goal.startDate),
                    tint: tint
                )

                Divider()
                    .opacity(0.55)
                    .padding(.leading, 22)

                TimelineRow(
                    systemImage: "flag.checkered",
                    label: "Deadline",
                    value: GoalDateFormatting.dateAndTime(goal.deadline),
                    tint: tint
                )
            }
        }
        .surfaceCard(padding: 13)
    }
}

private struct StatTile: View {
    let label: String
    let value: String
    let detail: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(.system(size: 8, weight: .semibold))
                .textCase(.uppercase)
                .tracking(0.5)
                .foregroundStyle(.secondary)

            Text(value)
                .font(.system(size: 12.5, weight: .semibold, design: .rounded))
                .monospacedDigit()
                .lineLimit(1)
                .minimumScaleFactor(0.7)

            if let detail {
                Text(detail)
                    .font(.system(size: 8.5, weight: .medium))
                    .foregroundStyle(.tertiary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 8)
        .padding(.vertical, 7)
        .background(Color.primary.opacity(0.04), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .accessibilityElement(children: .combine)
    }
}

private struct TimelineRow: View {
    let systemImage: String
    let label: String
    let value: String
    let tint: Color

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: systemImage)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(tint.opacity(0.85))
                .frame(width: 14)

            Text(label)
                .font(.system(size: 9.5, weight: .medium))
                .foregroundStyle(.secondary)

            Spacer(minLength: 8)

            Text(value)
                .font(.system(size: 10, weight: .medium))
                .lineLimit(1)
                .minimumScaleFactor(0.8)
        }
        .padding(.vertical, 7)
        .accessibilityElement(children: .combine)
    }
}

// MARK: - Quick action

private struct DashboardActionLabel: View {
    let title: String
    let systemImage: String
    let tint: Color

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: systemImage)
                .font(.system(size: 8.5, weight: .semibold))
            Text(title)
                .font(.system(size: 10, weight: .semibold))
        }
        .foregroundStyle(tint)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 6)
        .background(tint.opacity(0.10), in: Capsule())
        .overlay {
            Capsule().strokeBorder(tint.opacity(0.16), lineWidth: 0.5)
        }
        .contentShape(Capsule())
    }
}
