import GoalPulseCore
import SwiftUI

/// The label rendered in the system menu bar.
///
/// It reads the shared clock, so the compact countdown stays accurate while
/// the popover is closed. The text is deliberately short and uses the adaptive
/// formatter: seconds only appear during the final hour.
struct MenuBarLabelView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        let mode = model.settings.preferences.menuBarDisplayMode
        let goal = model.activeGoal
        let countdown = goal.map { model.countdown(for: $0) }
        let mood = goal.map { model.mood(for: $0) }

        Group {
            if let goal, let countdown, let mood {
                HStack(spacing: 4) {
                    if mode != .countdownOnly {
                        PixelEmojiSprite(
                            emoji: goal.displayEmoji(for: mood),
                            size: 16
                        )
                    }

                    if mode != .emojiOnly {
                        Text(GoalFormatting.menuBarCountdown(countdown))
                            .font(.system(size: 11.5, weight: .medium, design: .rounded))
                            .monospacedDigit()
                    }
                }
            } else {
                Image(systemName: "timer")
                    .font(.system(size: 12, weight: .medium))
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(accessibilityLabel(goal: goal, countdown: countdown))
    }

    private func accessibilityLabel(goal: Goal?, countdown: GoalCountdown?) -> String {
        guard let goal, let countdown else {
            return "GoalPulse. No active goal."
        }
        if countdown.isComplete {
            return "GoalPulse. \(goal.trimmedTitle), complete."
        }
        return "GoalPulse. \(goal.trimmedTitle). \(GoalFormatting.accessibilityCountdown(countdown))."
    }
}
